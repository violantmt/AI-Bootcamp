from pathlib import Path
p=Path(__file__).resolve().parent/'prototype'
model=(p/'model.mjs').read_text().replace('export ','')
app=(p/'app.mjs').read_text().replace("import {fresh,api} from './model.mjs';",'')
(p/'MO-DEMO.html').write_text((p/'index.html').read_text().replace('<script type="module" src="app.mjs"></script>','<script>'+model+'\n'+app+'</script>'))
