# Codebase PB03 — Tier 2
Demo kho: prototype/MO-DEMO.html (standalone) hoặc prototype/index.html với source modules.
Knowledge Health: knowledge-health/MO-KNOWLEDGE-HEALTH.html. Không có Project Health tổng quát.
Mở HTML trên máy cá nhân; nếu trình duyệt chặn file local, từ thư mục CODEBASE chạy `python -m http.server 8000`, rồi mở trang prototype/MO-DEMO.html trên máy cục bộ.

## Kiểm tra
- Node.js 24 (đã dùng 24.19.0): `node prototype/test.mjs`.
- Python 3.12 và dependency trong requirements-test.txt: `python -m pip install -r requirements-test.txt`, `python -m playwright install chromium` nếu chưa có browser.
- Các script browser đang chọn /usr/bin/chromium như môi trường đã kiểm. Máy khác cần chỉnh executable_path theo vị trí Chromium được cài hoặc bỏ tham số đó để Playwright chọn browser đã cài; đây là cấu hình chạy test, không thay quy tắc kho.
- `python prototype/test_browser.py`; `python knowledge-health/test_dashboard.py`.
- Rebuild dashboard: `python knowledge-health/build.py`.
- Rebuild demo standalone: `python build_demo.py`.

Không có production backend, DB migration đang chạy, auth thật, nhiều người cập nhật đồng thời hoặc CI live. SQL chỉ schema tham khảo. Các scenario mở rộng TS15–TS21 chưa được thực thi; xem ARTIFACTS.
Dữ liệu trình duyệt là localStorage trên máy đang dùng. Test/video dùng profile riêng và dữ liệu giả, không cần credential.
