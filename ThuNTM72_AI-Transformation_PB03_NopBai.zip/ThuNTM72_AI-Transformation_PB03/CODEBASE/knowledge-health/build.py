from pathlib import Path
p=Path(__file__).resolve().parent
(p/'MO-KNOWLEDGE-HEALTH.html').write_text((p/'template.html').read_text().replace('__SEED__',(p/'seed.json').read_text()))
