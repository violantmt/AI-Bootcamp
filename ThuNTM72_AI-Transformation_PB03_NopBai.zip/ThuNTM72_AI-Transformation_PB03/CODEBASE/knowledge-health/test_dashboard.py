from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from threading import Thread
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parent
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root)));Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=b.new_page(viewport={'width':1280,'height':960});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/MO-KNOWLEDGE-HEALTH.html')
  assert page.locator('.card').count()==7
  assert page.locator('.card.red').count()==0
  assert page.locator('.card.unknown').count()==0
  assert page.locator('[data-id="c2"] .value').inner_text()=='100%'
  assert page.locator('[data-id="c7"] .value').inner_text()=='100%'
  assert page.locator('[data-id="c3"] .value').inner_text()=='100%'
  assert page.locator('[data-id="c5"] .value').inner_text()=='100%'
  assert 'Changes Requested' in page.locator('[data-id="c5"]').inner_text()
  assert page.locator('[data-id="c4"] .value').inner_text()=='0%'
  assert 'còn finding' in page.inner_text('#overall')
  page.select_option('#status','unknown');assert page.locator('.card').count()==0
  page.select_option('#status','all');page.select_option('#scope','knowledge');assert page.locator('.card').count()==7
  def update(id,n,d):
   card=page.locator(f'[data-id="{id}"]');detail=card.locator('.editor');
   if not detail.get_attribute('open'):detail.locator('summary').click()
   card.locator('input[name="num"]').fill(str(n));card.locator('input[name="den"]').fill(str(d));card.locator('input[name="evidence"]').fill('Fixture test, not audit actual');card.locator('input[name="date"]').fill('2026-10-31');card.get_by_role('button',name='Lưu số liệu').click()
  update('c7',6,8);assert 'green' in page.locator('[data-id="c7"]').get_attribute('class');assert page.locator('[data-id="c7"] .value').inner_text()=='75%'
  update('c4',3,15);assert 'amber' in page.locator('[data-id="c4"]').get_attribute('class')
  update('c2',0,0);assert page.locator('[data-id="c2"] .value').inner_text()=='N/A'
  update('c1',11,10);assert 'tử số' in page.locator('[data-id="c1"] .editError').inner_text()
  page.reload();assert page.locator('[data-id="c7"] .value').inner_text()=='75%'
  page.locator('#actions input').first.check()
  with page.expect_download() as download:page.click('#export')
  content=json.loads(Path(download.value.path()).read_text());assert len(content['metrics'])==7;assert content['actions']['fresh'] is True
  page.once('dialog',lambda d:d.accept());page.click('#reset');assert page.locator('[data-id="c7"] .value').inner_text()=='100%'
  page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path=str(root/'knowledge-mobile.png'),full_page=True)
  page.set_viewport_size({'width':1440,'height':1000});page.screenshot(path=str(root/'knowledge-desktop.png'),full_page=True)
  assert not errors,errors;b.close()
 print('PASS: 7 c1–c7 cards, audited seed ratios, 0 red/0 unknown; c3 10/10 and c5 10/10 review trace, Changes Requested remains visible; c2 9/9 revisions, c7 human 8/8, filters, c7 ratio, inverse c4 thresholds, N/A zero denominator, invalid ratio, persistence, action export/reset, mobile, no JS errors.')
finally:server.shutdown()
