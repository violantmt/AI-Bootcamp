# Phạm vi kiểm tra trước đóng gói
Log đã chạy thật: model27tests, demo Chromium, Knowledge Health Chromium. Hai build HTML được tái tạo và so hash giống nội dung đã giao. MP4 được ffprobe đọc metadata và ffmpeg decode toàn bộ không lỗi; PDF được render và kiểm trang đầu tiếng Việt.
Các test concurrent/storage failure mở rộng trong review PM/BA chưa triển khai/chưa chạy, giữ Not Tested. Không có xác nhận production hoặc UAT thủ kho thật.
Prompt/response và decisions được tái dựng từ hội thoại/artefact theo phạm vi ghi trong logs, không giả commit Git hoặc billing.
Người học cần đọc/chỉnh bài thu hoạch và xem video trước khi nộp. Video là record tự động có phụ đề, không giọng đọc, không chứng minh học viên đã tự thuyết trình miệng.
