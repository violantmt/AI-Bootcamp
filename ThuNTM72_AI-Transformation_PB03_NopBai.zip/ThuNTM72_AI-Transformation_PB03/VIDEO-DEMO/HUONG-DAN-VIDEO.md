# Video demo
Video do AI hỗ trợ quay thao tác tự động trên bản demo thật, dữ liệu giả và profile sạch; phụ đề tiếng Việt, không có giọng đọc/facecam và không giả danh người học thuyết trình.
Bao gồm nhập sai/đúng, không trùng hàng, tạo mã, xóa còn tồn bị chặn, đề nghị giảm/duyệt, xóa tồn0 giữ lịch sử sau reload và Knowledge Health.
Kịch bản cảnh trong KICH-BAN-VIDEO.md có thể dùng để ThuNTM72 tự thuyết minh hoặc quay lại nếu người tổ chức yêu cầu video người học trình bày. Video chỉ minh họa phạm vi demo, không chứng minh concurrency/SoD/production hoặc mọi test đã đạt.
