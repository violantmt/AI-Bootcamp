from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
from threading import Thread
from playwright.sync_api import sync_playwright
import json,time
root=Path(__file__).resolve().parents[1]/'CODEBASE'
out=Path(__file__).resolve().parent/'recording-output';out.mkdir(exist_ok=True,parents=True)
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(root)))
Thread(target=server.serve_forever,daemon=True).start();scenes=[];start=time.monotonic()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  context=b.new_context(viewport={'width':1280,'height':800},record_video_dir=str(out/'raw'),record_video_size={'width':1280,'height':800})
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  def caption(title,body,seconds=10):
   page.evaluate('''([title,body])=>{let box=document.getElementById('recording-caption');if(!box){box=document.createElement('div');box.id='recording-caption';box.style.cssText='position:fixed;left:16px;right:16px;bottom:12px;z-index:999999;background:rgba(12,38,53,.97);color:white;padding:16px 22px;border-radius:12px;font:18px/1.45 system-ui;pointer-events:none;box-shadow:0 2px 18px #0005';document.body.append(box);}box.replaceChildren();let h=document.createElement('b');h.textContent=title;h.style.cssText='display:block;color:#7ee4cd;font-size:22px;margin-bottom:5px';let p=document.createElement('div');p.textContent=body;box.append(h,p);}''',[title,body])
   scenes.append({'second':round(time.monotonic()-start,1),'title':title,'caption':body})
   print(title,flush=True);page.wait_for_timeout(seconds*1000)
  base=f'http://127.0.0.1:{server.server_port}'
  page.goto(base+'/prototype/MO-DEMO.html');caption('PB-03 · Quản lý kho văn phòng phẩm · Tier 2','Quay trực tiếp bản demo thật bằng thao tác tự động của AI. Dữ liệu giả, phụ đề, không giọng đọc; không thay lời bảo vệ trực tiếp của người học.',9)
  page.select_option('#role','keeper');page.locator('#lines input').fill('-3');page.click('#save');assert 'lớn hơn 0' in page.inner_text('#message');page.locator('#message').evaluate("el=>el.scrollIntoView({block:'center'})");caption('1 · Kiểm tra dữ liệu nhập','Nhập -3 bị từ chối và không làm thay đổi tồn. Đây là ca sai phải được chặn, không chỉ kiểm happy path.',11)
  page.locator('#lines input').fill('3');page.click('#save');assert page.locator('#stock tr').first.inner_text().split('\t')[2]=='13';page.locator('#stock').evaluate("el=>el.scrollIntoView({block:'center'})");caption('2 · Luồng nhập → lưu → xem lại','Bút ban đầu 10, nhập hợp lệ 3: tồn thành 13, có phiếu và lịch sử. Chỉ báo thành công sau khi lưu cục bộ được.',11)
  page.locator('#lines input').fill('2');page.click('#add');page.locator('#lines input').nth(1).fill('4');assert page.locator('#lines select').nth(1).locator('option[value="BUT"]').is_disabled();page.locator('#lines').evaluate("el=>el.scrollIntoView({block:'center'})");caption('3 · Quyết định UX của người học','Bỏ gộp dòng, ngăn chọn hàng đã có trên phiếu. Khi hết danh mục, không thêm dòng; API mock vẫn kiểm trùng phía logic.',11)
  page.click('#save');assert page.locator('#stock tr').first.inner_text().split('\t')[2]=='15'
  page.select_option('#role','manager');assert page.locator('#receiptSection').is_hidden();page.fill('#productId','THUOC');page.fill('#productName','Thước kẻ');page.fill('#productUnit','cây');page.click('#createProduct');assert 'thành công' in page.inner_text('#createMessage');page.locator('#createMessage').evaluate("el=>el.scrollIntoView({block:'center'})");caption('4 · Danh mục và thông báo đúng vị trí','Quản lý tạo mã THUOC với tồn 0. Kết quả hiện ngay dưới nút tạo; Quản lý không thấy phần lập phiếu nhập.',11)
  page.select_option('#manageProduct','BUT');page.click('#deleteProduct');assert 'còn 15 cây' in page.inner_text('#catalogMessage');page.locator('#catalogMessage').evaluate("el=>el.scrollIntoView({block:'center'})");caption('5 · Xóa khi còn tồn bị chặn','Bút còn 15 cây nên không thể xóa. Thông báo nêu rõ mã/tên và số tồn ngay dưới mục đang thao tác.',11)
  page.select_option('#role','keeper');page.select_option('#adjustProduct','BUT');page.fill('#adjustQuantity','15');page.fill('#adjustReason','Kiểm kê: hàng bị hỏng, đề nghị giảm tồn');page.click('#requestAdjustment');assert page.locator('#stock tr').first.inner_text().split('\t')[2]=='15';page.locator('#adjustmentList').evaluate("el=>el.scrollIntoView({block:'center'})");caption('6 · Thủ kho gửi đề nghị, chưa trừ tồn','Đề nghị giảm 15 cây có lý do được ghi ở trạng thái chờ. Tồn vẫn 15; người tạo không tự duyệt trong quy trình nghiệp vụ đã chốt.',11)
  page.select_option('#role','manager');page.get_by_role('button',name='Duyệt DC-1',exact=True).click();assert page.locator('#stock tr').first.inner_text().split('\t')[2]=='0';page.locator('#reviewMessage').evaluate("el=>el.scrollIntoView({block:'center'})");caption('7 · Quản lý duyệt và lưu lịch sử','Duyệt DC-1 giảm tồn về 0, ghi tồn trước/sau và người/giờ demo. Request đã xử lý không được trừ lặp khi gọi tuần tự trên state mới.',11)
  page.select_option('#manageProduct','BUT');page.click('#deleteProduct');page.click('#confirmDelete');assert 'Xóa hàng thành công: BUT' in page.inner_text('#catalogMessage');page.locator('#catalogMessage').evaluate("el=>el.scrollIntoView({block:'center'})");caption('8 · Tồn 0 được xóa dù có lịch sử','Xóa khỏi danh mục đang dùng, báo thành công ngay tại chỗ. Phiếu và lịch sử điều chỉnh được giữ, không xóa dấu vết nghiệp vụ.',11)
  page.reload();page.select_option('#role','manager');assert page.locator('#manageProduct option[value="BUT"]').count()==0;assert 'BUT' in page.inner_text('#history');page.locator('#history').evaluate("el=>el.scrollIntoView({block:'center'})");caption('9 · Tải lại và kiểm tra bằng chứng','Sau reload, Bút không còn trong danh mục nhưng các phiếu nhập vẫn tra cứu được. Đây là demo lưu cục bộ, không phải cơ sở dữ liệu nhiều người dùng.',11)
  page.goto(base+'/knowledge-health/MO-KNOWLEDGE-HEALTH.html');page.select_option('#status','all');page.locator('#metrics').evaluate("el=>el.scrollIntoView({block:'center'})");caption('10 · Knowledge Health c1–c7','Theo dõi trace, freshness, review và decision evidence. c7 được người học chấm 8/8; c2 đo theo 9 đợt gói demo, không giả Git commit.',12)
  page.locator('[data-id="c5"]').evaluate("el=>el.scrollIntoView({block:'center'})");caption('11 · KPI xanh không thay thế approval','c5=100% nghĩa có dấu vết review. API và test scenario vẫn Changes Requested; hướng dẫn được đánh giá tạm ổn. Không coi tất cả artefact đã được phê duyệt.',12)
  page.goto(base+'/prototype/MO-DEMO.html');page.locator('h1').evaluate("el=>el.scrollIntoView({block:'center'})");caption('Giới hạn và bài học','Role selector không chứng minh RBAC/SoD thật. Concurrency, double-click/retry và lỗi storage mở rộng còn Not Tested. AI hỗ trợ xây dựng; con người kiểm chứng và chịu trách nhiệm.',14)
  assert not errors,errors
  video=page.video;context.close();path=video.path();b.close()
  (out/'recording-result.json').write_text(json.dumps({'raw_video':str(path),'duration_observed_seconds':round(time.monotonic()-start,1),'scenes':scenes,'page_errors':errors,'recording':'AI-driven real browser interactions on test profile; no human voice or impersonation; no production data'},ensure_ascii=False,indent=2))
  print('RECORDING_COMPLETE',str(path),flush=True)
finally:server.shutdown()
