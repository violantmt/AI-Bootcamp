# Kịch bản video và phụ đề đã ghi

Video AI quay thao tác thật trên demo, không giả lời thuyết trình người học. Mốc thời gian xấp xỉ theo bản ghi.

## 00:00 — PB-03 · Quản lý kho văn phòng phẩm · Tier 2

Quay trực tiếp bản demo thật bằng thao tác tự động của AI. Dữ liệu giả, phụ đề, không giọng đọc; không thay lời bảo vệ trực tiếp của người học.

## 00:10 — 1 · Kiểm tra dữ liệu nhập

Nhập -3 bị từ chối và không làm thay đổi tồn. Đây là ca sai phải được chặn, không chỉ kiểm happy path.

## 00:21 — 2 · Luồng nhập → lưu → xem lại

Bút ban đầu 10, nhập hợp lệ 3: tồn thành 13, có phiếu và lịch sử. Chỉ báo thành công sau khi lưu cục bộ được.

## 00:32 — 3 · Quyết định UX của người học

Bỏ gộp dòng, ngăn chọn hàng đã có trên phiếu. Khi hết danh mục, không thêm dòng; API mock vẫn kiểm trùng phía logic.

## 00:43 — 4 · Danh mục và thông báo đúng vị trí

Quản lý tạo mã THUOC với tồn 0. Kết quả hiện ngay dưới nút tạo; Quản lý không thấy phần lập phiếu nhập.

## 00:54 — 5 · Xóa khi còn tồn bị chặn

Bút còn 15 cây nên không thể xóa. Thông báo nêu rõ mã/tên và số tồn ngay dưới mục đang thao tác.

## 01:05 — 6 · Thủ kho gửi đề nghị, chưa trừ tồn

Đề nghị giảm 15 cây có lý do được ghi ở trạng thái chờ. Tồn vẫn 15; người tạo không tự duyệt trong quy trình nghiệp vụ đã chốt.

## 01:17 — 7 · Quản lý duyệt và lưu lịch sử

Duyệt DC-1 giảm tồn về 0, ghi tồn trước/sau và người/giờ demo. Request đã xử lý không được trừ lặp khi gọi tuần tự trên state mới.

## 01:28 — 8 · Tồn 0 được xóa dù có lịch sử

Xóa khỏi danh mục đang dùng, báo thành công ngay tại chỗ. Phiếu và lịch sử điều chỉnh được giữ, không xóa dấu vết nghiệp vụ.

## 01:39 — 9 · Tải lại và kiểm tra bằng chứng

Sau reload, Bút không còn trong danh mục nhưng các phiếu nhập vẫn tra cứu được. Đây là demo lưu cục bộ, không phải cơ sở dữ liệu nhiều người dùng.

## 01:50 — 10 · Knowledge Health c1–c7

Theo dõi trace, freshness, review và decision evidence. c7 được người học chấm 8/8; c2 đo theo 9 đợt gói demo, không giả Git commit.

## 02:02 — 11 · KPI xanh không thay thế approval

c5=100% nghĩa có dấu vết review. API và test scenario vẫn Changes Requested; hướng dẫn được đánh giá tạm ổn. Không coi tất cả artefact đã được phê duyệt.

## 02:14 — Giới hạn và bài học

Role selector không chứng minh RBAC/SoD thật. Concurrency, double-click/retry và lỗi storage mở rộng còn Not Tested. AI hỗ trợ xây dựng; con người kiểm chứng và chịu trách nhiệm.

