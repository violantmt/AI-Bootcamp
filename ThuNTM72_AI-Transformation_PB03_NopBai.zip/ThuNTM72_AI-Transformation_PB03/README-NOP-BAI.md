# ThuNTM72 — Bộ bài nộp AI Transformation PB03

## Thành phần theo yêu cầu
1. **ARTIFACTS/**: yêu cầu, WBS, estimate/trade-off, risk, delegation, DoR/DoD, RTM, báo cáo/dashboard EX05, usage/productivity/hallucination logs, viva, review evidence và audit Knowledge Health.
2. **CODEBASE/**: source prototype, API mock/localStorage, schema tham khảo, tests, dashboard Knowledge Health, script build và hướng dẫn chạy.
3. **BAI-THU-HOACH/**: Markdown, Word và PDF cùng nội dung, người thực hiện ThuNTM72. Bản thảo AI hỗ trợ từ quá trình trao đổi, cần người học đọc/chỉnh/xác nhận trước khi nộp.
4. **VIDEO-DEMO/**: video quay màn hình thao tác thật có phụ đề tiếng Việt; không giọng đọc, không giả người học trình bày. Kèm script cảnh và nguồn quay.
5. **VALIDATION/**: log kiểm tra thật và kết quả đối chiếu gói.

## Mở nhanh
- Demo: CODEBASE/prototype/MO-DEMO.html.
- Knowledge Health: CODEBASE/knowledge-health/MO-KNOWLEDGE-HEALTH.html.
- Bài thu hoạch: BAI-THU-HOACH/BAI-THU-HOACH-ThuNTM72.pdf hoặc .docx để sửa.
- Video: VIDEO-DEMO/DEMO-ThuNTM72-PB03.mp4.
Nếu mở HTML trực tiếp bị chính sách trình duyệt chặn, xem CODEBASE/README.md. Các artefact root dùng ../CODEBASE/prototype/ khi trỏ tới code; các bản history giữ nguyên đường dẫn lịch sử để bảo toàn evidence.

## Phạm vi và những điểm chưa đạt/chưa có dữ liệu
Tier 2, dữ liệu giả; demo v10 được người học nghiệm thu. Không có production DB/auth/SoD thật, transaction/locking multi-user hoặc triển khai thật.
API/scenario là Changes Requested theo review PM/BA; guide được đánh giá tạm ổn, không blanket approval. TS15–TS21 (concurrency, double-click/retry, consistency matrix, storage fault) là Not Tested; không biến các test tuần tự cũ thành PASS cho concurrency.
EX05 chưa phát hiện hallucination thật: giữ kết luận trung thực, chưa đủ evidence tiêu chí ≥1 phát hiện thật. Các log trống không bị điền số giả.
90 phút là số người học đã báo tại thời điểm trước, không phải tổng thời gian toàn khóa hoặc từng EX. Token cost/năng suất thực chưa đủ billing/baseline. Adoption31/31 chỉ tập phiên quan sát tại lúc inventory lập, không đại diện doanh nghiệp.
c5=100% có dấu vết review, không phải tất cả artefact Approved. C3 là audit AI sau chuẩn hóa. C7 có chấm từng câu bởi người học trước các lần sửa doc sau đó, không blind benchmark.

Bản Project Health tổng quát đã loại khỏi gói theo yêu cầu. Chỉ Knowledge Health c1–c7 được giữ. Không chứa repository .git, credential, node_modules/browser cache hoặc file ZIP lồng nhau.

## Trước khi nộp
- ThuNTM72 đọc/chỉnh bài thu hoạch, đặc biệt các câu ở ngôi tôi và giới hạn.
- Xem video, kiểm âm thanh nếu người tổ chức yêu cầu có lời thuyết trình; có thể quay lại/thu lời nói của chính mình theo script kèm.
- Giữ rõ các mục Not Tested/Changes Requested, không tự ghi đủ mọi rubric khi chưa có bằng chứng.
- ZIP này được chuẩn bị để người học nộp; chưa gửi tới cổng/người nhận bên ngoài.
