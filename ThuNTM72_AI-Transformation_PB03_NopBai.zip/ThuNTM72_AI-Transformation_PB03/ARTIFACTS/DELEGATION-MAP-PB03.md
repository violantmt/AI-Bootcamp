# Delegation Map PB03 — EX-06 rút gọn

Trạng thái: AI đề xuất; chờ người học review. ≥8 task cho buổi chính; bản đầy đủ cần ≥15 task từ WBS và Risk.
Tier 2: prototype + API mock + schema SQL + test scenario/script. Dữ liệu giả, không kết nối kho thật.
Mức L là quyền AI trong từng task; A/A+ là kiểm soát thông thường/tăng cường. Task nhạy cảm vẫn có thể giữ AI ở L1/L2 và áp A+; không mặc định nâng quyền lên L4.

| ID | Task/output | Nhóm | Mức AI | Leash | Ai duyệt | Cổng kiểm / lý do |
|---|---|---|---|---|---|---|
| T01 | Tóm tắt brief và truy nguồn scope | AI-do | L0 | A | Người học spot-check | So với PB-03; không thêm tính năng thành yêu cầu gốc |
| T02 | Nháp REQ và AC | AI-do | L1 | A | Người học duyệt toàn bộ | Đủ hợp lệ/không hợp lệ, không tự chốt chỗ thiếu |
| T03 | Chốt quy tắc nghiệp vụ và scope | Human-do | L2 hỗ trợ đề xuất | A | Người học quyết | AI nêu lựa chọn; không coi đề xuất là đã chốt |
| T04 | Nháp mô hình dữ liệu và SQL cho sandbox | AI-do | L1 | A | Người học review với giải thích | Có hàng/phiếu/dòng hàng/lịch sử, ràng buộc số lượng; chưa chạy trên DB thật |
| T05 | Nháp ma trận quyền, không áp vào hệ thật | Human-review | L1 | A+ | Người học đích thân duyệt | Giữ thấp dù AI viết được; kiểm ca từ chối, không tự thêm quyền sửa danh mục |
| T06 | Dựng UI nhập phiếu và xem tồn prototype | AI-do | L3 | A | Người học bấm thử | Khớp AC, dữ liệu giả; không tuyên bố mock là bảo mật production |
| T07 | Dựng API mock và lưu dữ liệu demo | AI-do | L3 | A | Người học spot-check | Nhập -3/0/số lẻ bị từ chối, không đổi tồn; nhập hợp lệ có lịch sử |
| T08 | Sinh/chạy test script theo AC | AI-do | L3 | A | Người học đọc kết quả | Báo PASS/FAIL/chưa chạy thật, không bỏ test lỗi để xanh |
| T09 | Tự review chéo REQ/API/UI/test | AI-review | L2 | A | Người học phân xử | Nêu bằng chứng lệch và đề xuất sửa; AI review không thay người nghiệm thu |
| T10 | Nghiệm thu demo và trả lời viva | Human-do | L0 hỗ trợ tóm tắt | A | Người học | Tự thử và giải thích; AI không trả lời thay như bằng chứng hiểu |
| T11 | Nháp quy trình đề nghị/duyệt điều chỉnh tồn (để sau lát cắt đầu) | Human-review | L1 | A+ | Người học đích thân duyệt | Đề nghị chưa duyệt không đổi tồn; thủ kho không tự duyệt; chưa triển khai |
| T12 | Tự quyết điều chỉnh tồn hoặc thay quyền trên kho thật | AI-không-nên | L0, không cấp thực thi | A+ | Chủ hệ thống/người có thẩm quyền | Ngoài quyền bài học; không kết nối hoặc thay dữ liệu thật |

## Người học cần review
- Có task nào giao AI quá nhiều quyền hoặc thiếu cổng kiểm không?
- T05 cố ý giữ ở L1: hãy giải thích rủi ro nếu AI tự quyết quyền cho người dùng.
- Có thể sửa bất kỳ hàng nào; ghi nguyên văn phản biện thực tế vào Decision Log.

## Trạng thái các quyết định
Đã chốt: thủ kho đề nghị điều chỉnh, quản lý duyệt; số lượng nhập là số nguyên >0 trong case văn phòng phẩm; ưu tiên luồng MVP, xem xét barcode sau.
Chưa chốt: ai tạo/sửa danh mục; quyền quản lý đối với luồng nhập; chi tiết điều chỉnh; kế hoạch build và DoR.
Chưa build hoặc chạy test; không đánh dấu Done toàn bài.

## Giải trình do người học viết
> AI có thể tự dựng màn hình demo vì đó là môi trường giả lập an toàn, mang tính kỹ thuật và có thể sửa đổi dễ dàng nếu có sai sót. Ngược lại, việc phân quyền sửa tồn kho ảnh hưởng trực tiếp đến tài sản thực tế và tính bảo mật của doanh nghiệp, đòi hỏi tư duy quản trị rủi ro và trách nhiệm giải trình mà chỉ con người mới có quyền quyết định.

Bằng chứng hiểu T05/T06: người học phân biệt rủi ro demo và quyết định phân quyền tác động tài sản. Đây là giải trình lựa chọn, không phải lỗi AI được sửa; không tự cộng Human-edit. Các hàng khác vẫn là bản nháp cần review, không suy diễn là đã được duyệt toàn bộ.

Cập nhật: người học đã đồng ý quy tắc và phạm vi demo, thêm nút tự động gộp dòng. Không suy diễn thành cấp quyền trên hệ thật.

## Quy tắc hiện hành — bản v2 sau UAT (thay thế quy tắc gộp trước đây)
- Không có nút gộp. Mỗi hàng chỉ một dòng; hàng đã chọn bị vô hiệu hóa ở dòng khác. Thêm dòng tự chọn hàng chưa có; hết hàng thì chặn Thêm dòng; bỏ dòng thì hàng đó được chọn lại.
- Mọi dòng trên phiếu đều phải hợp lệ. Sổ nhập 10 hợp lệ; nếu dòng Bút trống, báo đúng “Dòng 1 (BUT)”, giữ toàn bộ tồn/phiếu chưa lưu. Bỏ dòng chưa dùng rồi lưu.
- Người học đã chọn chỉ Quản lý tạo mã mới; Thủ kho chỉ chọn để nhập. Đây là mở rộng phạm vi và thay thế mô tả quản lý chỉ xem trước đây. Không thêm sửa/xóa danh mục.
- Mã mới duy nhất, chuẩn hóa chữ hoa, tên và đơn vị bắt buộc; tồn khởi đầu 0. Có nhật ký tạo mã trong snapshot demo. API mock POST /api/products: manager 201, keeper 403, dữ liệu sai 400, trùng mã 409.
- Vai trò vẫn chỉ mô phỏng, không phải xác thực hoặc bảo mật production.

## Phạm vi hiện hành v4 — danh mục và giảm tồn (thay thế giới hạn v3)
Quản lý tạo/sửa tên; mã và đơn vị chỉ đổi khi tồn 0 và chưa có phiếu/đề nghị. Mã mới phải duy nhất. Không chỉnh trực tiếp số tồn trong danh mục.
Xóa hẳn cần tồn 0 và chưa sử dụng trong phiếu/đề nghị; phải xác nhận. Hàng có lịch sử dùng “Ngừng sử dụng”: giữ tồn và lịch sử, chặn nhập/đề nghị mới, có thể dùng lại. Còn đề nghị chờ thì phải xử lý trước khi ngừng sử dụng. Nhật ký danh mục giữ trước/sau, người thao tác và thời điểm.
Thủ kho gửi đề nghị giảm tồn: chọn hàng đang dùng, số lượng nguyên >0 và không vượt tồn hiện tại, lý do bắt buộc. Chờ duyệt không đổi tồn. Quản lý duyệt hoặc từ chối (cần lý do). Duyệt kiểm lại tồn hiện tại, trừ đúng một lần, ghi người/giờ duyệt và tồn trước/sau. Không đủ tồn thì giữ chờ, không trừ âm. Từ chối không đổi tồn và không duyệt lại được.
Luồng này dành cho mất/hỏng/chênh lệch kiểm kê, không thay thế luồng xuất kho hàng bán. Tồn demo ban đầu 10 bút/20 sổ là số dư mở đầu; lịch sử phiếu mới thể hiện biến động sau đó.
Role chỉ mô phỏng trên cùng trình duyệt, không có xác thực danh tính thật; chưa hỗ trợ nhiều người/đa tab đồng thời. Đây vẫn là Tier 2, không phải hệ thống kho production.
