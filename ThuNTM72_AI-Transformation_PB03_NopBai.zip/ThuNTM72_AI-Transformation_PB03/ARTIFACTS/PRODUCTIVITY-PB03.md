# So sánh năng suất trước/sau AI — phương pháp và mẫu

Mục tiêu: so effort người cho đầu ra tương đương, không suy năng suất từ token hoặc Adoption.

| Task/nhóm công việc | Scope/AC và độ khó đối chiếu | Baseline không AI (giờ người) | Nguồn baseline: đo thật/ước tính | Có AI: giờ làm + review + rework | Nguồn time log | Chất lượng/gate hai phía | Yếu tố gây lệch | Kết luận |
|---|---|---|---|---|---|---|---|---|

Công thức:
- Compression = baseline giờ / giờ người có AI, mẫu số >0.
- Effort tiết kiệm = baseline − giờ người có AI.
- Tỷ lệ giảm effort = (baseline − giờ người có AI)/baseline ×100%, baseline >0.
Nếu chi phí người có AI cao hơn baseline, báo tiết kiệm âm, không giấu rework.
Chỉ tính khi hai bên cùng scope và chuẩn chất lượng. Baseline ước tính phải ghi est, không trình bày thành đo thực nghiệm; lưu người ước lượng và giả định. Nên dùng nhóm task tương đương, ghi khác biệt người làm/độ quen/công cụ và thiên lệch do học lại.
Không vừa cộng giờ review/rework riêng vừa tính lại nếu tổng giờ đã bao gồm chúng. Chi phí tiền cần thêm đơn giá lao động và chi phí công cụ/token thật.

## Dữ liệu hiện có
- Thực hành: người học báo tổng 90 phút; không có baseline không AI hoặc phân bổ task → Compression/effort tiết kiệm thực tế N/A.
- INPUT-W3 giả lập: khoảng 1,5 MD tiết kiệm theo đề; không có baseline/actual cùng scope → không suy Compression từ đó.
- Không dùng 90 phút để so trực tiếp với MD dự án production hoặc 1,5 MD giả lập.
