# Báo cáo tuần 3/8 — bài giả lập EX-05
Nguồn: INPUT-W3.md, dữ liệu Workbook; không phải báo cáo tiến độ thật.

**Tiến độ:** Kế hoạch hoàn thành module #1 và #2. Module #1 đã xong; module #2 trễ 1 ngày do logic nghiệp vụ phức tạp hơn dự kiến. Chưa có xác nhận module #2 hoàn tất hoặc mốc mới. Không suy 1/2 module thành 50% effort toàn dự án.

**Chất lượng:** Còn 3 bug mở (2 UI, 1 logic); chưa có severity, owner hoặc trạng thái xử lý chi tiết.

**Đóng góp AI:** hỗ trợ sinh CRUD; tiết kiệm khoảng 1,5 MD và token tuần khoảng 120k theo ước tính đề bài. Chưa đủ dữ liệu tính chi phí tiền, tỷ lệ adoption hay năng suất thực.

**Rủi ro mới:** tài liệu API bên thứ ba chưa tốt. Cần xác minh tích hợp nào và ảnh hưởng; không tự thêm tích hợp vào MVP PB03.

**Kế hoạch tuần tới — AI đề xuất, chưa được duyệt:** làm rõ logic để lập lại kế hoạch module #2; phân loại/đánh giá severity của 3 bug và xử lý theo rủi ro; làm rõ tài liệu API; bổ sung nguồn dữ liệu KPI. Chưa hứa đóng hết bug hoặc ngày hoàn tất khi chưa có effort.

**Quyết định người học:**
Tuần tới, mình sẽ ưu tiên phân tích nguyên nhân module #2 trễ tiến độ, làm rõ các vấn đề logic và đánh giá mức độ nghiêm trọng của 3 bug để ưu tiên xử lý theo mức độ ảnh hưởng đến nghiệp vụ.
Đồng thời, mình sẽ làm việc với bên liên quan để bổ sung tài liệu API còn thiếu, đánh giá tác động đến tiến độ và cập nhật Risk Register.
Về AI adoption, mình sẽ tiếp tục theo dõi effort tiết kiệm và token usage, nhưng chỉ báo cáo các KPI có dữ liệu kiểm chứng, không tự suy diễn số liệu còn thiếu.

Ghi chú chỉ số: AI Adoption = task dùng AI/tổng task; effort tiết kiệm và token là chỉ số khác, chưa có đủ dữ liệu để tính Adoption. Việc bổ sung API là hành động trong case giả lập, không phải đã liên hệ bên thứ ba hoặc đã thêm tích hợp vào scope PB03.

**Thu thập KPI — người học bổ sung:** kiểm usage/billing công cụ để xác định token cost; khi chưa truy xuất được, ghi nguồn và cách thu cho phiên sau. Adoption cần inventory task từ REQ/WBS/EST/RISK/WEEKLY, gộp trùng và đối chiếu tương tác/artefact trước phân loại AI-assisted/Non-AI/Unknown. Chưa trộn dữ liệu thực hành với dữ liệu tuần giả lập; chưa tự thay giá trị N/A bằng số chưa kiểm chứng.

**Kết quả kiểm chứng EX-05:** Người học xác nhận chưa phát hiện hallucination trong nội dung đã rà soát. Không tạo lỗi giả để đủ tiêu chí. Yêu cầu Workbook về ≥1 phát hiện thật hiện chưa có bằng chứng; không ghi đã đạt.
