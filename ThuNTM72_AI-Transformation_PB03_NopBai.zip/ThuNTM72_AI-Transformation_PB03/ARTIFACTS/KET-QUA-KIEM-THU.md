# Kết quả v2
- `node ../CODEBASE/prototype/test.mjs`: 18 tests, 18 pass, 0 fail, 0 skipped. Gồm Sổ 20+10, chỉ rõ dòng sai, atomic phiếu, API quyền, tạo mã mới/duplicate/audit.
- `python ../CODEBASE/prototype/test_browser.py`: PASS Chromium trên bản MO-DEMO.html qua HTTP: nhập hợp lệ/sai, chỉ rõ dòng Bút trống, Sổ lên 30, chọn hàng không trùng/hết mã/bỏ dòng, tải lại, manager không ghi phiếu; manager tạo mã mới, tải lại và thủ kho nhập mã mới được; không lỗi JS, mobile 390px không tràn ngang.
- Browser cloud chặn file:// bằng chính sách quản trị; nhấp đúp file trên máy cá nhân cần người học xác nhận.
- Chưa chạy SQL thật (Tier 2), lỗi/quota storage hoặc đa tab ghi đồng thời. Không dùng demo cho kho thật.
- UAT bản v2 của người học: CHỜ; không coi test AI là nghiệm thu người học.

V3: 18 test logic đạt; Chromium regression đạt thêm kiểm ẩn Lập phiếu nhập cho Quản lý/chưa chọn role, hiện lại Thủ kho và thông báo tạo mã vẫn hiển thị.

V4: 25 tests logic đều pass. Chromium regression đạt thêm: gửi đề nghị không giảm tồn, quản lý duyệt giảm đúng, từ chối có lý do, tải lại giữ lịch sử; sửa tên/đổi mã hàng mới, giữ lựa chọn sau đổi mã, chặn xóa có lịch sử, xóa hàng mới, ngừng sử dụng/khôi phục; không lỗi JS hoặc tràn ngang mobile 390px. Kiểm direct-file trên máy người học và UAT v4 vẫn chờ. Chưa kiểm/khẳng định chống ghi đè đa tab, danh tính thật, SQL production hoặc quota storage.

V5: 25 tests logic pass, 0 fail; Chromium regression pass, gồm đúng hai nút sửa/xóa, thông báo tại chỗ, chặn xóa tồn và hiển thị số tồn, xóa mã mới, clear thông báo khi đổi lựa chọn, luồng giảm tồn và mobile không tràn ngang. Chưa có UAT người học v5.

V6: thay đổi UI, logic nghiệp vụ giữ kết quả 25 test của v5 (không chạy lại). Chromium regression mới đạt: xóa và phản hồi mã/tên, focus/viewport, giữ thông báo khi đổi lựa chọn, hủy xóa có thông báo; lỗi còn tồn tại chỗ; các luồng nhập, giảm tồn, phân quyền và mobile vẫn đạt. UAT v6 người học chờ xác nhận.

V7: 27 test logic pass, 0 fail, 0 skipped. Chromium regression pass gồm duyệt giảm Bút về 0, xóa thành công/thông báo tại chỗ, không còn mã trong danh mục sau reload, phiếu và lịch sử điều chỉnh vẫn còn. Chặn còn tồn và đóng đề nghị chờ sau xóa đã có test logic. Không tuyên bố đã có nghiệm thu người học v7 hoặc DB production.

V8: Chromium regression mới PASS, kiểm còn tồn báo lỗi không mở xác nhận; tồn 0 mở xác nhận trong trang; hủy không xóa; xác nhận xóa thành công có mã/tên, focus/viewport tại mục; xóa Bút về 0 có lịch sử và reload vẫn giữ lịch sử. Logic model không đổi so với v7 (27 tests đã chạy trước); UAT người học v8 CHỜ.

V9: Chromium regression PASS, bổ sung kiểm thành công tạo mã, lỗi trùng/thiếu mã tại createMessage, vị trí trực tiếp sau nút Tạo mã hàng và focus; xóa/giảm tồn/role/reload/mobile vẫn đạt. Không đổi model nghiệp vụ; giữ bằng chứng 27 tests logic của v7, không chạy lại cho thay đổi UI này.

V10: Chromium regression mới PASS: duyệt thành công và giảm đúng tồn, từ chối thiếu lý do hiện lỗi tại reviewMessage, từ chối có lý do hiện thành công/giữ lịch sử, khung trực tiếp dưới adjustmentList và focus đúng. Các luồng cũ, reload/mobile vẫn pass. Logic model không đổi, không chạy lại suite 27 tests cho thay đổi UI này.
