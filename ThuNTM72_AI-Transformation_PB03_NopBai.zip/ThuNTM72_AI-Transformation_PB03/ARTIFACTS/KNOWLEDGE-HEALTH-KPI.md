# Knowledge Health KPI PB03 — trọng tâm c1–c7

Nguồn khung: AI-Transformation-Program.md §8.2. Audit snapshot ngày 31/10/2026 theo Asia/Saigon, phạm vi demo v10 và hồ sơ trực tiếp liên quan.
Dashboard standalone: knowledge-health/MO-KNOWLEDGE-HEALTH.html. Dashboard Project Health tổng quát đã được bỏ khỏi bộ đang dùng theo yêu cầu người học; bản cũ lưu ở history/retired-project-health, không đóng gói cùng Knowledge Health.

## Inventory cố định và mức tin cậy
- Requirement: 10 KH01–KH10, module: 5, bảng trong RTM-DEMO-V10.md. Đây là tập quan trọng cho demo được AI chọn công khai, cần người học spot-check; không phải tất cả requirement MVP production.
- Tài liệu: 10 artefact lõi liệt kê trong ARTEFACT-AUDIT.md. Không tính history, log lịch sử hay chính file audit/dashboard mới vào mẫu số.
- Thay đổi lớn: 11 mục trong DECISION-AUDIT.md, nối record thực trong Decision Log.
- Retrieval: 8 câu trong RETRIEVAL-SPOTCHECK.md đã được người học chấm riêng từng câu, tổng 8/8.
- AI thực hiện audit file và kiểm sự tồn tại test/record. Không dùng AI tự xác nhận thay cho phê duyệt độc lập của người học.

| KPI | Số ban đầu | Công thức/phạm vi | Target tài liệu | Hành động |
|---|---|---|---|---|
| c1 · Traceability Coverage | 10/10 = 100% | Req có trace yêu cầu → WBS → code → test / tổng req quan trọng ×100% | Target ≥80%. Audit AI; trace tồn tại không thay cho test pass/approval. | Duy trì RTM khi đổi yêu cầu/code/test; người học spot-check các dòng. Không thêm requirement tương lai vào mẫu số demo. |
| c2 · Change Coupling (theo đợt demo) | 9/9 = 100% | Đợt phiên bản có code đổi và doc liên quan đổi / đợt code đổi có ảnh hưởng doc ×100% | Target ≥70%. Đơn vị đo: 9 đợt v1→v10, audit hồi cứu theo gói bàn giao; không phải original Git commit. | Giữ code/doc cùng change ID từ lần sửa tiếp theo; kiểm tính đúng tài liệu qua c3 riêng. Nếu cần đo theo commit/PR production, thu evidence theo đơn vị đó, không suy từ gói demo. |
| c3 · Freshness | 10/10 =100% | Doc fresh, trạng thái hiện hành nhất quán / tổng doc trong inventory ×100% | Target ≥85%. Sau chuẩn hóa 8 doc, audit AI thấy 10/10 nhất quán; cần người học báo finding nếu còn. | Giữ version hiện hành duy nhất, archive lịch sử, cập nhật docs khi rule/code đổi; review lại finding người học, không chỉ thêm ghi chú cuối file. |
| c4 · Orphan Rate | 0/15 = 0% | (Req thiếu code/test + module thiếu doc)/(10 req +5 module) ×100% | Target ≤15%. Chỉ sự tồn tại liên kết; doc cũ vẫn bị c3 cảnh báo. | Khi thêm chức năng, tạo req/code/test/doc cùng lúc; kiểm module mới và orphan. Đừng xóa req khỏi scope để làm tỷ lệ đẹp. |
| c5 · Review Evidence | 10/10 =100% (review trace) | Artefact có trace review người / tổng artefact trong inventory ×100% | Target ≥90%. 10/10 có dấu vết review, KHÔNG phải 10/10 Approved; API/scenario còn Changes Requested. | Giữ review source/version và phản biện. Thực thi test concurrency/double-click/retry/persistence/storage theo kế hoạch, review lại bằng chứng trước đóng finding. Không dùng c5 xanh để tự approve release. |
| c6 · Decision Coverage | 11/11 = 100% | Thay đổi lớn có ADR/Decision Log / tổng thay đổi lớn đã xác định ×100% | Target ≥75%; 11 thay đổi demo được công bố trong inventory. | Giữ rationale, phương án bỏ/chọn và rule hiện hành; gắn mã record ổn định khi đổi lớn. Không coi số record là số lỗi hoặc duyệt production. |
| c7 · Retrieval Quality | 8/8 = 100% | Câu spot-check đúng–đủ–không bịa / tổng câu đã chấm ×100% | Target ≥70%. Đạt 100% trong bộ 8 câu demo v10, được người học chấm từng câu có hướng dẫn. | Giữ nguồn và điểm từng câu; kiểm lại khi đổi tài liệu/code. Mở rộng tập câu ngoài những câu đã luyện để giảm thiên lệch; không suy 100% thành đúng mọi truy vấn. |

## Findings và thứ tự khắc phục
1. c3: tám file REQ/WBS/EST/RISK/DoR/API/scenario/hướng dẫn còn trộn trạng thái cũ/mới. Viết lại bản hiện hành, chuyển phần lịch sử sang history, giữ nguồn và các quyết định. Không chỉ thêm một ghi chú cuối file. Chưa tự coi việc có kế hoạch sửa là đã fresh.
2. c5: ba artefact API, scenario và hướng dẫn chưa thấy review người trực tiếp. Cho người học đọc, phản hồi và lưu trace gắn đúng phiên bản. Review một phần đã có được tính như trace, không nói toàn bộ file đã được duyệt.
3. c2: 9/9 cặp archive revision có cả code và doc đổi, được kiểm bằng hash và lưu PACKAGE-CHANGE-AUDIT.json. Đây là proxy package-level, chưa chứng minh cùng change set thực thi nên KPI chính vẫn N/A. Từ phiên sau gắn change ID, code/doc diff cùng commit hoặc bản ghi thay đổi đáng tin.
4. c7: người học chấm 8 câu (đúng/đủ/không bịa=1, còn lại=0), ghi finding/nguồn, tính số đạt/8. AI không tự chấm câu trả lời mình để tạo 100%.
5. c1/c4: RTM mới được lập trong lần audit này đã nối code/test hiện hữu. C1 đạt 100% và c4 0% là độ nối trong population đã chọn, không chứng minh code đúng, test vừa chạy lại hoặc doc fresh. Người học cần spot-check.
6. c6: 11/11 record có dấu vết thực; giữ lý do và version khi đổi lớn. Không đồng nhất record với lỗi AI hoặc approval production.

## Ngưỡng màu
Xanh theo target tài liệu: c1≥80, c2≥70, c3≥85, c4≤15, c5≥90, c6≥75, c7≥70 (%).
Dải vàng do AI đề xuất để hiển thị: c1 60–<80; c2 50–<70; c3 70–<85; c4 >15–30; c5 75–<90; c6 50–<75; c7 50–<70. Ngoài dải là đỏ; thiếu số/den=0 là xám, không tính thành 0%.
Không có điểm tổng bình quân; xám/đỏ phải nhìn riêng. Ngưỡng còn cần người phụ trách thống nhất, không phải SLA đã ký.

## Quản lý snapshot
Giữ inventory và evidence khi cập nhật; nếu đổi scope/mẫu số ghi rõ lý do và version, không so xu hướng giữa hai population khác nhau như cùng một phép đo. Dữ liệu được cập nhật bằng tay, không đồng bộ Git/CI và không tự đọc file nguồn khi mở HTML. Xuất JSON có timestamp để lưu lịch sử. Chưa có biểu đồ trend vì chưa có chuỗi audit đã kiểm chứng.

## Cập nhật c7 sau chấm đầy đủ
Người học đã chấm từng câu 1–8 đạt 1 điểm sau xem nguồn, c7=100% đạt target trong tập demo v10. Đây là kiểm có hướng dẫn, không phải blind benchmark. Thay thế các trạng thái c7 chưa chấm ở snapshot ban đầu; c2 còn thiếu evidence, c3=20% và c5=70% chưa được khắc phục.

## Cập nhật c2 — đơn vị đợt phiên bản
Đã dựng 9 change set hồi cứu từ diff archive v1–v10, đối chiếu code và phần doc liên quan đúng chủ đề. C2 theo đợt phiên bản =9/9=100%. CHANGESET-REGISTER có patch/SHA để kiểm lại. Cập nhật này thay trạng thái c2 N/A trong snapshot ban đầu nếu dùng đơn vị đợt demo. Không có original Git history, không chứng minh cùng timestamp hoặc chính sách PR production; c3 vẫn 20% vì doc còn nội dung cũ.

## Snapshot v3 — c3/c5
Đã chuẩn hóa8 file và audit10/10fresh theo inventory cũ; trước/sau có archive/SHA. c5 vẫn7/10 chờ review trực tiếp ba mục trong REVIEW-PACKET-PB03.md; không tự ký người học. c7 8/8 là lần chấm trước refresh, chưa tự retest.

## Snapshot v4 — Review evidence có điều kiện
Người học review API/scenario từ góc nhìn PM/BA, yêu cầu sửa/bổ sung; hướng dẫn được đánh giá tạm ổn. c5=100% vì có trace10/10, không phải tất cả Approved. Contract làm rõ mock không chứng minh RBAC/SoD/concurrency. TS15–TS21 được bổ sung nhưng Not Tested. c3 vẫn10/10 nhất quán, không coi đặc tả test mới là evidence chạy đạt.
