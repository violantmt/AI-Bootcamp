# Viva mini PB03

## Câu 1 — AI sai/thiếu ở đâu, bạn phát hiện và sửa thế nào?
Trạng thái: người học đã chọn và xác nhận câu trả lời dưới đây. Nguồn: bản AI gợi ý dựa trên các phản hồi UAT thực tế; không phải bằng chứng trả lời tự phát hoặc đã bảo vệ miệng.

1. **Vấn đề:** Khi quản lý xóa một mặt hàng, thông báo kết quả chưa rõ và khó nhận biết, khiến mình không chắc hệ thống đã xóa thành công hay chưa.
2. **Cách mình phát hiện:** Mình trực tiếp thử xóa hàng trên demo và quan sát phần giao diện bên dưới nút Xóa. Mình chưa thấy phản hồi đủ rõ nên đã báo lại cho AI.
3. **Mình yêu cầu sửa:** Hiện thông báo ngay dưới mục đang thao tác, ghi rõ mã và tên hàng đã xóa. Nếu không xóa được thì phải giải thích lý do, chẳng hạn vẫn còn hàng tồn kho.
4. **Kết quả sau khi thử lại:** Sau các lần chỉnh sửa và kiểm tra demo, mình thấy phản hồi thao tác rõ ràng hơn và xác nhận demo đã ổn.

## Câu 2 — Vì sao giao dựng prototype L3, còn quyết định phân quyền do con người chốt?
Tái sử dụng nguyên văn giải trình người học đã tự cung cấp trước đó; không yêu cầu trả lời lại cùng nội dung:
> AI có thể tự dựng màn hình demo vì đó là môi trường giả lập an toàn, mang tính kỹ thuật và có thể sửa đổi dễ dàng nếu có sai sót. Ngược lại, việc phân quyền sửa tồn kho ảnh hưởng trực tiếp đến tài sản thực tế và tính bảo mật của doanh nghiệp, đòi hỏi tư duy quản trị rủi ro và trách nhiệm giải trình mà chỉ con người mới có quyền quyết định.

Liên hệ kỹ thuật do AI giải thích: dựng prototype trong giới hạn tương ứng L3; AI chỉ nháp/đề xuất chính sách quyền ở L1/L2, người học chốt. Role trong demo là mô phỏng, không phải hệ thống bảo mật doanh nghiệp đã triển khai.

## Câu 3 — Cổng nào gác output, nếu đỏ thì làm gì?
Người học đã chọn và xác nhận câu trả lời cuối cùng dưới đây. Đây là bản AI gợi ý dựa trên thực hành rồi được người học xác nhận, không phải chứng cứ bảo vệ miệng tự phát.

1. **Trường hợp này chưa đạt**, vì hàng vẫn còn tồn nhưng hệ thống cho xóa là vi phạm quy tắc nghiệp vụ đã chốt. Việc hiện thông báo thành công không chứng minh thao tác đó đúng.
2. **Mình sẽ yêu cầu AI sửa và kiểm thử lại cả hai trường hợp:** còn tồn thì chặn xóa, thông báo rõ số lượng còn lại; tồn bằng 0 thì cho xóa và báo thành công ngay dưới mục thao tác. Sau khi AI báo kết quả kiểm thử, mình sẽ trực tiếp thử lại demo. Nếu còn sai hoặc chưa kiểm chứng được thì chưa nghiệm thu.

Lưu ý: “còn tồn nhưng cho xóa” là tình huống giả định của câu hỏi; không ghi thành lỗi đã xảy ra trên demo thực tế.

## Tạm dừng sau UAT mới
Người học phản hồi chưa đạt yêu cầu thông báo xóa. Đoạn “kết quả sau khi thử lại…đã ổn” phía trên là câu trả lời từng được chọn, không được dùng làm bằng chứng đã nghiệm thu v8. Chờ thử lại trước khi hoàn thiện câu 1 hoặc tiếp câu 2.

## Tiếp tục sau nghiệm thu v10
Người học: “Mình nghĩ demo ok rồi đó, bạn tiếp các bước tíep theo trong tài liệu nhé”. Ghi nhận nghiệm thu demo hiện hành, kết thúc trạng thái tạm dừng UAT trước đây. Câu 1 giữ nội dung người học đã chọn; câu 2 dùng giải trình thực tế trước đó; câu 3 và telemetry còn chờ. Không coi xác nhận demo là đã hoàn thành mọi tiêu chí bài.

## Trạng thái hiện hành
Đã có câu trả lời được người học chọn cho câu 1 và câu 3; câu 2 tái sử dụng giải trình trước đó. Những dòng chờ/tạm dừng ở các mục lịch sử đã được thay thế bởi trạng thái này. Chưa có bảo vệ miệng độc lập. Telemetry và rà hồ sơ còn chờ.
