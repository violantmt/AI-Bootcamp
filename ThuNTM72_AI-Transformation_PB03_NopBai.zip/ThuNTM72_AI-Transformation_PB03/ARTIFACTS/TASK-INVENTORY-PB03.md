# Task inventory và AI Adoption — phiên thực hành PB03

## Phạm vi và quy tắc đếm
Kỳ: từ lúc học tài liệu ZIP đến yêu cầu tổng hợp task trong cuộc trò chuyện hiện tại. Chỉ xét việc học/thiết kế/lập kế hoạch/dựng demo/tổng hợp hồ sơ có dấu vết trong phiên này. Loại onboarding repository trước khi nhận ZIP và việc người học có thể làm ngoài hội thoại vì chưa được quan sát.
Đơn vị: một đầu ra hoặc luồng công việc có thể kiểm lại, không đếm từng tin nhắn, từng file sinh ra hoặc mỗi bản v1–v10 thành task riêng. Tài liệu nhiều nguồn cùng nói về một task chỉ map tới một ID. Task In progress tính khi đã thực sự tạo đầu ra/làm việc trong kỳ; chưa duyệt cuối không đồng nghĩa chưa dùng AI.
Định nghĩa AI-assisted: AI có đóng góp trực tiếp cho đầu ra hoặc hỗ trợ task bằng thiết kế/scenario/review. Human-do không đồng nghĩa Non-AI: người quyết/kiểm vẫn có thể dùng AI hỗ trợ. Non-AI chỉ khi có bằng chứng task trong kỳ thực hiện không nhờ AI. Unknown khi task đã thực hiện nhưng mức dùng AI chưa xác minh.
Inventory là hồi cứu dựa hội thoại và file, chưa có git diff/commit/time log theo task. Evidence ở cột bên dưới là artefact + sự kiện có trong cuộc trò chuyện; không giả commit hay prompt export. Skill/rule cụ thể cho từng task chưa xác minh, không dùng chúng làm căn cứ tính tỷ lệ. Bản log mẫu task PB03-UI-REVIEW-MSG được gộp vào A12, không tính thêm.
Đây là inventory bao phủ các nhóm việc được quan sát trong phiên, không khẳng định đầy đủ công việc ngoài hội thoại/của doanh nghiệp. Người học cần báo nếu có task riêng chưa ghi nhận; khi đó cập nhật mẫu số và phân loại.

## Task đã thực hiện hoặc đang thực hiện có đầu ra
| ID | Nhóm | Task chuẩn | Trace nguồn (không đếm thêm) | Evidence file | Evidence tương tác/đóng góp AI | Tiến độ | Phân loại |
|---|---|---|---|---|---|---|---|
| A01 | Chuẩn bị | Chọn PB03/Tier 2 và lộ trình học | REQ/WBS 1.1 | [HUONG-DAN.md](HUONG-DAN.md) | AI đề xuất PB03 cho người chưa code; người học chọn đề dễ | Done | AI-assisted |
| A02 | Yêu cầu | Viết/review yêu cầu, scope, AC và làm rõ nghiệp vụ | REQ; WBS 1.1 | [REQ-PB03.md](REQ-PB03.md); [RA-SOAT-EX01-PB03.md](RA-SOAT-EX01-PB03.md) | AI nháp; người học chốt số nguyên, quyền, điều chỉnh và giữ phiếu gốc | In progress: cần bản REQ sạch | AI-assisted |
| A03 | Yêu cầu | Phản hồi stakeholder đòi barcode | REQ scope simulation | [REQ-PB03.md](REQ-PB03.md) | AI đưa simulation; người học viết phản hồi bảo vệ scope | Done | AI-assisted |
| A04 | Quản trị | Lập/review Delegation Map rút gọn | WBS 1.1;RISK R04/R14 | [DELEGATION-MAP-PB03.md](DELEGATION-MAP-PB03.md) | AI lập 12 task; người học giải thích demo/phân quyền | Done: bản thực hành | AI-assisted |
| A05 | Thiết kế | Chốt DoR và kế hoạch build | WBS 1.2 | [DOR-PB03.md](DOR-PB03.md) | AI trình luồng; người học đồng ý kèm clarification gộp dòng | Done: demo | AI-assisted |
| A06 | Thiết kế | Thiết kế API contract mock | WBS 1.2;RISK R04 | [API-PB03.md](API-PB03.md) | AI viết endpoint/response và cập nhật theo scope | Done: mock contract | AI-assisted |
| A07 | Thiết kế | Viết schema SQL tham khảo | WBS 1.2;EST E01 tham chiếu | [../CODEBASE/prototype/schema.sql](../CODEBASE/prototype/schema.sql) | AI viết schema, người học không phải viết code; chưa chạy DB thật | Done: tài liệu thiết kế | AI-assisted |
| A08 | Demo | Dựng và sửa luồng danh mục tạo/sửa/xóa | WBS 1.3;REQ US01;RISK R07 | [../CODEBASE/prototype/model.mjs](../CODEBASE/prototype/model.mjs); [../CODEBASE/prototype/app.mjs](../CODEBASE/prototype/app.mjs) | Người học yêu cầu quyền quản lý, đơn giản hóa nút, xóa tồn 0; AI code và sửa | Done: demo | AI-assisted |
| A09 | Demo | Dựng/sửa nhập phiếu nhiều dòng và kiểm số lượng | WBS 1.4;REQ US02;RISK R03 | [../CODEBASE/prototype/model.mjs](../CODEBASE/prototype/model.mjs); [../CODEBASE/prototype/app.mjs](../CODEBASE/prototype/app.mjs) | AI code; người học báo Sổ 10 và chọn ngăn trùng thay gộp | Done: demo | AI-assisted |
| A10 | Demo | Dựng luồng đề nghị giảm tồn, duyệt/từ chối | WBS 1.5;RISK R05 | [../CODEBASE/prototype/model.mjs](../CODEBASE/prototype/model.mjs); [../CODEBASE/prototype/app.mjs](../CODEBASE/prototype/app.mjs) | Người học chốt thủ kho đề nghị/QL duyệt; AI xây flow | Done: demo | AI-assisted |
| A11 | Demo | Hiển thị theo role, tồn/lịch sử và lưu tải lại | WBS 1.3–1.5;RISK R04/R07 | [../CODEBASE/prototype/app.mjs](../CODEBASE/prototype/app.mjs); [../CODEBASE/prototype/index.html](../CODEBASE/prototype/index.html) | AI dựng localStorage/UI; người học yêu cầu ẩn lập phiếu của quản lý | Done: demo | AI-assisted |
| A12 | Demo | Cải thiện phản hồi thao tác tại đúng mục | REQ cập nhật v5–v10;RISK R09 | [../CODEBASE/prototype/app.mjs](../CODEBASE/prototype/app.mjs); [../CODEBASE/prototype/index.html](../CODEBASE/prototype/index.html) | Người học review thông báo xóa/tạo/duyệt; AI sửa, không đếm mỗi vòng một task | Done: demo v10 | AI-assisted |
| A13 | Kiểm thử | Viết kịch bản và chạy logic regression | WBS 1.6;RISK R10/R11 | [TEST-SCENARIOS-PB03.md](TEST-SCENARIOS-PB03.md); [../CODEBASE/prototype/test.mjs](../CODEBASE/prototype/test.mjs) | AI viết/chạy test; kết quả 27 test đã được ghi trong phiên | Done: model demo | AI-assisted |
| A14 | Kiểm thử | Chạy browser regression, kiểm mobile và sửa lỗi tự phát hiện | WBS 1.6;RISK R09/R11 | [../CODEBASE/prototype/test_browser.py](../CODEBASE/prototype/test_browser.py); [KET-QUA-KIEM-THU.md](KET-QUA-KIEM-THU.md) | AI chạy Chromium, log có trong hội thoại, sửa selection/mobile; không phải UAT người dùng thật | Done: v10 browser | AI-assisted |
| A15 | Nghiệm thu | Người học thử demo, báo vấn đề và nghiệm thu lại | WBS 1.7;RISK R09 | [DECISION-LOG-PB03.md](DECISION-LOG-PB03.md) | Người học báo lỗi trực tiếp, AI cung cấp scenario/hỗ trợ và sửa; đã xác nhận v10 ổn | Done: người học, không phải thủ kho thật | AI-assisted |
| A16 | Hồ sơ | Viết hướng dẫn mở demo và đóng gói các bản | WBS 1.8 | [BAT-DAU-DEMO.md](BAT-DAU-DEMO.md); [../CODEBASE/prototype/MO-DEMO.html](../CODEBASE/prototype/MO-DEMO.html) | AI tạo standalone/ZIP và hướng dẫn; người học mở trên máy | Done: demo v10 | AI-assisted |
| A17 | Hồ sơ | Ghi Decision Log, review evidence và telemetry | WBS 1.8;RISK R14 | [DECISION-LOG-PB03.md](DECISION-LOG-PB03.md); [TELEMETRY-PB03.md](TELEMETRY-PB03.md) | AI tổng hợp; người học cung cấp 90 phút; chưa có usage/cost/baseline thật | In progress: còn dữ liệu thiếu | AI-assisted |
| A18 | Hồ sơ | Soạn câu trả lời viva và ghi xác nhận | WBS 1.8;RISK R14 | [VIVA-PB03.md](VIVA-PB03.md) | Người học tự giải thích quyền; AI gợi ý câu 1/3 và người học chọn bản cuối | Done: câu trả lời viết, không phải viva miệng độc lập | AI-assisted |
| A19 | EX02 | Lập/review WBS và tách hướng dẫn/UAT | WBS;REQ scope | [WBS-PB03.md](WBS-PB03.md) | AI tạo WBS; người học bổ sung/tách 2 việc với lý do | Done: bài lập kế hoạch | AI-assisted |
| A20 | EX03 | Lập estimate 3-point và capacity/sensitivity | EST E01–E14;WBS Wave2 | [EST-PB03.md](EST-PB03.md) | AI tính ngày công; người học đối chiếu capacity/chọn mốc đề xuất | Done: estimate giả định | AI-assisted |
| A21 | EX03 | Trade-off Excel, cập nhật scope/WBS và đề xuất 8 tuần | EST;REQ;WBS 2.6;RISK R01/R02 | [TRADEOFF-PB03.md](TRADEOFF-PB03.md); [history/REQ-PB03-truoc-hoan-excel.md](history/REQ-PB03-truoc-hoan-excel.md) | AI lập phương án; người học chọn hoãn Excel, 8 tuần có điều kiện | Done: kế hoạch, không phải stakeholder đã cam kết | AI-assisted |
| A22 | EX04 | Lập Risk Register và chọn Top5/owner/trigger | RISK;WBS 2.7/2.8 | [RISK-PB03.md](RISK-PB03.md) | AI nháp 14 risk; người học bổ sung mitigation và chốt Top5 | Done: risk planning | AI-assisted |
| A23 | EX04 | Viết DoD với evidence gates | RISK R03/R04/R05/R08/R11 | [DOD-PB03.md](DOD-PB03.md) | Người học yêu cầu review/test/UAT/evidence; AI thành checklist và ghi cổng chưa chạy | Done: tài liệu, không phải các gate đã pass | AI-assisted |
| A24 | EX05 | Viết báo cáo tuần từ input giả lập và quyết định | WEEKLY;RISK R01/R13 | [WEEKLY-W3.md](WEEKLY-W3.md); [INPUT-W3.md](INPUT-W3.md) | AI viết report; người học chọn hành động tuần tới dựa input | Done: report giả lập | AI-assisted |
| A25 | EX05 | Dựng bảng KPI có công thức/nguồn | WEEKLY;EST metrics | [DASHBOARD-PB03.md](DASHBOARD-PB03.md) | AI lập dashboard N/A; người học chỉ đạo kiểm nguồn/adoption/cost | Done: dashboard có trường thiếu | AI-assisted |
| A26 | EX05 | Audit claims với nguồn W3 | WEEKLY;RISK R11 | [CLAIM-AUDIT-W3.md](CLAIM-AUDIT-W3.md) | AI lập bảng nguồn; người học yêu cầu kiểm severity/Adoption/token cost | Done: bảng audit hỗ trợ, không giả review độc lập | AI-assisted |
| A27 | EX05 | Lập inventory/evidence và tính Adoption của phiên | REQ/WBS/EST/RISK/WEEKLY | [AI-USAGE-LOG-PB03.md](AI-USAGE-LOG-PB03.md); [EX05-DATA-COLLECTION.md](EX05-DATA-COLLECTION.md) | Người học yêu cầu log/task inventory; AI tổng hợp và đối soát file | In progress: kết quả hồi cứu cần review | AI-assisted |
| A28 | EX05 | Thiết lập cách đo năng suất trước/sau | EST/WEEKLY metrics | [PRODUCTIVITY-PB03.md](PRODUCTIVITY-PB03.md) | Người học đề xuất baseline trước/sau; AI viết worksheet và giới hạn | Done: phương pháp, chưa đo uplift | AI-assisted |
| A29 | EX05 | Thiết lập Hallucination Log có evidence | WEEKLY;RISK R11 | [HALLUCINATION-LOG-PB03.md](HALLUCINATION-LOG-PB03.md) | Người học yêu cầu prompt/response/source; AI làm mẫu, chưa có hallucination thật | Done: mẫu log, chưa đạt phát hiện thật | AI-assisted |
| A30 | EX05 | Xác định nguồn/cách thu usage-billing và Unknown | WEEKLY metrics;RISK R11 | [EX05-DATA-COLLECTION.md](EX05-DATA-COLLECTION.md) | Người học bổ sung nguồn usage/billing và A/N/U; AI ghi quy trình | Done: kế hoạch dữ liệu, chưa truy xuất billing | AI-assisted |
| A31 | EX06 | Nháp Delegation Map đầy đủ 20 task | WBS;RISK | [DELEGATION-MAP-PB03-FULL.md](DELEGATION-MAP-PB03-FULL.md) | AI đã tạo bản nháp trước khi người học yêu cầu tiếp EX05 | In progress: người học chưa duyệt bản đầy đủ | AI-assisted |

## Kết quả trong phạm vi phiên quan sát
- Task đủ điều kiện: 31.
- AI-assisted: 31; Non-AI được chứng minh: 0; Unknown trong tập đã đối chiếu: 0.
- AI Adoption hồi cứu = 31/(31+0) × 100% = **100%**.

100% chỉ nói mọi task trong inventory này có AI tham gia, không nói AI làm toàn bộ, người học không làm gì, đúng 100%, năng suất tăng 100% hoặc doanh nghiệp đã adoption 100%. Người học vẫn quyết nghiệp vụ, thử demo và nghiệm thu. Kết quả là thống kê có phạm vi/định nghĩa rõ, chờ người học review độ bao phủ; không phải phép đo độc lập của toàn dự án.
Không dùng 100% phiên học để ghi Adoption tuần 3 giả lập. Tuần W3 vẫn N/A vì không có task usage log của case đó. Năng suất/token cost cũng không tự tính từ Adoption này.

## Task kế hoạch/chưa có bằng chứng thực hiện — loại khỏi mẫu số
| ID | Công việc | Trace | Trạng thái | Phân loại sử dụng AI khi thực thi |
|---|---|---|---|---|
| P01 | Backend/DB production | EST E01;WBS 2.1 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P02 | Auth/RBAC/audit thật | EST E02;WBS 2.1 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P03 | Danh mục trên backend thật | EST E03 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P04 | Nhập kho trên DB thật | EST E04 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P05 | Xuất kho và kiểm đồng thời | EST E05;WBS 2.3 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P06 | Điều chỉnh tăng/giảm gắn phiếu gốc | EST E06;WBS 2.4 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P07 | Cảnh báo tồn tối thiểu/tra cứu thật | EST E07;WBS 2.5 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P08 | Báo cáo tồn theo kỳ thật | EST E08;WBS 2.6a | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P09 | Xuất Excel phase sau | EST E09;WBS 2.6b | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P10 | Integration/security/load trên hệ thật | EST E10;WBS 2.7 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P11 | Triển khai, backup/restore thật | EST E11;WBS 2.8 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P12 | Hướng dẫn thủ kho cho MVP thật | EST E12;WBS 2.9 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P13 | UAT với thủ kho thật | EST E13;WBS 2.10 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P14 | Rework sau UAT thật | EST E14;WBS 2.11 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P15 | Xác minh dữ liệu đầu kỳ/import cần thiết | WBS 2.2;RISK R06 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P16 | Team xác nhận effort, duration, dependency/critical path | EST điều kiện người học;RISK R01/R02 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P17 | Review Risk Register hằng tuần với team thật | RISK lịch review người học | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P18 | Phê duyệt RPO/RTO, test recovery thật | RISK R08 | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P19 | Lấy usage/billing và baseline năng suất thật | WEEKLY;EX05-DATA-COLLECTION | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |
| P20 | Phát hiện hallucination thật đủ evidence | WEEKLY rubric;HALLUCINATION-LOG | Planned/chưa thực hiện được xác minh | Unknown — không đưa vào tỷ lệ phiên |

Các task Pxx được nhắc/ước lượng trong tài liệu không chứng minh đã được thực thi. Việc soạn estimate/risk cho chúng đã tính tại A20/A22, không tính code production của chúng như một đóng góp AI thực tế.

## Đối chiếu yêu cầu nguồn
- REQ: scope/AC ở A02, simulation A03; tính năng demo A08–A12; phần xuất/report/auth thật map Pxx.
- WBS Wave1: A02–A18; Wave2 và EST E01–E14: P01–P14; chính việc tạo WBS/estimate tính A19/A20.
- RISK: A22 lập register, A23 viết cổng; thực thi gate production chưa có, map P10/P11/P13/P16/P17/P18.
- WEEKLY: A24 viết report, A25–A30 KPI/logs; module #1/#2 trong input là dữ liệu giả lập, không nhập vào inventory task thực của phiên.

## Cách duy trì sau phiên
Ghi task ID/scope/status khi bắt đầu; giữ prompt/response và diff/artefact nếu dùng AI; ghi Không khi không dùng với evidence; Unknown nếu chưa đủ. Chốt kỳ rồi gộp ID trùng, rà task thiếu, tính lại A/N/U. Không thay đổi độ hạt chỉ để làm đẹp tỷ lệ.
