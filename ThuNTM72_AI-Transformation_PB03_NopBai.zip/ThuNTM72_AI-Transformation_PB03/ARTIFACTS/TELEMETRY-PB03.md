# Telemetry PB03 — số liệu có căn cứ

| Trường | Giá trị | Nguồn / giới hạn |
|---|---|---|
| Tool | Codex | Công cụ dùng trong phiên; không ghi tên model chưa xác minh |
| Thời gian người học | 90 phút (1,5 giờ) | Người học cung cấp trực tiếp; tổng đọc/trao đổi/thử demo, không phân bổ giả cho từng bài |
| Token in/out | Chưa có dữ liệu | Không tự suy từ số tin nhắn hoặc số phiên bản |
| Vòng chỉnh demo | 9 vòng đóng gói lại, v1 → v10 | Chỉ số phiên bản trong hồ sơ; không đồng nghĩa 9 lần sửa prompt hay 9 lỗi |
| Rework | Có | Thay gộp bằng chặn trùng; đơn giản hóa nút; sửa luồng phản hồi; thay quy tắc xóa tồn 0 |
| Human-edit theo nghĩa sửa/override AI | 12 thay đổi yêu cầu/review được ghi nhận | Danh sách bên dưới; tính thay đổi cụ thể, không tính mọi tin nhắn/nhắc lại hoặc AI tự sửa |
| Lỗi AI thật do người học phát hiện | Chưa chốt tổng theo rubric | Không đồng nhất 12 Human-edit với ≥3 lỗi; một số là mở rộng scope/đổi rule |

## 12 thay đổi có dấu vết người học
1. Yêu cầu nút gộp thay vì chỉ bắt sửa tay.
2. Thay gộp bằng không cho chọn hàng trùng.
3. Thêm tạo mã hàng, chỉ Quản lý được tạo.
4. Ẩn phần lập phiếu với Quản lý.
5. Mở rộng cho Quản lý sửa/xóa danh mục.
6. Bổ sung luồng Thủ kho đề nghị giảm tồn, Quản lý duyệt.
7. Đơn giản hóa danh mục thành hai nút và đổi tên mục.
8. Yêu cầu thông báo xóa rõ tại chỗ, gồm mã/tên hàng (các lần nhắc lại cùng yêu cầu tính một thay đổi).
9. Tồn 0 được xóa dù có lịch sử, giữ lịch sử tra cứu.
10. Báo đúng dòng lỗi khi số lượng Sổ hợp lệ nhưng phiếu bị từ chối (báo cáo ban đầu do người học; nguyên nhân phiếu gốc chưa xác minh).
11. Đưa phản hồi tạo mã về dưới mục tạo mã.
12. Đưa phản hồi duyệt/từ chối về dưới lịch sử giảm tồn.

Định nghĩa đếm: thay đổi yêu cầu/UX người học chỉ đạo và AI triển khai; bao gồm thêm phạm vi, không chỉ lỗi. Không dùng số này như bằng chứng người học tự viết code. Người học có thể đính chính cách đếm khi rà hồ sơ.
Không tính bài giả định nhập -3, AI tự bắt lỗi mobile/dropdown, hoặc câu trả lời viva AI gợi ý thành lỗi người học bắt.
Chưa tính KPI nén/năng suất/chi phí token vì thiếu baseline/token/đơn giá. Không gán số 0 cho dữ liệu thiếu.
