# DoR PB03 — Prototype Tier 2

Trạng thái: DRAFT, chưa được người học chốt kế hoạch; chưa build.

## Luồng đề xuất
Thủ kho demo chọn bút/sổ có sẵn → nhập phiếu nhiều dòng → API mock kiểm tra → lưu dữ liệu demo → xem tồn và lịch sử.
Không làm xuất kho, barcode, sửa danh mục hoặc điều chỉnh kiểm kê ở lát cắt đầu. Các chức năng MVP còn lại chưa triển khai, không coi là đã hoàn thành.

## Thiết kế đề xuất
- HTML/CSS/JavaScript chạy trong trình duyệt, không cần người học viết code.
- API mock có contract rõ, dữ liệu giữ trong localStorage để tải lại vẫn xem được; không có backend production, không lưu dữ liệu thật.
- GET /api/products: danh sách hàng và tồn; GET /api/receipts: phiếu/lịch sử; POST /api/receipts: gửi {lines:[{productId, quantity}]}.
- Thành công 201 trả phiếu và tồn mới; 400 dữ liệu sai; 401 chưa chọn người dùng demo; 403 role không được nhập. Đây là mô phỏng HTTP, không tuyên bố có server/auth thật.
- Mỗi dòng: hàng tồn tại, số lượng nguyên >0; kiểm toàn bộ phiếu trước khi cập nhật, không lưu nửa chừng.
- Trùng hàng trong cùng phiếu: đề xuất chặn và yêu cầu gộp thành một dòng; chưa được người học chốt.
- Quyền đề xuất cho demo: thủ kho tạo phiếu/xem tồn/lịch sử; quản lý chỉ xem tồn/lịch sử trong lát cắt này. Không suy diễn thành chính sách thật đã được duyệt.
- Schema SQL tham khảo: products, receipts, receipt_lines, audit_events; khóa ngoại, quantity >0, stock >=0; script test kiểm tra số nguyên tại mock. Không chạy migration trên hệ thật.

## Checklist
| Điều kiện | Trạng thái | Bằng chứng / phần còn thiếu |
|---|---|---|
| Đề đơn giản và Tier phù hợp | PASS | PB03 văn phòng phẩm, Tier 2, người học chưa code |
| Luồng hẹp được đề xuất | DRAFT | Nhập → lưu → xem tồn/lịch sử, chờ người học chốt |
| Quy tắc số lượng | PASS về quy tắc | Người học xác nhận số nguyên >0; chưa chạy test |
| API/data | DRAFT | Thiết kế ở trên, cần review rồi triển khai |
| Quyền trong demo | CHỜ CHỐT | Thủ kho nhập, quản lý chỉ xem cho lát cắt đầu |
| Dòng hàng trùng | CHỜ CHỐT | Đề xuất chặn để tránh nhập nhầm |
| Gate | DRAFT | Chạy test theo danh sách dưới và người học bấm thử |
| Ranh giới | DRAFT | Chỉ local/mock/dữ liệu giả; không hệ thật, không push/release |
| Kế hoạch build | CHỜ CHỐT | Trình tự bên dưới; chưa thực hiện |

## Gate dự kiến, chưa chạy
1. Tồn 10 nhập 3 → 13, có phiếu và lịch sử; tải lại vẫn còn.
2. Nhập -3/0/1.5/thiếu hàng → từ chối, tồn không đổi.
3. Phiếu nhiều dòng có một dòng sai → không lưu phiếu, mọi tồn giữ nguyên.
4. Role không được tạo phiếu → từ chối cả ở mock handler, không chỉ ẩn nút.
5. Chưa chọn người dùng demo → từ chối tạo phiếu.
6. Phiếu trùng hàng → theo quy tắc được người học chốt.
7. Mọi AC kiểm thử ghi PASS/FAIL/CHƯA CHẠY trung thực; gate lỗi thì chưa đạt.

## Kế hoạch build đề xuất
1. Chốt quyền demo, cách xử lý hàng trùng và lát cắt.
2. Sinh API contract, schema SQL, test scenario để review.
3. Dựng UI và API mock/lưu dữ liệu demo.
4. Chạy script test; sửa lỗi thật, lưu bằng chứng trước/sau.
5. Hướng dẫn người học mở prototype và tự thử ca hợp lệ/sai/quyền.
6. Người học review, ghi phản biện thực tế, demo và trả lời viva; hoàn thiện telemetry.

Không điền thay giờ thật, không tạo lỗi giả để đủ Decision Log. Chưa có đủ bằng chứng thì chưa đánh dấu hoàn thành bài.

## Cập nhật sau clarification dòng trùng của người học
Người học đồng ý phạm vi/quy tắc demo và yêu cầu có nút “Tự động gộp dòng” thay vì chỉ bắt sửa thủ công. Đây là bổ sung thực tế do người học review, không phải lỗi sản phẩm đã phát hiện.
Quy tắc triển khai: chặn Lưu khi trùng; nút gộp chỉ cộng các dòng hợp lệ cùng mã trong nháp, không tự lưu; dòng sai bị từ chối trước khi cộng. Các chi tiết kiểm tra trước gộp và bấm Lưu riêng do AI cụ thể hóa, người học cần thử/review.
Kế hoạch build đã được người học chấp thuận với bổ sung trên. Đã dựng Tier 2, chạy 17 test logic và kiểm UI Chromium. DoR đủ cho build demo; nghiệm thu người học/hoàn thành toàn bài vẫn chờ. Các trạng thái DRAFT/chưa build ở phần trên là lịch sử trước quyết định này.

## Quy tắc hiện hành — bản v2 sau UAT (thay thế quy tắc gộp trước đây)
- Không có nút gộp. Mỗi hàng chỉ một dòng; hàng đã chọn bị vô hiệu hóa ở dòng khác. Thêm dòng tự chọn hàng chưa có; hết hàng thì chặn Thêm dòng; bỏ dòng thì hàng đó được chọn lại.
- Mọi dòng trên phiếu đều phải hợp lệ. Sổ nhập 10 hợp lệ; nếu dòng Bút trống, báo đúng “Dòng 1 (BUT)”, giữ toàn bộ tồn/phiếu chưa lưu. Bỏ dòng chưa dùng rồi lưu.
- Người học đã chọn chỉ Quản lý tạo mã mới; Thủ kho chỉ chọn để nhập. Đây là mở rộng phạm vi và thay thế mô tả quản lý chỉ xem trước đây. Không thêm sửa/xóa danh mục.
- Mã mới duy nhất, chuẩn hóa chữ hoa, tên và đơn vị bắt buộc; tồn khởi đầu 0. Có nhật ký tạo mã trong snapshot demo. API mock POST /api/products: manager 201, keeper 403, dữ liệu sai 400, trùng mã 409.
- Vai trò vẫn chỉ mô phỏng, không phải xác thực hoặc bảo mật production.

## Cập nhật v3 — Hiển thị theo quyền
Quản lý không thấy section Lập phiếu nhập; chưa chọn role cũng ẩn. Thủ kho thấy lại section khi đổi vai trò. API mock vẫn từ chối Quản lý tạo phiếu với 403. Thông báo chung nằm ngoài section để Quản lý vẫn thấy kết quả tạo mã hàng.

## Phạm vi hiện hành v4 — danh mục và giảm tồn (thay thế giới hạn v3)
Quản lý tạo/sửa tên; mã và đơn vị chỉ đổi khi tồn 0 và chưa có phiếu/đề nghị. Mã mới phải duy nhất. Không chỉnh trực tiếp số tồn trong danh mục.
Xóa hẳn cần tồn 0 và chưa sử dụng trong phiếu/đề nghị; phải xác nhận. Hàng có lịch sử dùng “Ngừng sử dụng”: giữ tồn và lịch sử, chặn nhập/đề nghị mới, có thể dùng lại. Còn đề nghị chờ thì phải xử lý trước khi ngừng sử dụng. Nhật ký danh mục giữ trước/sau, người thao tác và thời điểm.
Thủ kho gửi đề nghị giảm tồn: chọn hàng đang dùng, số lượng nguyên >0 và không vượt tồn hiện tại, lý do bắt buộc. Chờ duyệt không đổi tồn. Quản lý duyệt hoặc từ chối (cần lý do). Duyệt kiểm lại tồn hiện tại, trừ đúng một lần, ghi người/giờ duyệt và tồn trước/sau. Không đủ tồn thì giữ chờ, không trừ âm. Từ chối không đổi tồn và không duyệt lại được.
Luồng này dành cho mất/hỏng/chênh lệch kiểm kê, không thay thế luồng xuất kho hàng bán. Tồn demo ban đầu 10 bút/20 sổ là số dư mở đầu; lịch sử phiếu mới thể hiện biến động sau đó.
Role chỉ mô phỏng trên cùng trình duyệt, không có xác thực danh tính thật; chưa hỗ trợ nhiều người/đa tab đồng thời. Đây vẫn là Tier 2, không phải hệ thống kho production.

## Giao diện hiện hành v5 — thay thế mục nhiều nút của v4
Tên mục: Chỉnh sửa danh mục hàng. Chỉ có hai nút Lưu chỉnh sửa và Xóa hàng; bỏ nút Ngừng sử dụng/Dùng lại khỏi UI.
Kết quả sửa/xóa hoặc lỗi hiển thị ngay dưới hai nút; xóa thông báo cũ khi đổi hàng/sửa trường để không nhầm với thao tác mới.
Xóa vẫn cần xác nhận. Nếu tồn >0: báo “Không thể xóa <mã>: còn <số lượng> <đơn vị> trong kho”. Nếu tồn 0 nhưng có phiếu/đề nghị: chặn và nêu cần giữ lịch sử. Không xóa mất liên kết phiếu.
Các hàng đã ngừng sử dụng từ v4 vẫn giữ trạng thái/dữ liệu; chức năng archive/restore cũ chỉ còn tương thích ở mock, không nằm trên UI v5. Không tự thay trạng thái dữ liệu đã có.

## Quy tắc hiện hành v7 — tồn 0 được xóa dù có lịch sử
Thay thế mọi điều kiện cũ “chưa có lịch sử mới được xóa”. Chỉ Quản lý xóa; tồn >0 thì chặn và nêu số lượng/đơn vị. Tồn 0 thì xóa khỏi danh mục đang dùng và báo thành công tại chỗ với mã/tên.
Phiếu, đề nghị đã xử lý và audit không bị xóa; snapshot mã hàng đã xóa lưu trong deletedProducts với người/thời điểm xóa. Không tái sử dụng mã đã xóa để tránh nhầm lịch sử. Đề nghị còn chờ của hàng được xóa được đóng trạng thái rejected với lý do hệ thống, không thay tồn.
API manage/delete trả 200 và next khi tồn 0 kể cả có lịch sử; 409 nếu còn tồn. UI chỉ báo thành công sau khi localStorage ghi thành công.
