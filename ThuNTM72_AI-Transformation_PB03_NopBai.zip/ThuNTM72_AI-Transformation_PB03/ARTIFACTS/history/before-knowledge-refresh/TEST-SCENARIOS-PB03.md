# Kịch bản hiện hành v2
1. Given Sổ 20, When thủ kho nhập 10 trong phiếu một dòng, Then Sổ 30 và có lịch sử.
2. Given Bút trống/Sổ 10, When lưu, Then chỉ rõ dòng Bút sai, không đổi tồn; bỏ dòng Bút rồi lưu thì thành công.
3. Given đã chọn Bút, When thêm dòng, Then chọn Sổ và không chọn lại Bút được. Hết mã thì chặn thêm; xóa dòng thì trả lựa chọn.
4. Given số lượng -3/0/1.5 hoặc một dòng sai, When lưu, Then từ chối toàn phiếu.
5. Given role quản lý, When tạo mã hợp lệ, Then tồn 0, có audit; mã trùng bị từ chối. Thủ kho gọi mock tạo mã bị 403.
6. Given mã mới, When thủ kho nhập 7, Then tồn mới 7; tải lại vẫn giữ mã, tồn và phiếu.
7. Given manager, When tạo phiếu nhập, Then 403; role trống thì 401.
8. Lỗi localStorage/quota chưa kiểm tự động; phải giữ nháp và không báo thành công khi ghi thất bại.

## Cập nhật v3 — Hiển thị theo quyền
Quản lý không thấy section Lập phiếu nhập; chưa chọn role cũng ẩn. Thủ kho thấy lại section khi đổi vai trò. API mock vẫn từ chối Quản lý tạo phiếu với 403. Thông báo chung nằm ngoài section để Quản lý vẫn thấy kết quả tạo mã hàng.

## Phạm vi hiện hành v4 — danh mục và giảm tồn (thay thế giới hạn v3)
Quản lý tạo/sửa tên; mã và đơn vị chỉ đổi khi tồn 0 và chưa có phiếu/đề nghị. Mã mới phải duy nhất. Không chỉnh trực tiếp số tồn trong danh mục.
Xóa hẳn cần tồn 0 và chưa sử dụng trong phiếu/đề nghị; phải xác nhận. Hàng có lịch sử dùng “Ngừng sử dụng”: giữ tồn và lịch sử, chặn nhập/đề nghị mới, có thể dùng lại. Còn đề nghị chờ thì phải xử lý trước khi ngừng sử dụng. Nhật ký danh mục giữ trước/sau, người thao tác và thời điểm.
Thủ kho gửi đề nghị giảm tồn: chọn hàng đang dùng, số lượng nguyên >0 và không vượt tồn hiện tại, lý do bắt buộc. Chờ duyệt không đổi tồn. Quản lý duyệt hoặc từ chối (cần lý do). Duyệt kiểm lại tồn hiện tại, trừ đúng một lần, ghi người/giờ duyệt và tồn trước/sau. Không đủ tồn thì giữ chờ, không trừ âm. Từ chối không đổi tồn và không duyệt lại được.
Luồng này dành cho mất/hỏng/chênh lệch kiểm kê, không thay thế luồng xuất kho hàng bán. Tồn demo ban đầu 10 bút/20 sổ là số dư mở đầu; lịch sử phiếu mới thể hiện biến động sau đó.
Role chỉ mô phỏng trên cùng trình duyệt, không có xác thực danh tính thật; chưa hỗ trợ nhiều người/đa tab đồng thời. Đây vẫn là Tier 2, không phải hệ thống kho production.

## Giao diện hiện hành v5 — thay thế mục nhiều nút của v4
Tên mục: Chỉnh sửa danh mục hàng. Chỉ có hai nút Lưu chỉnh sửa và Xóa hàng; bỏ nút Ngừng sử dụng/Dùng lại khỏi UI.
Kết quả sửa/xóa hoặc lỗi hiển thị ngay dưới hai nút; xóa thông báo cũ khi đổi hàng/sửa trường để không nhầm với thao tác mới.
Xóa vẫn cần xác nhận. Nếu tồn >0: báo “Không thể xóa <mã>: còn <số lượng> <đơn vị> trong kho”. Nếu tồn 0 nhưng có phiếu/đề nghị: chặn và nêu cần giữ lịch sử. Không xóa mất liên kết phiếu.
Các hàng đã ngừng sử dụng từ v4 vẫn giữ trạng thái/dữ liệu; chức năng archive/restore cũ chỉ còn tương thích ở mock, không nằm trên UI v5. Không tự thay trạng thái dữ liệu đã có.

## V6 — Phản hồi xóa ngay dưới mục danh mục
Thông báo nằm trong khung có viền, ngay dưới hai nút, nêu mã/tên đã xóa và danh mục đã cập nhật. Sau thao tác tự đưa khung vào vùng nhìn thấy và focus để nhận biết; không tự biến mất khi đổi hàng/chỉnh trường. Thông báo giữ nguyên tới thao tác quản lý tiếp theo hoặc đổi vai trò. Hủy xác nhận thì báo đã hủy, không báo thành công. Không có hàng thì báo chưa có hàng để xóa. Lỗi còn tồn vẫn báo tại cùng vị trí.

## Quy tắc hiện hành v7 — tồn 0 được xóa dù có lịch sử
Thay thế mọi điều kiện cũ “chưa có lịch sử mới được xóa”. Chỉ Quản lý xóa; tồn >0 thì chặn và nêu số lượng/đơn vị. Tồn 0 thì xóa khỏi danh mục đang dùng và báo thành công tại chỗ với mã/tên.
Phiếu, đề nghị đã xử lý và audit không bị xóa; snapshot mã hàng đã xóa lưu trong deletedProducts với người/thời điểm xóa. Không tái sử dụng mã đã xóa để tránh nhầm lịch sử. Đề nghị còn chờ của hàng được xóa được đóng trạng thái rejected với lý do hệ thống, không thay tồn.
API manage/delete trả 200 và next khi tồn 0 kể cả có lịch sử; 409 nếu còn tồn. UI chỉ báo thành công sau khi localStorage ghi thành công.

## Quy tắc tương tác hiện hành v8 — xóa và phản hồi tại chỗ
Còn tồn >0: bấm Xóa hàng hiện ngay “Không thể xóa <mã> — <tên>: còn <số> <đơn vị> trong kho”, không mở xác nhận, không đổi dữ liệu.
Tồn 0: bấm Xóa hàng mở khung xác nhận trong trang (không dùng window.confirm). Chưa xác nhận thì chưa xóa. Bấm Xác nhận xóa, chỉ sau khi lưu thành công mới hiện “Xóa hàng thành công: <mã> — <tên>. Danh mục đã được cập nhật.” ngay dưới mục; Hủy thì báo đã hủy và giữ dữ liệu.
Đổi hàng hoặc role đóng khung xác nhận để tránh xóa nhầm. API vẫn kiểm lại điều kiện tồn và quyền. Lịch sử giữ nguyên theo v7.

## V9 — Thông báo tạo mã hàng tại chỗ
Thông báo tạo thành công hoặc lỗi (thiếu dữ liệu, mã trùng, lỗi lưu) nằm ngay dưới nút Tạo mã hàng, trước mục Chỉnh sửa danh mục hàng. Có khung màu thành công/lỗi, focus/scroll vào thông báo; chỉ báo thành công khi localStorage lưu thành công. Phần sửa/xóa giữ thông báo riêng tại chỗ như v8.

## V10 — Phản hồi duyệt/từ chối tại lịch sử giảm tồn
Thành công hoặc lỗi từ POST /api/adjustments/review đều hiện ở khung ngay dưới danh sách “Đề nghị và lịch sử giảm tồn”. Thành công ghi mã đề nghị, hành động và tồn đã cập nhật/không thay đổi. Thiếu lý do từ chối hoặc lỗi nghiệp vụ cũng hiện cùng chỗ. Thông báo focus/scroll vào vùng thấy được; đổi role ẩn phản hồi cũ. Chỉ báo thành công khi localStorage lưu được. Không thay rule duyệt/từ chối hoặc quyền.
