# Bắt đầu demo v10 (không cần viết code)
1. Giải nén PB03-demo-va-ho-so-v10.zip, mở prototype/MO-DEMO.html bằng trình duyệt trên máy bạn.
2. Thử trên cùng file/trình duyệt nếu muốn giữ dữ liệu cũ. localStorage dùng cùng key, nhưng trình duyệt có thể tách dữ liệu theo đường dẫn file. Không xóa/ghi đè file cũ nếu cần giữ bằng chứng.
3. Chọn Thủ kho, đổi hàng trên dòng duy nhất sang Sổ, nhập 10 và Lưu: tồn Sổ tăng 10.
4. Thêm dòng nhưng để trống: Lưu sẽ chỉ rõ dòng/mã lỗi; nhập số lượng hoặc bấm Bỏ dòng đó.
5. Thêm dòng: chỉ chọn được hàng chưa có. Khi đã chọn hết hàng thì nút Thêm dòng bị khóa. Không còn nút gộp.
6. Chọn Quản lý, ở phần Danh mục nhập mã THUOC, tên Thước kẻ, đơn vị cây; bấm Tạo mã hàng. Tồn mới là 0. Chọn Thủ kho rồi nhập mã mới.
7. Tải lại, chọn role và kiểm phiếu/tồn/mã mới vẫn còn.
Demo chỉ dùng dữ liệu giả. Nếu file không chạy/lưu được do chính sách trình duyệt, báo lỗi; có thể nhờ hỗ trợ chạy `python -m http.server 8000 --directory prototype` từ thư mục PB03.
Đã kiểm bản HTML gộp qua HTTP Chromium; môi trường cloud chặn mở file://, nên việc nhấp đúp trên máy bạn cần tự xác nhận.
Hồ sơ vẫn đang học, chưa nộp: cần UAT bạn xác nhận, đủ bằng chứng lỗi AI thật, telemetry và viva.

V3: chọn Quản lý không còn thấy phần Lập phiếu nhập; đổi Thủ kho phần này hiện lại.

## Thử chức năng v4
1. Quản lý tạo THUOC, tồn 0; chọn trong phần Sửa/xóa, đổi tên/mã/đơn vị rồi Lưu sửa. Có thể xóa hẳn nếu chưa sử dụng.
2. Hàng đã có tồn/phiếu: chỉ sửa tên, không đổi mã/đơn vị; xóa bị chặn. Bản v5 chỉ có sửa/xóa; không còn nút Ngừng sử dụng/Dùng lại.
3. Thủ kho chọn Bút ở Đề nghị giảm tồn, nhập 2, lý do “Bị hỏng”, Gửi đề nghị. Kiểm tồn chưa đổi.
4. Đổi Quản lý, Duyệt đề nghị: tồn giảm 2, hiện tồn trước/sau và người/giờ duyệt. Hoặc nhập lý do rồi Từ chối: tồn không đổi.
5. Tải lại và kiểm lịch sử. Không xóa dữ liệu trình duyệt nếu cần giữ bằng chứng.

## Giao diện hiện hành v5 — thay thế mục nhiều nút của v4
Tên mục: Chỉnh sửa danh mục hàng. Chỉ có hai nút Lưu chỉnh sửa và Xóa hàng; bỏ nút Ngừng sử dụng/Dùng lại khỏi UI.
Kết quả sửa/xóa hoặc lỗi hiển thị ngay dưới hai nút; xóa thông báo cũ khi đổi hàng/sửa trường để không nhầm với thao tác mới.
Xóa vẫn cần xác nhận. Nếu tồn >0: báo “Không thể xóa <mã>: còn <số lượng> <đơn vị> trong kho”. Nếu tồn 0 nhưng có phiếu/đề nghị: chặn và nêu cần giữ lịch sử. Không xóa mất liên kết phiếu.
Các hàng đã ngừng sử dụng từ v4 vẫn giữ trạng thái/dữ liệu; chức năng archive/restore cũ chỉ còn tương thích ở mock, không nằm trên UI v5. Không tự thay trạng thái dữ liệu đã có.

Thử v5: Quản lý → Chỉnh sửa danh mục hàng → sửa tên và Lưu chỉnh sửa: xem thông báo ngay dưới. Thử xóa hàng còn tồn: xem lý do và số tồn. Tạo hàng mới chưa nhập rồi xóa: thấy Xóa hàng thành công ngay trong mục.

## V6 — Phản hồi xóa ngay dưới mục danh mục
Thông báo nằm trong khung có viền, ngay dưới hai nút, nêu mã/tên đã xóa và danh mục đã cập nhật. Sau thao tác tự đưa khung vào vùng nhìn thấy và focus để nhận biết; không tự biến mất khi đổi hàng/chỉnh trường. Thông báo giữ nguyên tới thao tác quản lý tiếp theo hoặc đổi vai trò. Hủy xác nhận thì báo đã hủy, không báo thành công. Không có hàng thì báo chưa có hàng để xóa. Lỗi còn tồn vẫn báo tại cùng vị trí.

Kiểm đúng bản: đầu trang có nhãn v10. Quản lý tạo hàng TEST chưa nhập, chọn TEST ở Chỉnh sửa danh mục hàng, bấm Xóa hàng và xác nhận. Khung ngay bên dưới hiện “Xóa hàng thành công: TEST — <tên>”.

## Quy tắc hiện hành v7 — tồn 0 được xóa dù có lịch sử
Thay thế mọi điều kiện cũ “chưa có lịch sử mới được xóa”. Chỉ Quản lý xóa; tồn >0 thì chặn và nêu số lượng/đơn vị. Tồn 0 thì xóa khỏi danh mục đang dùng và báo thành công tại chỗ với mã/tên.
Phiếu, đề nghị đã xử lý và audit không bị xóa; snapshot mã hàng đã xóa lưu trong deletedProducts với người/thời điểm xóa. Không tái sử dụng mã đã xóa để tránh nhầm lịch sử. Đề nghị còn chờ của hàng được xóa được đóng trạng thái rejected với lý do hệ thống, không thay tồn.
API manage/delete trả 200 và next khi tồn 0 kể cả có lịch sử; 409 nếu còn tồn. UI chỉ báo thành công sau khi localStorage ghi thành công.

Thử v7: Thủ kho gửi đề nghị giảm hết tồn Bút; Quản lý duyệt, xác nhận tồn 0, chọn Bút và Xóa hàng. Thấy “Xóa hàng thành công: BUT — Bút bi”. Tồn/danh mục không còn Bút, lịch sử vẫn tra được.

## Quy tắc tương tác hiện hành v8 — xóa và phản hồi tại chỗ
Còn tồn >0: bấm Xóa hàng hiện ngay “Không thể xóa <mã> — <tên>: còn <số> <đơn vị> trong kho”, không mở xác nhận, không đổi dữ liệu.
Tồn 0: bấm Xóa hàng mở khung xác nhận trong trang (không dùng window.confirm). Chưa xác nhận thì chưa xóa. Bấm Xác nhận xóa, chỉ sau khi lưu thành công mới hiện “Xóa hàng thành công: <mã> — <tên>. Danh mục đã được cập nhật.” ngay dưới mục; Hủy thì báo đã hủy và giữ dữ liệu.
Đổi hàng hoặc role đóng khung xác nhận để tránh xóa nhầm. API vẫn kiểm lại điều kiện tồn và quyền. Lịch sử giữ nguyên theo v7.

Kiểm bản v8 ở đầu trang. Thử một hàng còn tồn để thấy lỗi ngay. Với hàng tồn 0, bấm Xóa hàng rồi Xác nhận xóa trong trang để thấy thành công. Không dùng popup trình duyệt.

## V9 — Thông báo tạo mã hàng tại chỗ
Thông báo tạo thành công hoặc lỗi (thiếu dữ liệu, mã trùng, lỗi lưu) nằm ngay dưới nút Tạo mã hàng, trước mục Chỉnh sửa danh mục hàng. Có khung màu thành công/lỗi, focus/scroll vào thông báo; chỉ báo thành công khi localStorage lưu thành công. Phần sửa/xóa giữ thông báo riêng tại chỗ như v8.

Thử v9: Quản lý → Tạo mã hàng; xem thông báo ngay dưới nút. Thử tạo lại cùng mã hoặc thiếu dữ liệu để xem lỗi tại cùng chỗ.

## V10 — Phản hồi duyệt/từ chối tại lịch sử giảm tồn
Thành công hoặc lỗi từ POST /api/adjustments/review đều hiện ở khung ngay dưới danh sách “Đề nghị và lịch sử giảm tồn”. Thành công ghi mã đề nghị, hành động và tồn đã cập nhật/không thay đổi. Thiếu lý do từ chối hoặc lỗi nghiệp vụ cũng hiện cùng chỗ. Thông báo focus/scroll vào vùng thấy được; đổi role ẩn phản hồi cũ. Chỉ báo thành công khi localStorage lưu được. Không thay rule duyệt/từ chối hoặc quyền.
