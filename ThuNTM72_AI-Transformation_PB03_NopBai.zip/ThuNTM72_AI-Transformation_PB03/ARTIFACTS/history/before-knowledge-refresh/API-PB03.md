# API contract — mock trong trình duyệt
Không có HTTP backend thật. api(state, role, method, path, payload) trả {status,body,next?}. UI lưu next vào localStorage thành công rồi mới đổi state hiển thị.
- GET /api/products: role keeper/manager; 200 danh sách {id,name,unit,stock}.
- GET /api/receipts: role keeper/manager; 200 danh sách {id,at,actor,lines}.
- POST /api/receipts: role keeper; input {lines:[{productId,quantity}]}.
- 201: phiếu đã tạo trong next; 400: thiếu dòng/mã sai/số lượng sai hoặc overflow; 401: chưa có role hợp lệ; 403: manager ghi; 409: dòng trùng; 404: API không tồn tại.
- mergeLines: thao tác nháp, không lưu, kiểm từng dòng hợp lệ rồi cộng theo mã; không tự động gọi POST.
Schema tham khảo: prototype/schema.sql. Không chạy DB hoặc migration; phân quyền là mô phỏng, localStorage không bảo vệ dữ liệu thật.

## Quy tắc hiện hành — bản v2 sau UAT (thay thế quy tắc gộp trước đây)
- Không có nút gộp. Mỗi hàng chỉ một dòng; hàng đã chọn bị vô hiệu hóa ở dòng khác. Thêm dòng tự chọn hàng chưa có; hết hàng thì chặn Thêm dòng; bỏ dòng thì hàng đó được chọn lại.
- Mọi dòng trên phiếu đều phải hợp lệ. Sổ nhập 10 hợp lệ; nếu dòng Bút trống, báo đúng “Dòng 1 (BUT)”, giữ toàn bộ tồn/phiếu chưa lưu. Bỏ dòng chưa dùng rồi lưu.
- Người học đã chọn chỉ Quản lý tạo mã mới; Thủ kho chỉ chọn để nhập. Đây là mở rộng phạm vi và thay thế mô tả quản lý chỉ xem trước đây. Không thêm sửa/xóa danh mục.
- Mã mới duy nhất, chuẩn hóa chữ hoa, tên và đơn vị bắt buộc; tồn khởi đầu 0. Có nhật ký tạo mã trong snapshot demo. API mock POST /api/products: manager 201, keeper 403, dữ liệu sai 400, trùng mã 409.
- Vai trò vẫn chỉ mô phỏng, không phải xác thực hoặc bảo mật production.

## Phạm vi hiện hành v4 — danh mục và giảm tồn (thay thế giới hạn v3)
Quản lý tạo/sửa tên; mã và đơn vị chỉ đổi khi tồn 0 và chưa có phiếu/đề nghị. Mã mới phải duy nhất. Không chỉnh trực tiếp số tồn trong danh mục.
Xóa hẳn cần tồn 0 và chưa sử dụng trong phiếu/đề nghị; phải xác nhận. Hàng có lịch sử dùng “Ngừng sử dụng”: giữ tồn và lịch sử, chặn nhập/đề nghị mới, có thể dùng lại. Còn đề nghị chờ thì phải xử lý trước khi ngừng sử dụng. Nhật ký danh mục giữ trước/sau, người thao tác và thời điểm.
Thủ kho gửi đề nghị giảm tồn: chọn hàng đang dùng, số lượng nguyên >0 và không vượt tồn hiện tại, lý do bắt buộc. Chờ duyệt không đổi tồn. Quản lý duyệt hoặc từ chối (cần lý do). Duyệt kiểm lại tồn hiện tại, trừ đúng một lần, ghi người/giờ duyệt và tồn trước/sau. Không đủ tồn thì giữ chờ, không trừ âm. Từ chối không đổi tồn và không duyệt lại được.
Luồng này dành cho mất/hỏng/chênh lệch kiểm kê, không thay thế luồng xuất kho hàng bán. Tồn demo ban đầu 10 bút/20 sổ là số dư mở đầu; lịch sử phiếu mới thể hiện biến động sau đó.
Role chỉ mô phỏng trên cùng trình duyệt, không có xác thực danh tính thật; chưa hỗ trợ nhiều người/đa tab đồng thời. Đây vẫn là Tier 2, không phải hệ thống kho production.

POST /api/products/manage: manager; {action:edit|delete|archive|restore,originalId,id?,name?,unit?}; 200 next; 400 dữ liệu sai, 403 quyền, 404 mã không tồn tại, 409 ràng buộc nghiệp vụ.
POST /api/adjustments: keeper; {productId,quantity,reason}; 201 {id,productId,quantity,reason,status:pending,requestedBy,requestedAt}, không đổi tồn.
POST /api/adjustments/review: manager; {id,action:approve|reject,note?}; 200 cập nhật trạng thái/tồn nguyên tử trong next; 409 nếu đã xử lý/thiếu tồn, 400 thiếu lý do từ chối. UI chỉ áp dụng next khi ghi localStorage thành công.

## Giao diện hiện hành v5 — thay thế mục nhiều nút của v4
Tên mục: Chỉnh sửa danh mục hàng. Chỉ có hai nút Lưu chỉnh sửa và Xóa hàng; bỏ nút Ngừng sử dụng/Dùng lại khỏi UI.
Kết quả sửa/xóa hoặc lỗi hiển thị ngay dưới hai nút; xóa thông báo cũ khi đổi hàng/sửa trường để không nhầm với thao tác mới.
Xóa vẫn cần xác nhận. Nếu tồn >0: báo “Không thể xóa <mã>: còn <số lượng> <đơn vị> trong kho”. Nếu tồn 0 nhưng có phiếu/đề nghị: chặn và nêu cần giữ lịch sử. Không xóa mất liên kết phiếu.
Các hàng đã ngừng sử dụng từ v4 vẫn giữ trạng thái/dữ liệu; chức năng archive/restore cũ chỉ còn tương thích ở mock, không nằm trên UI v5. Không tự thay trạng thái dữ liệu đã có.

## Quy tắc hiện hành v7 — tồn 0 được xóa dù có lịch sử
Thay thế mọi điều kiện cũ “chưa có lịch sử mới được xóa”. Chỉ Quản lý xóa; tồn >0 thì chặn và nêu số lượng/đơn vị. Tồn 0 thì xóa khỏi danh mục đang dùng và báo thành công tại chỗ với mã/tên.
Phiếu, đề nghị đã xử lý và audit không bị xóa; snapshot mã hàng đã xóa lưu trong deletedProducts với người/thời điểm xóa. Không tái sử dụng mã đã xóa để tránh nhầm lịch sử. Đề nghị còn chờ của hàng được xóa được đóng trạng thái rejected với lý do hệ thống, không thay tồn.
API manage/delete trả 200 và next khi tồn 0 kể cả có lịch sử; 409 nếu còn tồn. UI chỉ báo thành công sau khi localStorage ghi thành công.
