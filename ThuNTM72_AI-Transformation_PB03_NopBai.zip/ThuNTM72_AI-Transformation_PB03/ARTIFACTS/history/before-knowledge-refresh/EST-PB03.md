# EX-03 — Ước lượng PB03, bản AI để người học review

## Phạm vi và giả định
Ước lượng phần còn lại để chuyển prototype Tier 2 thành MVP thực có frontend React/Vue, backend Spring Boot/.NET, PostgreSQL/MySQL theo brief. Không tính demo như backend production đã hoàn thành. Không ước lượng lại 90 phút đã học.
MD = ngày công một người. Số dưới đây là giả định lập kế hoạch, không phải báo giá hay số đo thực tế. Hai dev có kinh nghiệm stack, một PM; không có QA riêng. Có môi trường nội bộ và người dùng tham gia UAT. Chưa biết kinh nghiệm thật, lịch nghỉ, nền tảng có sẵn hay thời gian cấp hạ tầng.
Giả định dữ liệu đầu kỳ được người dùng kiểm và nhập qua phiếu mở đầu chuẩn; import Excel tự động chỉ ước lượng khi chốt nhu cầu, không tự tính là scope đã xác nhận.
Ba mức O/M/P: thuận lợi/thông thường/khó khăn. M dùng đối chiếu capacity theo Workbook; không dùng trung bình PERT thay M mà không giải thích.

| ID | Trace WBS | Việc | O dev-MD | M dev-MD | P dev-MD | PM-MD (M) | Giả định |
|---|---|---|---:|---:|---:|---:|---|
| E01 | 2.1 | Backend/DB và mô hình dữ liệu | 3 | 5 | 8 | 1 | Stack theo brief; dựng DB thật, mock không tái dùng nguyên trạng |
| E02 | 2.1 | Xác thực, phân quyền và audit | 3 | 5 | 9 | 1 | Hai role, tài khoản nội bộ; chưa tích hợp LDAP/AD |
| E03 | 1.3→2.1 | Danh mục trên backend thật | 2 | 3 | 5 | 0.5 | Giữ lịch sử/xóa nghiệp vụ, kiểm quyền server |
| E04 | 1.4→2.1 | Nhập kho trên DB thật | 2 | 4 | 6 | 0.5 | Phiếu nhiều dòng nguyên tử; không sửa phiếu đã lưu |
| E05 | 2.3 | Xuất kho và chống tranh chấp | 3 | 5 | 8 | 0.5 | Transaction/khoá để không xuất âm |
| E06 | 2.4 | Điều chỉnh tăng/giảm và duyệt | 3 | 5 | 9 | 1 | Liên kết phiếu gốc, duyệt một lần, audit |
| E07 | 2.5 | Tồn, lịch sử và cảnh báo tối thiểu | 2 | 3 | 5 | 0.5 | Danh sách có lọc cơ bản, không dashboard nâng cao |
| E08 | 2.6a | Báo cáo nhập–xuất–tồn theo kỳ | 2 | 4 | 7 | 0.5 | Đối soát số dư/biến động, quyền xem |
| E09 | 2.6b | Xuất Excel | 1 | 3 | 5 | 0.25 | Dùng thư viện chuẩn, bộ lọc và kiểm quyền giống báo cáo |
| E10 | 2.7 | Kiểm thử tích hợp, bảo mật và 20 user | 3 | 5 | 9 | 1 | Không có QA riêng; dev tự chạy và review chéo |
| E11 | 2.8 | Triển khai, backup và thử phục hồi | 2 | 3 | 6 | 1 | Một môi trường nội bộ, cần quyền hạ tầng |
| E12 | 2.9 | Hướng dẫn người dùng | 0.5 | 1 | 2 | 2 | Dev cung cấp minh họa; PM soạn/điều phối |
| E13 | 2.10 | UAT thủ kho thực tế | 1 | 2 | 4 | 2 | Người dùng có lịch tham gia; effort dev không thay thời gian chờ |
| E14 | 2.11 | Sửa theo UAT và kiểm lại | 2 | 3 | 6 | 1 | Chỉ sửa lỗi thuộc scope; không thêm tính năng mới |

## Capacity theo vai trò
- Dev: 2 × 6 tuần × 5 ngày = 60 dev-MD danh nghĩa. Giả định 20% dành cho họp/điều phối/gián đoạn → 48 dev-MD khả dụng. Không trừ kiểm thử/UAT lần nữa vì đã có E10/E13/E14.
- PM: 1 × 6 × 5 = 30 PM-MD; cùng giả định 20% → 24 PM-MD. Nhu cầu PM M = 12.75 MD trước buffer; không cộng PM thành năng lực code của dev.
- Buffer rủi ro 15% cộng vào effort M; tách với overhead capacity. E14 là sửa lỗi dự kiến; buffer dành cho bất định ngoài giả định, cần hiệu chỉnh nếu trùng rủi ro cụ thể.

| Kịch bản | M dev-MD | Buffer 15% | Tổng | So với 48 dev-MD |
|---|---:|---:|---:|---:|
| Đầy đủ, có Excel | 51 | 7.65 | 58.65 | Vượt 10.65 |
| Hoãn Excel theo lựa chọn người học | 48 | 7.20 | 55.20 | Vượt 7.20 |

Kết luận: hoãn Excel giảm effort nhưng CHƯA đủ để cam kết MVP 6 tuần. Tổng MD vừa capacity cũng chưa chứng minh lịch khả thi vì có dependency/UAT/hạ tầng. Chưa được đánh dấu khả thi.
Top bất định: E02 xác thực/quyền; E06 điều chỉnh/trace; E10 kiểm thử không có QA. Nếu dev chưa quen stack hoặc cần LDAP/import tự động, phải cập nhật effort và timeline.
Nhạy cảm: nếu overhead 10% thì capacity 54 dev-MD; overhead 30% thì 42. Không được chọn overhead nhỏ chỉ để ép vừa mốc.

## Quyết định người học và chỗ cần review
Người học ưu tiên không âm, duyệt điều chỉnh; hoãn Excel bằng MoSCoW. Đây là quyết định thực, chưa phải người học đã review mọi con số AI.
Cần người học chọn cách xử lý gap: giảm tiếp phạm vi có đánh giá hoặc điều chỉnh mốc. Đề xuất giữ chức năng cốt lõi và xem xét mốc 8 tuần như kịch bản phân tích; chưa được người học chốt.

## Quyết định người học — phương án 8 tuần
Người học chọn đề xuất 8 tuần để giữ kiểm soát tồn không âm, phân quyền, duyệt điều chỉnh và kiểm thử; Excel vẫn hoãn sang phase sau.
Capacity dev theo giả định: 2 × 8 × 5 × 80% = 64 dev-MD; nhu cầu M + 15% dự phòng = 55,2 dev-MD; chênh 8,8 dev-MD (không cộng thêm một lần buffer 15%). PM: 8 × 5 × 80% = 32 PM-MD; effort PM khả dĩ 12,75, hoặc 14,6625 nếu áp 15% dự phòng tương tự.
Đây là phương án lập kế hoạch trong bài tập, chưa phải stakeholder đã duyệt đổi deadline. Người học yêu cầu xác nhận effort với team, dependency và critical path trước khi cam kết. Chưa có lịch nghỉ, task assignment và duration thực tế nên không khẳng định đường găng hoặc ngày bàn giao cụ thể.
Nếu overhead dev tăng 30% thì capacity 56 dev-MD, chỉ hơn nhu cầu 0,8. Nếu effort M tăng 20%, nhu cầu sau buffer thành 66,24 dev-MD, vượt capacity 64 là 2,24. Phải tái ước lượng/thương lượng nếu giả định không còn đúng.
