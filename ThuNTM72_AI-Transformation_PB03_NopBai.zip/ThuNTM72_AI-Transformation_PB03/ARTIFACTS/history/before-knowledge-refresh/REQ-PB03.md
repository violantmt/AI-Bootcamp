# REQ-PB03 — Bản nháp AI để người học review

Trạng thái: DRAFT; chưa được người học chốt. Nguồn: Project-Briefs, PB-03.

## Mục tiêu và ràng buộc
Thay Excel bằng web nội bộ quản lý nhập–xuất–tồn, giảm nhầm lẫn và truy vết giao dịch.
Dự án giả định: 1 PM, 2 dev, 6 tuần; khoảng 20 người dùng đồng thời.

## Scope MVP theo đề
IN: danh mục; phiếu nhập nhiều dòng; phiếu xuất, chặn quá tồn; tồn hiện tại/cảnh báo tối thiểu; lịch sử; báo cáo theo kỳ/xuất Excel; 2 vai trò thủ kho và quản lý.
OUT: nhiều kho, barcode, tích hợp kế toán, dự báo.
Luồng điều chỉnh kiểm kê cần làm rõ; chưa tự coi là scope đã được chốt.
Lát cắt buổi học đề xuất: nhập phiếu → lưu → xem tồn và lịch sử. Đây là tập con của MVP, không đồng nghĩa bỏ các yêu cầu còn lại khỏi dự án.

## User stories
US01: Là người được cấp quyền quản lý danh mục, tôi muốn quản lý mã/tên/đơn vị/tồn tối thiểu để nhận diện hàng. [CHỜ xác định vai trò có quyền]
US02: Là thủ kho, tôi muốn nhập phiếu nhiều dòng để tồn tăng và tra cứu được.
US03: Là thủ kho, tôi muốn xuất hàng trong giới hạn tồn để không phát sinh tồn âm.
US04: Là người dùng được cấp quyền, tôi muốn xem tồn và cảnh báo dưới mức tối thiểu.
US05: Là quản lý, tôi muốn xem báo cáo theo kỳ và xuất Excel. Thủ kho không được xem báo cáo tài chính tổng.
US06: Là thủ kho, tôi muốn gửi đề nghị điều chỉnh chênh lệch kiểm kê để quản lý duyệt. Chỉ sau khi quản lý duyệt, hệ thống mới điều chỉnh tồn. Người học đã chọn quy tắc này; chi tiết từ chối, lưu vết và phạm vi triển khai vẫn cần chốt.

## Acceptance criteria đề xuất cho lát cắt nhập kho
AC01: Given hàng DEMO-01 có tồn 10, When thủ kho nhập hợp lệ 5, Then tồn 15 và tra cứu được phiếu/lịch sử.
AC02: Given phiếu nhiều dòng, When một dòng không hợp lệ, Then không cập nhật một phần phiếu/tồn. [Đề xuất quy tắc atomic, cần người học chốt]
AC03: Given số lượng 0, âm hoặc thiếu mã hàng, When gửi phiếu, Then báo lỗi và không đổi tồn. [Cần chốt cho phép số lẻ theo đơn vị]
AC04: Given người chưa xác thực, When yêu cầu tạo phiếu, Then từ chối và không đổi dữ liệu. Tier 2 chỉ chứng minh hành vi mock, không tuyên bố có bảo mật production.
AC05: Given phiếu đã lưu, When tải lại màn tồn/lịch sử, Then kết quả vẫn khớp phiếu đã lưu theo cơ chế lưu của tier đã chọn.

## NFR
Theo đề: tồn không âm và khớp lịch sử; khoảng 20 người đồng thời; sửa/xóa ghi ai và lúc nào.
Đề xuất: kiểm quyền ở API thực đối với Tier 1; mock quyền chỉ là minh họa đối với Tier 2.
Chưa có ngưỡng latency, retention log, availability: cần làm rõ, không hứa số tự đặt là yêu cầu gốc.
Chỉ dùng dữ liệu giả khi học.

## AI tự review và câu hỏi để người học phân loại
Q1. Ai được tạo/sửa/xóa danh mục? — brief chưa rõ.
Q2. Khi lệch kiểm kê ai đề nghị, ai duyệt và ghi nhận thế nào? — hard-stop.
Q3. Hàng nào có số lượng lẻ, độ chính xác bao nhiêu? — cần làm rõ.
Q4. Phiếu đã ghi sổ có được sửa/xóa trực tiếp hay cần phiếu đảo? — cần làm rõ.
Q5. Báo cáo tài chính tổng gồm trường nào và quyền xem chi tiết ra sao? — cần làm rõ.
Q6. Có dữ liệu tồn đầu kỳ từ Excel cần nhập không? — không tự thêm migration vào scope.
Q7. Nếu hai người xuất cùng lúc thì cơ chế bảo vệ tồn ra sao? — yêu cầu không âm đã có, kỹ thuật cần thiết kế/test; không đẩy toàn bộ lựa chọn kỹ thuật cho stakeholder.
Tự review: quyền quản lý xem tồn/ghi phiếu chưa được định nghĩa đầy đủ; AC02–03 là đề xuất, chưa phải quyết định của bạn; chưa có test năng lực 20 người; chưa đủ điều kiện build toàn MVP.

## Hard-stop
[CHỜ LÀM RÕ — không để AI đoán] Quyền sửa danh mục chưa chốt. Quy tắc điều chỉnh tồn đã được người học chọn: thủ kho đề nghị, quản lý duyệt; các chi tiết và phạm vi triển khai chưa chốt. Chặn triển khai hai chức năng này; vẫn có thể chuẩn bị luồng nhập kho dùng dữ liệu giả sau khi chốt DoR.

## Phần người học điền
- Điểm tôi không đồng ý/sửa trong bản nháp và lý do:
- Nhãn [Hỏi stakeholder]/[AI tự sai] cho từng câu hỏi (chỉ dùng nhãn thứ hai nếu chỉ rõ AI sai thật):
- Quyết định nghiệp vụ đã chốt: thủ kho gửi đề nghị điều chỉnh tồn để quản lý duyệt (nguyên văn người học: “thủ kho nên gửi đề nghị để quản lý duyệt”). Chưa có lý do do người học tự giải thích.
- Simulation: “Kho muốn thêm quét barcode từ điện thoại ngay trong MVP.”
- Phản hồi của tôi (≤5 dòng):
- Lý do/ảnh hưởng dựa trên scope:

## Review của người học — số lượng nhập
Người học xác nhận: “Kết quả trên là SAI so với quy trình nghiệp vụ đã đề ra. Hệ thống đã vi phạm quy tắc cốt lõi: chỉ được nhập số lượng nguyên lớn hơn 0”.
Phạm vi quy tắc: bài thực hành kho văn phòng phẩm (bút/sổ), không áp dụng mặc định cho hàng cân/đo.
AC06 — Given kho có 10 cây bút, When thủ kho gửi phiếu nhập số lượng -3, Then hệ thống từ chối, báo số lượng phải là số nguyên lớn hơn 0, không lưu phiếu thành công và tồn vẫn là 10.
AC07 — Given kho có 10 cây bút, When số lượng là 0 hoặc 1.5, Then từ chối và tồn vẫn là 10.
AC08 — Given kho có 10 cây bút, When nhập 3 hợp lệ và lưu thành công, Then tồn là 13 và có phiếu/lịch sử tương ứng.
AC06–08 là đặc tả kiểm thử, chưa có sản phẩm để chạy; không ghi PASS.

## Phản hồi stakeholder do người học viết — EX-01
> Em hiểu anh muốn giảm thao tác nhập hàng nhờ quét barcode, giúp tăng tốc độ xử lý và hạn chế sai sót. Tuy nhiên, việc thêm tính năng này lúc này đòi hỏi phải khảo sát phần cứng, thiết kế lại luồng và kiểm thử thêm, nên chúng ta chưa có cơ sở hứa trước mốc thời gian hoàn thành. Trước mắt, mình hãy tập trung hoàn thiện và chạy thử luồng lưu phiếu, xem tồn chuẩn xác theo MVP; sau khi hệ thống này vận hành ổn định, em sẽ lên lịch trình để chúng ta xem xét tích hợp barcode ngay ở đợt tiếp theo.

AI review: đã có lợi ích, ảnh hưởng và phương án thay thế; không hứa thời gian thiếu cơ sở. Barcode ngoài MVP theo Project Briefs PB-03. Lưu ý kỹ thuật: cần khảo sát thiết bị hiện có/camera điện thoại, không mặc định cần mua phần cứng hoặc thiết kế lại toàn bộ luồng. Có thể dùng bản 3 dòng bên dưới khi nộp, giữ nguyên ý người học:
1. Em hiểu anh muốn quét barcode để nhập nhanh và giảm sai sót.
2. Barcode nằm ngoài MVP hiện tại; cần khảo sát thiết bị/camera, cách ghép với luồng nhập và kiểm thử nên chưa thể cam kết thời gian.
3. Trước mắt mình hoàn thiện nhập phiếu, lưu và xem tồn chính xác; sau khi chạy thử ổn định, mình đánh giá barcode cho đợt tiếp theo.
Bản rút gọn do AI đề xuất, chưa được người học xác nhận thay thế nguyên văn.

## Cập nhật sau clarification dòng trùng của người học
Người học đồng ý phạm vi/quy tắc demo và yêu cầu có nút “Tự động gộp dòng” thay vì chỉ bắt sửa thủ công. Đây là bổ sung thực tế do người học review, không phải lỗi sản phẩm đã phát hiện.
Quy tắc triển khai: chặn Lưu khi trùng; nút gộp chỉ cộng các dòng hợp lệ cùng mã trong nháp, không tự lưu; dòng sai bị từ chối trước khi cộng. Các chi tiết kiểm tra trước gộp và bấm Lưu riêng do AI cụ thể hóa, người học cần thử/review.
Kế hoạch build đã được người học chấp thuận với bổ sung trên. Đã dựng Tier 2, chạy 17 test logic và kiểm UI Chromium. DoR đủ cho build demo; nghiệm thu người học/hoàn thành toàn bài vẫn chờ. Các trạng thái DRAFT/chưa build ở phần trên là lịch sử trước quyết định này.

## Quy tắc hiện hành — bản v2 sau UAT (thay thế quy tắc gộp trước đây)
- Không có nút gộp. Mỗi hàng chỉ một dòng; hàng đã chọn bị vô hiệu hóa ở dòng khác. Thêm dòng tự chọn hàng chưa có; hết hàng thì chặn Thêm dòng; bỏ dòng thì hàng đó được chọn lại.
- Mọi dòng trên phiếu đều phải hợp lệ. Sổ nhập 10 hợp lệ; nếu dòng Bút trống, báo đúng “Dòng 1 (BUT)”, giữ toàn bộ tồn/phiếu chưa lưu. Bỏ dòng chưa dùng rồi lưu.
- Người học đã chọn chỉ Quản lý tạo mã mới; Thủ kho chỉ chọn để nhập. Đây là mở rộng phạm vi và thay thế mô tả quản lý chỉ xem trước đây. Không thêm sửa/xóa danh mục.
- Mã mới duy nhất, chuẩn hóa chữ hoa, tên và đơn vị bắt buộc; tồn khởi đầu 0. Có nhật ký tạo mã trong snapshot demo. API mock POST /api/products: manager 201, keeper 403, dữ liệu sai 400, trùng mã 409.
- Vai trò vẫn chỉ mô phỏng, không phải xác thực hoặc bảo mật production.

## Cập nhật v3 — Hiển thị theo quyền
Quản lý không thấy section Lập phiếu nhập; chưa chọn role cũng ẩn. Thủ kho thấy lại section khi đổi vai trò. API mock vẫn từ chối Quản lý tạo phiếu với 403. Thông báo chung nằm ngoài section để Quản lý vẫn thấy kết quả tạo mã hàng.

## Phạm vi hiện hành v4 — danh mục và giảm tồn (thay thế giới hạn v3)
Quản lý tạo/sửa tên; mã và đơn vị chỉ đổi khi tồn 0 và chưa có phiếu/đề nghị. Mã mới phải duy nhất. Không chỉnh trực tiếp số tồn trong danh mục.
Xóa hẳn cần tồn 0 và chưa sử dụng trong phiếu/đề nghị; phải xác nhận. Hàng có lịch sử dùng “Ngừng sử dụng”: giữ tồn và lịch sử, chặn nhập/đề nghị mới, có thể dùng lại. Còn đề nghị chờ thì phải xử lý trước khi ngừng sử dụng. Nhật ký danh mục giữ trước/sau, người thao tác và thời điểm.
Thủ kho gửi đề nghị giảm tồn: chọn hàng đang dùng, số lượng nguyên >0 và không vượt tồn hiện tại, lý do bắt buộc. Chờ duyệt không đổi tồn. Quản lý duyệt hoặc từ chối (cần lý do). Duyệt kiểm lại tồn hiện tại, trừ đúng một lần, ghi người/giờ duyệt và tồn trước/sau. Không đủ tồn thì giữ chờ, không trừ âm. Từ chối không đổi tồn và không duyệt lại được.
Luồng này dành cho mất/hỏng/chênh lệch kiểm kê, không thay thế luồng xuất kho hàng bán. Tồn demo ban đầu 10 bút/20 sổ là số dư mở đầu; lịch sử phiếu mới thể hiện biến động sau đó.
Role chỉ mô phỏng trên cùng trình duyệt, không có xác thực danh tính thật; chưa hỗ trợ nhiều người/đa tab đồng thời. Đây vẫn là Tier 2, không phải hệ thống kho production.

## Giao diện hiện hành v5 — thay thế mục nhiều nút của v4
Tên mục: Chỉnh sửa danh mục hàng. Chỉ có hai nút Lưu chỉnh sửa và Xóa hàng; bỏ nút Ngừng sử dụng/Dùng lại khỏi UI.
Kết quả sửa/xóa hoặc lỗi hiển thị ngay dưới hai nút; xóa thông báo cũ khi đổi hàng/sửa trường để không nhầm với thao tác mới.
Xóa vẫn cần xác nhận. Nếu tồn >0: báo “Không thể xóa <mã>: còn <số lượng> <đơn vị> trong kho”. Nếu tồn 0 nhưng có phiếu/đề nghị: chặn và nêu cần giữ lịch sử. Không xóa mất liên kết phiếu.
Các hàng đã ngừng sử dụng từ v4 vẫn giữ trạng thái/dữ liệu; chức năng archive/restore cũ chỉ còn tương thích ở mock, không nằm trên UI v5. Không tự thay trạng thái dữ liệu đã có.

## V6 — Phản hồi xóa ngay dưới mục danh mục
Thông báo nằm trong khung có viền, ngay dưới hai nút, nêu mã/tên đã xóa và danh mục đã cập nhật. Sau thao tác tự đưa khung vào vùng nhìn thấy và focus để nhận biết; không tự biến mất khi đổi hàng/chỉnh trường. Thông báo giữ nguyên tới thao tác quản lý tiếp theo hoặc đổi vai trò. Hủy xác nhận thì báo đã hủy, không báo thành công. Không có hàng thì báo chưa có hàng để xóa. Lỗi còn tồn vẫn báo tại cùng vị trí.

## Quy tắc hiện hành v7 — tồn 0 được xóa dù có lịch sử
Thay thế mọi điều kiện cũ “chưa có lịch sử mới được xóa”. Chỉ Quản lý xóa; tồn >0 thì chặn và nêu số lượng/đơn vị. Tồn 0 thì xóa khỏi danh mục đang dùng và báo thành công tại chỗ với mã/tên.
Phiếu, đề nghị đã xử lý và audit không bị xóa; snapshot mã hàng đã xóa lưu trong deletedProducts với người/thời điểm xóa. Không tái sử dụng mã đã xóa để tránh nhầm lịch sử. Đề nghị còn chờ của hàng được xóa được đóng trạng thái rejected với lý do hệ thống, không thay tồn.
API manage/delete trả 200 và next khi tồn 0 kể cả có lịch sử; 409 nếu còn tồn. UI chỉ báo thành công sau khi localStorage ghi thành công.

## Quy tắc tương tác hiện hành v8 — xóa và phản hồi tại chỗ
Còn tồn >0: bấm Xóa hàng hiện ngay “Không thể xóa <mã> — <tên>: còn <số> <đơn vị> trong kho”, không mở xác nhận, không đổi dữ liệu.
Tồn 0: bấm Xóa hàng mở khung xác nhận trong trang (không dùng window.confirm). Chưa xác nhận thì chưa xóa. Bấm Xác nhận xóa, chỉ sau khi lưu thành công mới hiện “Xóa hàng thành công: <mã> — <tên>. Danh mục đã được cập nhật.” ngay dưới mục; Hủy thì báo đã hủy và giữ dữ liệu.
Đổi hàng hoặc role đóng khung xác nhận để tránh xóa nhầm. API vẫn kiểm lại điều kiện tồn và quyền. Lịch sử giữ nguyên theo v7.

## V9 — Thông báo tạo mã hàng tại chỗ
Thông báo tạo thành công hoặc lỗi (thiếu dữ liệu, mã trùng, lỗi lưu) nằm ngay dưới nút Tạo mã hàng, trước mục Chỉnh sửa danh mục hàng. Có khung màu thành công/lỗi, focus/scroll vào thông báo; chỉ báo thành công khi localStorage lưu thành công. Phần sửa/xóa giữ thông báo riêng tại chỗ như v8.

## V10 — Phản hồi duyệt/từ chối tại lịch sử giảm tồn
Thành công hoặc lỗi từ POST /api/adjustments/review đều hiện ở khung ngay dưới danh sách “Đề nghị và lịch sử giảm tồn”. Thành công ghi mã đề nghị, hành động và tồn đã cập nhật/không thay đổi. Thiếu lý do từ chối hoặc lỗi nghiệp vụ cũng hiện cùng chỗ. Thông báo focus/scroll vào vùng thấy được; đổi role ẩn phản hồi cũ. Chỉ báo thành công khi localStorage lưu được. Không thay rule duyệt/từ chối hoặc quyền.

## Quyết định chốt — xử lý phiếu nhập đã lưu sai
Người học đồng ý: giữ nguyên phiếu gốc, không sửa/xóa trực tiếp phiếu đã lưu. Thủ kho gửi đề nghị điều chỉnh có lý do, Quản lý duyệt trước khi tồn thay đổi; lưu tham chiếu phiếu gốc, người yêu cầu/duyệt và thời điểm.
Quy tắc này đã chốt ở mức yêu cầu. Demo hiện chỉ có giảm tồn theo đề nghị và chưa có liên kết điều chỉnh về phiếu gốc; điều chỉnh tăng tồn do nhập thiếu cũng chưa có. Không tuyên bố toàn bộ quy trình này đã được triển khai/kiểm thử. Chưa cần thêm vào demo đang nghiệm thu.

## EX-03 — Ưu tiên scope khi thiếu nguồn lực
Người học đã chọn giữ kiểm tra tồn không âm và quyền duyệt điều chỉnh (Must-have), hoãn xuất Excel sang phase sau (Should/Could). Ước lượng giả định cho thấy vượt capacity nên áp dụng hoãn Excel ở kế hoạch MVP hiện tại. Báo cáo trong ứng dụng vẫn giữ, chưa bị cắt. Demo v10 không đổi; chưa cam kết MVP đầy đủ kịp 6 tuần.

## Quyết định người học — phương án 8 tuần
Người học chọn đề xuất 8 tuần để giữ kiểm soát tồn không âm, phân quyền, duyệt điều chỉnh và kiểm thử; Excel vẫn hoãn sang phase sau.
Capacity dev theo giả định: 2 × 8 × 5 × 80% = 64 dev-MD; nhu cầu M + 15% dự phòng = 55,2 dev-MD; chênh 8,8 dev-MD (không cộng thêm một lần buffer 15%). PM: 8 × 5 × 80% = 32 PM-MD; effort PM khả dĩ 12,75, hoặc 14,6625 nếu áp 15% dự phòng tương tự.
Đây là phương án lập kế hoạch trong bài tập, chưa phải stakeholder đã duyệt đổi deadline. Người học yêu cầu xác nhận effort với team, dependency và critical path trước khi cam kết. Chưa có lịch nghỉ, task assignment và duration thực tế nên không khẳng định đường găng hoặc ngày bàn giao cụ thể.
Nếu overhead dev tăng 30% thì capacity 56 dev-MD, chỉ hơn nhu cầu 0,8. Nếu effort M tăng 20%, nhu cầu sau buffer thành 66,24 dev-MD, vượt capacity 64 là 2,24. Phải tái ước lượng/thương lượng nếu giả định không còn đúng.
