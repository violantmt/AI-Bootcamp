# Tiến độ bài nộp PB03 — sau nghiệm thu v10

## Đã có
- Người học chọn đề đơn giản, Tier 2 phù hợp người chưa code.
- Prototype đã chạy, người học thử nhiều vòng và xác nhận demo v10 ổn.
- 27 test logic đạt, browser regression đạt; không có DB/auth production.
- Có REQ, Delegation Map 12 task, DoR, API contract, SQL tham khảo, scenario, test script và bằng chứng.
- Có phản hồi stakeholder về barcode, giải trình phân quyền, quyết định duyệt giảm tồn và nhiều review UI/nghiệp vụ thực tế.

## Cần hoàn thiện trước nộp
1. Viva mini: người học trả lời 3 câu bằng lời của mình.
2. Telemetry: giờ làm thật, token est hoặc chưa có, vòng lặp/rework, đối soát Human-edit theo thay đổi thực tế. Không suy giờ từ số phiên bản.
3. Rà EX-01: ≥5 câu hỏi gắn nhãn phù hợp, trạng thái quyết định/hard-stop trước và sau làm rõ; chưa coi danh sách AI tự viết là đã được người học phân loại.
4. Decision Log: có nhiều phản biện thực tế nhưng cần người học xác nhận phần nào là lỗi/thiếu sót AI và phần nào là đổi yêu cầu. Không tự kết luận đủ ≥3 lỗi AI thật; không tính AI tự phát hiện hoặc bài giả định thay người học.
5. Chuẩn hóa tài liệu thành bản hiện hành, để lịch sử thay đổi ở log; các file hiện có chứa phần bổ sung v1–v10, không nên nộp như bản chốt sạch.
6. Đóng gói cuối sau khi hoàn thiện; nơi nhận/hạn nộp chưa được cung cấp, chưa gửi ra ngoài.

## Viva mini theo Program §7.2
- AI sai hoặc thiếu ở đâu? Bạn phát hiện bằng cách nào, sửa gì?
- Vì sao cho AI dựng prototype ở L3, còn quyết định phân quyền phải do con người chốt?
- Cổng kiểm nào gác kết quả? Nếu test đỏ hoặc không xác minh được thì xử lý thế nào?

## Sau khi chốt bài chính
EX-02 WBS → EX-03 Estimation/trade-off → EX-04 Risk → EX-05 Weekly/Dashboard; EX-06 bản đầy đủ ≥15 task. Dùng cùng PB03 và capacity dự án giả định 1 PM + 2 dev/6 tuần; không lẫn thời lượng thực hành với thời lượng dự án.

Cập nhật: mở lại UAT phản hồi xóa theo phản hồi người học; v8 kiểm kỹ thuật đạt, nhưng chưa được người học nghiệm thu. Tạm dừng viva và nộp.

Trạng thái mới nhất: v10 đã được người học nghiệm thu; hết tạm dừng. Viva 1 đã chọn câu trả lời; Viva 2 có nguyên văn giải trình trước đó; Viva 3 chờ. Tiếp tục hoàn thiện hồ sơ, chưa nộp.

Cập nhật: người học đã chốt câu trả lời Viva 3; bộ câu trả lời viết đã có đủ 3 câu với nguồn hỗ trợ ghi rõ. Tiếp theo lấy giờ làm thật và rà Human-edit, rework; không coi tình huống giả định là lỗi thực tế.

Telemetry mới: người học cung cấp 90 phút tổng. Đã tổng hợp 12 thay đổi review/override và 9 vòng phiên bản, định nghĩa rõ trong TELEMETRY; token chưa có. EX-01 cần review bảng tổng hợp và chốt cách xử lý phiếu nhập đã lưu sai.

EX-02: đã có hai hiệu chỉnh do người học chọn — tách hướng dẫn thao tác và UAT thủ kho thật từ task gộp, kèm lý do và dependency. Các hoạt động này mới nằm trong kế hoạch, chưa thực hiện. Tiếp theo EX-03: ước lượng 3-point, giả định và so capacity 6 tuần.

EX-03: người học chọn đề xuất 8 tuần có điều kiện xác nhận effort/dependency/critical path, hoãn Excel; EST/TRADEOFF/REQ/WBS đã cập nhật. Chưa có baseline lịch được stakeholder phê duyệt. EX-04: AI đã soạn 14 rủi ro có L×I, owner/trigger và mức quyền/cổng; chờ người học chọn top-5 và phản biện mitigation.

EX-04: người học đã phản biện biện pháp AI tự kiểm chưa đủ và chỉ định kiểm soát cụ thể, DoD đã lưu. Tiếp theo chốt top-5 rủi ro; không coi những cổng mới là đã chạy/đạt.

EX-04: người học đã chọn Top-5 và biện pháp cụ thể/owner/trigger/review tuần; RPO/RTO còn phải chốt với nghiệp vụ, không tự ghi số. EX-05 đã có dữ liệu nguồn giả lập, báo cáo tuần và dashboard nhiều KPI có công thức/nguồn; thiếu dữ liệu ghi N/A. Chờ quyết định người học và review; chưa có hallucination số thật được phát hiện, không giả lập thành bằng chứng đạt.

EX-05: người học đã có quyết định dựa dữ liệu, giữ KPI có nguồn; cần task log để tính Adoption. Tiêu chí phát hiện hallucination thật vẫn chưa có bằng chứng, không dựng lỗi giả. EX-06 đầy đủ: đã có bản 20 task trace WBS/Risk, chờ người học review; giữ bằng chứng giải trình L1/L3 trước đây.

Đang tiếp tục EX-05 theo yêu cầu người học. Evidence templates đã tạo; Adoption/năng suất/token cost còn N/A khi chưa đủ dữ liệu. Cần dữ liệu task/baseline/usage thật hoặc giữ thiếu rõ ràng; hallucination thật chưa có evidence, không đánh dấu hoàn thành tiêu chí này. Chưa chốt EX-06 mở rộng.

EX-05 bổ sung: EX05-DATA-COLLECTION.md ghi nguồn usage/billing, thu dữ liệu phiên sau, inventory task và phân loại AI-assisted/Non-AI/Unknown. Chưa có billing thực hoặc inventory đầy đủ được đối soát, chưa tự tính Adoption/Cost.

Adoption phiên quan sát đã tính từ inventory hồi cứu 31 task có evidence: 100%; 20 mục kế hoạch/chưa xác minh loại trừ, không gán là đã làm. CSV và summary JSON đã lưu. Cần người học review độ bao phủ; W3 vẫn N/A, token cost/baseline/hallucination thật vẫn chưa có dữ liệu.

EX-06: đã ghi review người học cho F10/F11/F18 và mở rộng bốn trường trách nhiệm/gate/evidence cho 20 task; giữ task L1/L2 có giải trình. Cần rà tính nhất quán/hồ sơ chốt trước nộp, không yêu cầu thao tác production để hoàn tất bài lập kế hoạch. EX-05 thiếu hallucination thật vẫn ghi rõ.

## Kết luận rà soát EX-05 do người học xác nhận
Người học yêu cầu ghi trung thực: chưa phát hiện hallucination trong báo cáo EX-05 đã rà soát; thực tế người học cũng chưa thấy trường hợp nào ở đây.
Kết luận này giới hạn ở nội dung đã kiểm, không khẳng định mọi output AI đều đúng hoặc đã kiểm toàn bộ. Không tạo claim sai giả định và không dùng lỗi UI/đổi yêu cầu thay cho hallucination số liệu.
Trạng thái tiêu chí Workbook “≥1 phát hiện hallucination thật + cách sửa”: CHƯA CÓ BẰNG CHỨNG, không đánh dấu đạt; log hiện không có trường hợp phát hiện được xác nhận. Giữ nguyên báo cáo/KPI có nguồn và N/A cho dữ liệu thiếu.

Dashboard hiện ưu tiên Knowledge Health c1–c7. KNOWLEDGE-HEALTH-KPI.md và knowledge-health/* có baseline/finding/plan; RTM-DEMO-V10.md đã lập. Ưu tiên tiếp theo chuẩn hóa 8 doc, bổ sung review 3 artefact và chấm c7; không ghi đã hoàn thiện toàn bộ hồ sơ chỉ vì dashboard đã chạy. Project Health bản trước vẫn giữ riêng.

c7 đã hoàn tất chấm có hướng dẫn: 8/8=100%, người học xác nhận riêng từng câu trong hội thoại. Dashboard cập nhật snapshot này. c2 còn thiếu change-set evidence; c3 freshness và c5 review evidence vẫn cần sửa riêng.

Knowledge Health snapshot v2: c7 người học chấm 8/8=100%. C2 bổ sung diff ngữ nghĩa 9 revision package với code/doc liên quan, 9/9=100% theo đơn vị đợt demo; không giả Git history, không suy commit-level. c3=20%, c5=70% vẫn ưu tiên khắc phục. Gói dashboard v2 đã cập nhật.
