# EX-04 — Risk Register PB03, bản AI để người học review

Phạm vi: kế hoạch MVP thật đề xuất 8 tuần, Excel phase sau; demo v10 đã nghiệm thu nhưng không có auth/DB production.
L/I là likelihood/impact, thang 1–5 do AI giả định để ưu tiên, không phải xác suất đo. Score=L×I. Owner là vai trò giả định, chưa có người thật được giao. Trigger là điều kiện cần rà lại. Rủi ro có AI ghi rõ mức quyền/cổng; A+ không tự động cấp L4 hoặc quyền chạy hệ thật.

| ID | Nhóm | Rủi ro | L | I | L×I | Giảm thiểu cụ thể | Owner dự kiến | Trigger | AI được tới đâu | Cổng chặn |
|---|---|---|---:|---:|---:|---|---|---|---|---|
| R01 | Tiến độ | Effort AI thấp hơn khả năng thực tế của team | 4 | 4 | 16 | Team review 3-point trước chốt lịch; cập nhật estimate khi task vượt biên M, không cắt gate | PM + dev | Trước cam kết; task vượt M | L2 | Estimate cần người chọn, không tự cam kết |
| R10 | Chất lượng | Không có QA riêng nên bỏ sót negative/boundary cases | 4 | 4 | 16 | Phân công dev review chéo, checklist AC-role, dành effort test riêng E10; không bỏ test lỗi để xanh | Dev lead | Trước nghiệm thu và mỗi thay rule | L3 draft test | Gate fail-closed: test thiếu/đỏ thì chưa đạt |
| R11 | AI | AI viết code/tài liệu hoặc báo cáo test sai, người dùng tin ngay | 4 | 4 | 16 | Map AC→test/code, chạy script thật, ghi log exit/count; người đọc kết quả và spot-check chức năng | Người điều phối + dev | Mỗi output AI quan trọng | L1/L2 tài liệu, L3 sandbox | Không evidence hoặc không pass thì chặn, không tự approve |
| R03 | Dữ liệu | Hai giao dịch đồng thời làm tồn âm hoặc lệch lịch sử | 3 | 5 | 15 | Transaction/khóa hoặc cập nhật có điều kiện; test hai yêu cầu cạnh tranh và kiểm đối soát | Dev backend | Mỗi đổi logic stock | L3 nháp; A+ khi áp vào hệ thật | Test atomic/concurrency bắt buộc pass và người review |
| R04 | Quyền | Thủ kho tự duyệt hoặc gọi API sửa tồn trái quyền | 3 | 5 | 15 | Kiểm role ở backend thật, negative test mọi endpoint; role selector demo không đủ | Dev backend | Mọi thay đổi quyền/API | L1 thiết kế; A+ áp dụng | Người duyệt quyền + test 401/403, fail thì chặn |
| R05 | Điều chỉnh | Duyệt lặp hoặc hai đề nghị cùng làm giảm quá tồn | 3 | 5 | 15 | Duyệt pending một lần trong transaction, kiểm lại tồn tại thời điểm duyệt; thử duyệt lặp/cạnh tranh | Dev backend | Mỗi thay đổi flow duyệt | L3 sandbox; A+ hệ thật | Test đúng một lần/không âm + human review |
| R08 | Vận hành | Mất dữ liệu do chưa có backup/phục hồi kiểm chứng | 3 | 5 | 15 | Thiết lập backup bản thật và diễn tập restore trên môi trường riêng, đối soát dữ liệu phục hồi | Dev vận hành | Trước phát hành; diễn tập không đạt | L1 nháp; A+ chạy thật | Chưa restore thử đạt thì chưa phát hành |
| R12 | AI/Dữ liệu | Dữ liệu nội bộ/khóa bị đưa vào prompt hoặc demo | 3 | 5 | 15 | Chỉ dùng dữ liệu giả; kiểm file trước gửi/đóng gói, dùng cấu hình bảo mật được cho phép cho hệ thật | Người điều phối | Trước mọi upload/integration | L0 đối với dữ liệu thật ngoài phạm vi | Thiếu quyền hoặc phát hiện secret thì dừng, không gửi |
| R02 | Phụ thuộc | Đủ MD nhưng task tuần tự/chờ hạ tầng làm lỡ 8 tuần | 3 | 4 | 12 | Gán owner/duration, lập dependency và critical path; xác nhận quyền/môi trường trước build thật | PM | Trước baseline; prerequisite chưa sẵn | L2 | Chưa xác minh đường găng thì không xác nhận lịch |
| R06 | Tồn đầu kỳ | Dữ liệu Excel sai hoặc chưa thống nhất cách mở sổ | 3 | 4 | 12 | Stakeholder chốt dữ liệu và phương án import/phiếu mở đầu; đối soát có ký nhận trước nạp | PM + Quản lý kho | Trước nạp dữ liệu thật | L1/L2; A+ dữ liệu thật | Không nạp khi thiếu nguồn/đối soát/duyệt |
| R07 | Lịch sử | Xóa mã hàng mất truy vết hoặc tái dùng mã gây nhầm | 3 | 4 | 12 | Xóa nghiệp vụ bằng tombstone, giữ mã/phiếu/audit; test stock0/xóa/reload và không dùng lại mã | Dev backend | Mỗi thay đổi xóa/danh mục | L3 sandbox; A+ hệ thật | Test lịch sử + quyền + review schema |
| R09 | Người dùng | UI báo kết quả xa mục thao tác làm thao tác nhầm/lặp | 4 | 3 | 12 | Phản hồi thành công/lỗi tại chỗ, nêu mã/diễn biến tồn; cho thủ kho UAT theo kịch bản | PM + dev UI | UAT phát hiện không biết thao tác đã xong | L3 demo | UAT người dùng đạt; không thay bằng test AI |
| R13 | Scope | Barcode/Excel hoặc yêu cầu mới quay vào MVP làm vượt effort | 4 | 3 | 12 | Change request ghi tác động REQ/WBS/estimate, chỉ đưa vào khi stakeholder chốt trade-off | PM | Mỗi yêu cầu mới | L2 | Không tự tăng scope hoặc cam kết mốc |
| R14 | AI/Quản trị | Có file đẹp nhưng review người học chỉ là hình thức | 3 | 4 | 12 | Giữ dấu vết phản biện, phân biệt AI gợi ý và người viết; viva và UAT thật, không dựng lỗi/telemetry | Người điều phối | Chốt bài/duyệt artefact | L1/L2 | Thiếu bằng chứng hiểu thì chưa đánh dấu đạt |

## Top-5 AI đề xuất, chưa phải người học đã chọn
1. R10 — thiếu QA, 16 điểm.
2. R11 — output AI thiếu kiểm chứng, 16 điểm.
3. R01 — effort không sát team, 16 điểm.
4. R03 — tồn sai khi đồng thời, 15 điểm.
5. R04 — vượt quyền điều chỉnh, 15 điểm.
R05/R08/R12 cũng 15 điểm; không coi ngoài top-5 là không quan trọng. Khi bằng điểm, ưu tiên hậu quả tài sản/dữ liệu và khả năng ngăn chặn trước rollout; người học có thể thay thứ tự.

## Người học cần review để hoàn thiện EX-04
Chọn/điều chỉnh top-5; xem điểm nào không sát thực tế, mitigation nào chưa khả thi và sửa cụ thể. Không coi “cẩn thận hơn” hay “AI tự kiểm tra” là biện pháp đủ. Chưa có test production/UAT thủ kho thật thì các cổng tương ứng vẫn chưa qua.

## Review người học — rủi ro AI tự kiểm code
Người học đánh giá “AI tự kiểm tra thật kỹ” là CHƯA ĐỦ vì có thể bỏ sót hoặc kết luận sai. Yêu cầu bổ sung: review code bởi dev cho logic tồn/transaction/quyền; unit/integration thực, gồm invalid/concurrency/unauthorized; hai dev review chéo code/test; UAT thủ kho; bằng chứng test report/log hoặc CI; đưa vào DoD.
Cập nhật R11 và liên quan R03/R04/R10: AI không tự gỡ chốt nghiệm thu. Dev review bắt buộc, kiểm thử chạy thật, người có thẩm quyền đọc bằng chứng; cổng đỏ/chưa chạy/chưa xác minh thì chặn bàn giao. Hai dev là vai trò trong đội giả định, chưa có review code production thực tế diễn ra.
Đã có phản biện mitigation cụ thể từ người học. Top-5 trong bảng vẫn là AI đề xuất, người học chưa chốt thứ tự.

## Top-5 hiện hành — người học đã chốt (thay thứ tự AI đề xuất trước)
| Ưu tiên | ID | Rủi ro | L | I | Điểm | Kiểm soát người học bổ sung | Owner dự kiến | Trigger |
|---|---|---|---:|---:|---:|---|---|---|
| 1 | R03 | Đồng thời làm tồn sai/âm | 3 | 5 | 15 | DB transaction, locking phù hợp, concurrency testing | Dev backend | Đổi logic cập nhật tồn hoặc test tranh chấp lỗi |
| 2 | R04 | Sai phân quyền | 3 | 5 | 15 | RBAC, kiểm quyền tại API, negative testing | Dev backend + reviewer | Đổi role/API hoặc truy cập trái quyền lọt |
| 3 | R05 | Duyệt trùng | 3 | 5 | 15 | Idempotency, kiểm trạng thái, xử lý một lần trong transaction | Dev backend | Request lặp/đồng thời hoặc biến động tồn lặp |
| 4 | R11 | Code AI sai chưa kiểm chứng | 4 | 4 | 16 | Code review, automated tests và bằng chứng trước nghiệm thu | Dev reviewer + người điều phối | Output AI mới hoặc thiếu evidence |
| 5 | R08 | Mất dữ liệu | 3 | 5 | 15 | Backup định kỳ, diễn tập restore, chốt RPO/RTO theo nghiệp vụ | Dev vận hành + Quản lý kho | Backup/restore lỗi hoặc trước triển khai |

Điểm số vẫn là AI giả định, người học chốt ưu tiên theo hậu quả nghiệp vụ chứ không chỉ sắp điểm giảm dần. Owner là vai trò, cần gán người thật trước triển khai.
RPO = lượng dữ liệu có thể chấp nhận mất tính theo thời gian; RTO = thời gian phục hồi chấp nhận được. Chưa có giá trị cụ thể được duyệt; không tự cam kết số giờ. Chốt với chủ nghiệp vụ và kiểm bằng diễn tập.
Người học yêu cầu review Risk Register hằng tuần; tiến độ/nguồn lực tiếp tục theo dõi ngoài Top-5. Các mitigation chưa thực thi trên hệ thật; mock không chứng minh đã có locking/RBAC thật.

## Kiểm soát EX-06 được người học bổ sung
Duyệt tồn: Quản lý xác minh chứng từ, requester không được tự duyệt, RBAC/SoD/audit. Bản thật cần định danh người dùng riêng; role selector của demo không chứng minh đã thực thi SoD.
Migration: DBA/người được ủy quyền review/phê duyệt, staging pass, backup và chứng minh restore; AI chỉ nháp script/test/rollback, không tự chạy production.
Release: Release Owner xem DoD, kiểm thử quan trọng, rủi ro và rollback plan, phê duyệt đúng version/môi trường; người được phép phát hành. Least privilege/HITL/evidence là điều kiện xuyên suốt, không tự cấp thêm quyền AI.
Chưa thực hiện các approval/staging/restore thật, không gán PASS.
