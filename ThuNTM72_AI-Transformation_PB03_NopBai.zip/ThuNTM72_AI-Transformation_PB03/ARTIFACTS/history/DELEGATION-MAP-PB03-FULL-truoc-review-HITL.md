# EX-06 — Delegation Map đầy đủ PB03, bản AI chờ review

Input: WBS-PB03.md, RISK-PB03.md và quyết định người học. ≥15 task, map nhóm 5-loại, mức AI, A/A+, người duyệt và cổng/lý do.
L là mức AI thực sự được cấp trong task. A+ là yêu cầu kiểm soát tăng cường; không tự nâng lên L4. Không cấp L5. Các task hệ thật dưới đây là quy tắc lập kế hoạch, chưa có quyền thực thi, không có tài khoản/hệ thật được kết nối.

| ID | Trace | Task | Nhóm | Mức AI | Leash | Ai gỡ chốt | Cổng và lý do |
|---|---|---|---|---|---|---|---|
| F01 | 1.1 | Nháp requirement/AC | AI-do | L1 | A | Người học/PM duyệt | So brief và quyết định hiện hành, đánh dấu thiếu |
| F02 | 1.1 | Chốt scope và trade-off 8 tuần | Human-do | L2 hỗ trợ | A | PM/chủ nghiệp vụ | AI đề xuất, người chọn; chưa có quyền cam kết stakeholder |
| F03 | 1.2/2.1 | Nháp schema và API | AI-do | L1 | A | Dev review | Khóa/ràng buộc/trace; bản nháp chưa chạy hệ thật |
| F04 | 1.3/1.4 | Dựng UI/demo dữ liệu giả | AI-do | L3 | A | Người học thử | Test + UAT demo; sandbox, sửa được, không dữ liệu thật |
| F05 | 1.6 | Sinh/chạy test mock | AI-do | L3 | A | Người học đọc kết quả | Exit/count đúng, invalid/role/stock; test đỏ chặn |
| F06 | 2.1/R04 | Đề xuất chính sách phân quyền | Human-review | L1 | A+ | PM/chủ hệ thống đích thân duyệt | Cố ý giữ L1 dù AI viết được; không để AI tự cấp quyền |
| F07 | 2.1/R04 | Áp cấu hình quyền lên hệ thật | Human-do | L1 nháp lệnh | A+ | Chủ hệ thống | Không tự chạy; cần quyền rõ và negative test; chưa được phép trong bài |
| F08 | 2.3/R03 | Sinh code transaction/xuất kho | AI-do | L3 sandbox | A+ | Dev reviewer | Concurrency/atomic/không âm và review người trước dùng thật |
| F09 | 2.4/R05 | Sinh luồng duyệt idempotent | AI-do | L3 sandbox | A+ | Dev reviewer | Duyệt đúng một lần, trạng thái/role; không tự deploy |
| F10 | 2.4 | Duyệt đề nghị điều chỉnh tồn thật | Human-do | L0 đọc dữ liệu được phép | A+ | Quản lý kho | AI không tự quyết chứng từ/tồn; người duyệt và audit |
| F11 | 2.1/R07 | Chạy migration DB thật | Human-do | L1 nháp kế hoạch | A+ | Chủ hệ thống/dev có quyền | Backup/rollback và schema review; chưa được phép thực thi |
| F12 | 2.2/R06 | Nạp tồn đầu kỳ thật | Human-review | L1 nháp đối soát | A+ | Quản lý kho + chủ dữ liệu | Nguồn/đối soát/signed approval trước nạp; không tự dùng dữ liệu thật |
| F13 | 2.6a | Sinh báo cáo/query nháp | AI-do | L3 sandbox | A | Dev/PM kiểm số | Nguồn rõ, đối soát; thiếu dữ liệu N/A; không tự công bố |
| F14 | 2.7/R11 | Review chéo code và test của AI | Human-review | L2 hỗ trợ | A+ | Hai dev review | AI review thêm, không thay dev approval và test thực |
| F15 | 2.8/R08 | Nháp backup/restore, đề xuất RPO/RTO | AI-do | L1 | A+ | Vận hành + chủ nghiệp vụ | Chốt RPO/RTO, diễn tập môi trường được phép; không tự backup dữ liệu thật |
| F16 | 2.9 | Nháp hướng dẫn sử dụng | AI-do | L3 | A | PM/thủ kho review | Chỉ mô tả chức năng thật đã có; bấm thử theo hướng dẫn |
| F17 | 2.10 | UAT với thủ kho và nghiệm thu | Human-do | L1 hỗ trợ kịch bản | A | Thủ kho + PM | Người dùng thử thật, không ký thay hoặc bịa kết quả |
| F18 | 2.11 | Push/merge/release hệ thống | Human-do | L1 nháp checklist | A+ | Chủ release | Các gate đạt và người cho phép; AI không tự push/merge/release |
| F19 | R12 | Gửi khóa/dữ liệu nhạy cảm cho AI ngoài phạm vi | AI-không-nên | L0, không cấp hành động | A+ | Chủ dữ liệu/bảo mật | Thiếu quyền/nguồn kiểm soát thì hard-stop; chỉ dữ liệu giả trong bài |
| F20 | R11/EX05 | Tự review chéo trace và số liệu | AI-review | L2 | A | Người học/PM phân xử | Chỉ dẫn nguồn thực, không tự ký nghiệm thu hoặc điền số thiếu |

## Bằng chứng giải trình đã có
Người học đã tự giải thích: demo giả lập an toàn/sửa được, còn phân quyền ảnh hưởng tài sản/bảo mật và trách nhiệm cần con người quyết. Giữ F06 ở L1, không cấp cao chỉ vì AI làm được. Nguyên văn trong VIVA và map rút gọn.
Các hàng F04/F05/F08/F09/F13/F16 dùng L3 vì là thực thi trong sandbox kiểm được; nơi có rủi ro tồn/quyền áp A+ và review bắt buộc. Không coi sandbox pass là duyệt áp hệ thật.

## Chờ người học review bản mở rộng
F10 duyệt điều chỉnh, F11 migration, F18 release là Human-do; AI chỉ hỗ trợ trong phạm vi ghi ở bảng. Người học có thể giữ thấp thêm hoặc chỉnh gate/owner. Chưa tự ghi người học đã duyệt toàn bộ 20 hàng.
