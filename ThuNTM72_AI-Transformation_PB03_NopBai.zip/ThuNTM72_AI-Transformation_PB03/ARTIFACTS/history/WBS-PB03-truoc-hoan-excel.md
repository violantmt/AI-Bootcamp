# EX-02 — WBS PB03, bản AI để người học review

WBS là bảng chia việc thành đầu ra nhỏ. Input: yêu cầu PB03 và quyết định trong phiên học. Bản này lập cho dự án giả định 1 PM + 2 dev, 6 tuần; không coi 90 phút học là thời gian làm toàn dự án.
Phạm vi bản mẫu PB03 có xuất kho, báo cáo, Excel; demo Tier 2 hiện chỉ là một phần. Chưa estimate hoặc kết luận làm kịp 6 tuần.

## Wave 1 — Demo hiện có và hoàn thiện hồ sơ
| ID | Epic → task | Pha SDLC | Đầu ra / trạng thái | Phụ thuộc |
|---|---|---|---|---|
| 1.1 | Yêu cầu → chốt scope, role, số lượng và AC | Analysis | REQ; có nội dung, cần chuẩn hóa bản chốt | — |
| 1.2 | Thiết kế → API mock, schema và lưu demo | Design | API contract, schema SQL; có, SQL chưa chạy thật | 1.1 |
| 1.3 | Danh mục → tạo/sửa/xóa theo role và tồn | Code | Prototype v10; đã có | 1.2 |
| 1.4 | Nhập kho → nhập nhiều dòng, không trùng, kiểm toàn phiếu | Code | Prototype; đã có | 1.2, 1.3 |
| 1.5 | Giảm tồn → đề nghị, duyệt/từ chối, lịch sử | Code | Prototype; đã có | 1.2, 1.3 |
| 1.6 | Kiểm thử → hợp lệ/sai/quyền, lưu và tải lại | Test | Script và bằng chứng; đã chạy, giới hạn ghi rõ | 1.3, 1.4, 1.5 |
| 1.7 | Nghiệm thu → người học thử và phản biện | UAT | Nghiệm thu demo v10, Decision Log; đã có | 1.6 |
| 1.8 | Hồ sơ → REQ hiện hành, trace AC-test, telemetry và viva | Documentation | 90 phút/3 câu viết đã có; chuẩn hóa hồ sơ chưa xong | 1.7 |

## Wave 2 — MVP kho đầy đủ, chưa thực hiện
| ID | Epic → feature | Pha SDLC | Đầu ra | Phụ thuộc |
|---|---|---|---|---|
| 2.1 | Nền tảng → thiết kế xác thực/phân quyền thật, audit và DB | Design/Code | Thiết kế và triển khai có kiểm soát; không dùng role selector demo làm auth thật | 1.1, 1.2 |
| 2.2 | Dữ liệu → xác minh nhu cầu tồn đầu kỳ/migration Excel | Analysis/Data | Chỉ làm import khi stakeholder xác nhận; số 10/20 hiện là seed giả | 1.1 |
| 2.3 | Xuất kho → phiếu xuất, kiểm tra đủ tồn, chống tranh chấp | Design/Code/Test | Luồng xuất thật có test; chưa có trong demo | 2.1 |
| 2.4 | Điều chỉnh → giữ phiếu gốc, điều chỉnh tăng/giảm có liên kết và duyệt | Design/Code/Test | Truy vết phiếu sai, không sửa/xóa trực tiếp; chưa triển khai đầy đủ | 2.1, 1.5 |
| 2.5 | Tra cứu → lịch sử/tồn và cảnh báo tồn tối thiểu | Code/Test | Cảnh báo tối thiểu chưa có; tồn/lịch sử mới có bản demo | 2.1 |
| 2.6 | Báo cáo → nhập–xuất–tồn theo kỳ, xuất Excel, quyền xem | Code/Test | Theo brief, chưa triển khai | 2.3, 2.4, 2.5 |
| 2.7 | Độ tin cậy → backup/restore, concurrency, kiểm toàn vẹn và load | Test/Operations | Bằng chứng cho dữ liệu thật và khoảng 20 người dùng; chưa có | 2.1, 2.3, 2.4, 2.6 |
| 2.8 | Vận hành → runbook và chuẩn bị triển khai | Operations | Hướng dẫn khởi động/vận hành, phân công hỗ trợ; chưa thực hiện | 2.7 |
| 2.9 | Đào tạo → viết hướng dẫn thao tác ngắn cho thủ kho | Documentation/Training | Hướng dẫn nhập, xuất, tra tồn, đề nghị điều chỉnh; ảnh minh họa và xử lý lỗi phổ biến. Chỉ mô tả chức năng đã triển khai; hướng dẫn xuất chờ 2.3 | 2.3, 2.4, 2.5 |
| 2.10 | Nghiệm thu → thủ kho thực tế dùng thử và phản hồi | UAT | Kịch bản thao tác, kết quả thực tế, phản hồi và danh sách điểm cần sửa; chưa tổ chức, không thay bằng UAT của người học | 2.7, 2.9 |
| 2.11 | Hoàn thiện → sửa điểm chưa đạt, kiểm lại và nghiệm thu phát hành | Rework/Test/Release | Xử lý phản hồi 2.10, cập nhật hướng dẫn nếu đổi UI/quy trình, chạy lại ca liên quan; chỉ phát hành khi được cho phép | 2.8, 2.10 |

## Wave 3 — Ngoài MVP
Barcode/camera, nhiều kho, kế toán, dự báo: chỉ khảo sát/ước lượng khi có yêu cầu riêng; không tự đưa vào kế hoạch 6 tuần.

## Người học review để đạt EX-02
Workbook yêu cầu ≥2 task người học thêm/bớt/chỉnh so với bản AI, kèm lý do. Bảng trên mới là AI đề xuất; chưa tính là đã được người học review.
Hãy xem công việc có bỏ sót không, việc nào ngoài scope; không xóa lịch sử/audit để làm bảng gọn. Có thể bổ sung task hướng dẫn người dùng hoặc kiểm xử lý dữ liệu lỗi nếu bạn thấy cần, nhưng quyết định phải do bạn chọn.

## Review EX-02 do người học thực hiện
Người học chọn bổ sung/tách rõ hai công việc:
1. Viết hướng dẫn thao tác ngắn: giúp thủ kho mới làm quen, giảm sai sót nhập/xuất/tra tồn. Đã tách thành 2.9.
2. Cho thủ kho dùng thử (UAT): kiểm tính dễ dùng và quy trình thực tế, thu phản hồi trước triển khai. Đã tách thành 2.10; 2.11 là bước AI bổ sung để xử lý phản hồi, không tính thêm một quyết định của người học.
Lý do chung nguyên văn: “Một hệ thống không chỉ cần đáp ứng đúng yêu cầu chức năng mà còn phải dễ sử dụng và phù hợp với người dùng thực tế. Hai công việc này giúp giảm rủi ro khi triển khai và tăng khả năng người dùng chấp nhận hệ thống.”

Bản AI trước đã gộp “UAT MVP và hướng dẫn dùng” trong 2.8. Đây là hai thay đổi làm rõ/phân tách task, không khẳng định AI đã bỏ sót hoàn toàn. Nhánh 1.7 là nghiệm thu demo của người học, không chứng minh đã có thủ kho thực tế dùng thử.
Trạng thái: đã có ≥2 thay đổi WBS do người học review và lý do; chưa estimate, chưa tổ chức các hoạt động mới. 90 phút là tổng số người học đã cung cấp trước đó, không tự tăng hoặc gán riêng thời lượng EX-02.
