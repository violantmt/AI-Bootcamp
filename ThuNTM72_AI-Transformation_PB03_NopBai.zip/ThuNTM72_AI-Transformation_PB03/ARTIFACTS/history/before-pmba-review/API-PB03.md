# API-PB03 — Contract mock hiện hành

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Cách gọi và ranh giới
`api(state, role, method, path, payload={}, now=...)` trong prototype/model.mjs trả `{status, body, next?}`. Không có REST server thật; status mô phỏng HTTP. Role chỉ keeper/manager, không hợp lệ trả401. API không đổi state gốc: next chỉ được UI áp dụng sau localStorage ghi thành công. GET trả bản sao. Endpoint lạ trả404.

| Method / path | Role được dùng | Input chính | Thành công | Lỗi chính |
|---|---|---|---|---|
| GET /api/products | keeper/manager | — | 200 danh sách {id,name,unit,stock,active?} | 401 |
| GET /api/receipts | keeper/manager | — | 200 phiếu {id,at,actor,lines} | 401 |
| POST /api/products | manager | {id,name,unit} | 201 product tồn0 + next | 400 invalid,403 sai role,409 mã trùng/đã xóa |
| POST /api/products/manage | manager | {action,originalId,id?,name?,unit?} | 200 {message}+next | 400 invalid,403 role,404 mã không tồn tại,409 ràng buộc |
| POST /api/receipts | keeper | {lines:[{productId,quantity}]} | 201 phiếu+next | 400 dữ liệu/overflow,403 role,409 dòng trùng |
| POST /api/adjustments | keeper | {productId,quantity,reason} | 201 request pending+next, tồn chưa đổi | 400 dữ liệu/lý do,403 role,409 vượt tồn |
| POST /api/adjustments/review | manager | {id,action:approve/reject,note?} | 200 request cập nhật+next | 400 action/lý do,403 role,404 request,409 đã xử lý/không đủ tồn |

## Danh mục
Mã trim/uppercase, 1–30 ký tự A-Z/0-9/_/-, tên trim1–100, unit trim1–30. Không tạo lại mã hiện có hoặc lưu trong deletedProducts.
manage edit: originalId tìm hàng; sửa tên; đổi mã/unit chỉ khi tồn0 và chưa có phiếu/đề nghị/liên quan theo model; chặn mã trùng/đã xóa.
manage delete: tồn khác0 trả409 với số tồn; tồn0 được xóa khỏi products, giữ snapshot trong deletedProducts cùng người/giờ, giữ phiếu/đề nghị/audit. Đề nghị pending của mã đó được đóng rejected với lý do. Không yêu cầu “chưa có lịch sử”.
Nhánh archive/restore còn trong model để tương thích lịch sử; UI v10 không có các nút đó. Hàng inactive không được nhập/gửi đề nghị mới; archive pending bị chặn. Không có mergeLines trong bản hiện hành.

## Phiếu nhập
Toàn phiếu cần ít nhất một dòng, hàng tồn tại/active, quantity là safe integer >0. Kiểm tất cả dòng và trùng trước tạo next; cộng tồn vượt giới hạn số nguyên an toàn bị chặn. Bất kỳ lỗi giữ state gốc, không lưu một phần. Phiếu ID PN-n, actor demo, timestamp và lines.
UI dùng select không cho chọn trùng và không có gộp. API vẫn chặn trùng để không chỉ tin UI.

## Đề nghị giảm và duyệt
Quantity nguyên >0, không vượt tồn hiện tại; reason trim1–500 ký tự. Request DC-n có productId/quantity/reason/status pending/requestedBy/requestedAt, chưa trừ tồn.
Review chỉ pending: approve kiểm hàng active/đủ tồn tại lúc duyệt, trừ một lần và ghi beforeStock/afterStock; reject cần note không trống, tối đa500, không đổi tồn. Cả hai ghi status/reviewedBy/reviewedAt/reviewNote. Đề nghị đã xử lý trả409, không xử lý lại.

## Phản hồi/lưu trữ và hạn chế
Tạo mã: createMessage dưới nút Tạo. Sửa/xóa: catalogMessage trong mục chỉnh sửa. Review: reviewMessage dưới lịch sử. Thành công sau khi ghi snapshot localStorage; lỗi ghi không báo thành công.
Không có endpoint sửa/xóa phiếu đã lưu, xuất kho, tăng điều chỉnh gắn phiếu gốc hoặc auth thật. Person demo chỉ chuỗi theo role; không bảo đảm requester khác approver. Không có DB transaction/locking/đồng thời thật; schema.sql chỉ bản tham khảo.

## Review cần người học thực hiện
Kiểm ba ý: Quản lý quản lý danh mục nhưng không lập phiếu; Thủ kho lập phiếu/đề nghị nhưng không duyệt; tồn0 xóa được và giữ lịch sử. Tài liệu chuẩn hóa code v10, chưa có review trực tiếp người học cho bản contract này; xem REVIEW-PACKET-PB03.md.
