# TEST-SCENARIOS-PB03 — Bộ kiểm demo hiện hành

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Phạm vi và evidence
Script logic prototype/test.mjs có 27 tests theo báo cáo đã lưu; browser prototype/test_browser.py kiểm UI/role/lưu tải lại. Đây là script/nguồn tồn tại, không tự tuyên bố vừa chạy lại ở lần sửa tài liệu. Không thay UAT thủ kho thật hoặc test production. Kết quả lịch sử trong KET-QUA-KIEM-THU.md.

| Scenario | Given / When / Then | Nguồn kiểm hiện có |
|---|---|---|
| TS01 nhập đúng | Bút10, thủ kho nhập3/lưu →13 và có phiếu/lịch sử | test.mjs AC08; browser |
| TS02 nhập sai | Số -3/0/1.5/NaN/overflow → từ chối, không đổi tồn | test.mjs quantity/overflow; browser âm |
| TS03 lỗi chỉ dòng | Bút trống, Sổ10 → lỗi dòng Bút, giữ tồn; bỏ dòng Bút rồi lưu → Sổ20→30 | model test và browser |
| TS04 không trùng | Đã chọn Bút, thêm dòng chọn Sổ, khóa Bút ở dòng2; hết hàng chặn thêm; xóa dòng trả lựa chọn | browser option disabled/add |
| TS05 atomic phiếu | Một dòng đúng và một dòng sai → không lưu phiếu, mọi tồn không đổi | test.mjs Phiếu nhiều dòng lỗi |
| TS06 quyền nhập | Role rỗng401, manager403, keeper hợp lệ; UI ẩn lập phiếu cho manager | model + browser |
| TS07 quyền danh mục | Chỉ manager tạo; mã trùng/thiếu field bị chặn; tồn hàng mới0 | model + browser |
| TS08 sửa/xóa | Hàng có tồn không đổi mã/unit; tên sửa được; tồn>0 không xóa và báo số tồn; tồn0 xóa thành công dù có lịch sử, giữ phiếu/đề nghị sau reload | model + browser |
| TS09 xác nhận xóa | Tồn0 mở xác nhận trong trang; Hủy giữ mã, Xác nhận xóa thành công; đổi role/hàng đóng xác nhận | browser có hủy/confirm; đổi role được code xử lý, chưa có test riêng đầy đủ mọi biến thể |
| TS10 đề nghị | Keeper gửi quantity>0 và reason; thiếu lý do/số sai/vượt tồn/sai role bị chặn; gửi hợp lệ không đổi tồn | model + browser |
| TS11 review | Manager duyệt một lần; kiểm lại tồn, không âm; reject cần lý do và giữ tồn; keeper không duyệt | model + browser |
| TS12 vị trí feedback | Tạo dưới nút Tạo; sửa/xóa dưới mục chỉnh sửa; review dưới lịch sử; lỗi/thành công đúng kết quả | browser create/catalog/reviewMessage |
| TS13 local persistence | Lưu/tải lại giữ danh mục/tồn/phiếu/lịch sử; không lộ tham chiếu GET; test profile không chạm dữ liệu học viên | model JSON roundtrip + browser reload |
| TS14 giới hạn | Lỗi/quota localStorage, identity SoD thật, DB concurrency, backup/restore production → chưa kiểm đủ, không ghi PASS | Code có nhánh lỗi ghi; cần kiểm riêng/hệ thật |

## Cổng nghiệm thu
Đối chiếu AC trong REQ/RTM. Ghi PASS/FAIL/SKIP/CHƯA CHẠY và version/command/count thật, không hạ test để xanh. Sửa lỗi → retest liên quan. Scenario đủ nguồn không đồng nghĩa mọi trường hợp edge/production đã được kiểm.
Review người học cho chính artefact scenario còn chờ; xem REVIEW-PACKET-PB03.md. Câu giả định để luyện và hallucination thật là loại bằng chứng khác, không đưa vào số test thực chạy.
