# REQ-PB03 — Yêu cầu hiện hành

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## 1. Mục tiêu và phạm vi
Bài toán kho văn phòng phẩm nội bộ, Tier 2 cho người chưa code. Người học đã nghiệm thu demo v10. Đầu ra hiện có: HTML tương tác, API mock trong trình duyệt, localStorage, schema SQL tham khảo và script test; không có backend/DB/auth production.
MVP theo brief còn có xuất kho, cảnh báo tồn tối thiểu, báo cáo theo kỳ và phân quyền thật. Đây là kế hoạch tương lai, không phải demo đã có. Phương án dự án: 1 PM + 2 dev, đề xuất 8 tuần thay brief 6 tuần; Excel phase sau, stakeholder chưa phê duyệt deadline. Ngoài scope: barcode, nhiều kho, kế toán, dự báo.

## 2. Quyền và chức năng demo
| ID | Yêu cầu hiện hành | Tiêu chí chấp nhận |
|---|---|---|
| KH01 | Thủ kho lập phiếu nhập/đề nghị giảm; Quản lý quản lý danh mục và duyệt | Mock từ chối sai role; UI ẩn chức năng không có quyền; chưa đăng nhập thật |
| KH02 | Quản lý tạo mã duy nhất, tên và đơn vị; tồn khởi đầu 0 | Mã chuẩn hóa uppercase, 1–30 A-Z/0-9/_/-, tên 1–100, đơn vị 1–30; trùng mã hiện có/đã xóa bị chặn |
| KH03 | Quản lý sửa thông tin và xóa hàng tồn 0 | Tên được sửa; mã/đơn vị chỉ đổi nếu tồn 0, chưa dùng. Xóa tồn 0 kể cả có lịch sử: giữ snapshot/phiếu/audit, đóng đề nghị chờ. Còn tồn báo rõ số lượng, không xóa |
| KH04 | Số lượng nhập là số nguyên an toàn >0 | Âm/0/số lẻ/không hợp lệ bị từ chối, báo đúng dòng; overflow tồn bị chặn |
| KH05 | Mỗi mã hàng chỉ một dòng phiếu | Hàng đã chọn bị vô hiệu ở dòng khác; thêm dòng chọn hàng chưa có; hết hàng chặn thêm; mock từ chối trùng |
| KH06 | Phiếu nhiều dòng không được lưu một phần | AC02: bất kỳ dòng nào sai thì không lưu phiếu và tất cả tồn không đổi; validate trước khi tạo trạng thái mới |
| KH07 | Thủ kho đề nghị giảm tồn kèm lý do | Số nguyên >0, không vượt tồn hiện tại, lý do 1–500 ký tự; gửi thành công vẫn chưa giảm tồn |
| KH08 | Quản lý duyệt/từ chối, chỉ xử lý một lần | Duyệt kiểm lại tồn, trừ một lần, lưu trước/sau/người/giờ; thiếu tồn từ chối thao tác, giữ chờ. Từ chối cần lý do, không đổi tồn; trạng thái đã xử lý không duyệt lại |
| KH09 | Lưu demo và tra tồn/lịch sử sau tải lại | Chỉ cập nhật UI thành công sau localStorage ghi được. Lỗi ghi giữ state cũ/nháp; dữ liệu không đọc được chặn ghi. Chưa đảm bảo nhiều tab cùng ghi |
| KH10 | Phản hồi thao tác tại mục liên quan | Tạo mã ngay dưới nút Tạo mã; sửa/xóa dưới Chỉnh sửa danh mục hàng; duyệt/từ chối dưới lịch sử giảm tồn. Xóa tồn 0 có xác nhận trong trang; Hủy không xóa |

## 3. Quy tắc bổ sung và giới hạn
- Không có nút gộp dòng; Quản lý chỉ thấy hai nút chính Lưu chỉnh sửa/Xóa hàng trong mục chỉnh sửa, không có Ngừng sử dụng/Dùng lại trên UI.
- Mock còn nhánh archive/restore để tương thích bản cũ, không phải chức năng người dùng hiện hành. Hàng từng inactive không nhận phiếu/đề nghị mới.
- Nhập hợp lệ Bút 10 +3 →13; Sổ 20 +10 →30. Dòng Bút trống cùng Sổ10 thì báo lỗi dòng Bút và giữ toàn bộ tồn; người dùng nhập hoặc bỏ dòng trống.
- Giảm tồn dùng cho mất/hỏng/chênh lệch kiểm kê, không thay cho xuất hàng bán. Tồn 10/20 là seed giả ban đầu, không phải kết quả import Excel thật.
- Phiếu nhập đã lưu không sửa/xóa trực tiếp. Người học chốt dùng đề nghị điều chỉnh có lý do, Quản lý duyệt, gắn phiếu gốc. Demo chưa có điều chỉnh tăng và liên kết phiếu gốc đầy đủ; giữ ở backlog.
- Role selector chỉ mô phỏng. Chưa có định danh thật để đảm bảo requester khác approver, DB transaction/concurrency production, backup/restore thật hoặc UAT thủ kho thật.

## 4. NFR và tiêu chí thật chưa kiểm chứng
Brief nêu khoảng 20 người dùng đồng thời, không âm/khớp lịch sử và audit sửa/xóa. Demo minh họa logic, chưa kiểm chứng NFR production. RPO/RTO, SLA/latency, retention log và tích hợp AD/LDAP cần nghiệp vụ/team chốt, không tự đặt số.
Chỉ dữ liệu giả trong bài học. Không tự đưa dữ liệu nhạy cảm/khóa vào prompt hoặc đóng gói. Gate thật trong DOD-PB03.md và Delegation Map.

## 5. Làm rõ/hard-stop và review người học
| Câu hỏi | Nhãn | Quyết định/trạng thái |
|---|---|---|
| Ai quản lý danh mục? | Hỏi stakeholder | Người học chọn Quản lý tạo/sửa/xóa |
| Ai giảm tồn/ai duyệt? | Hỏi stakeholder | Thủ kho đề nghị; Quản lý duyệt |
| Cho số lượng lẻ trong kho bút/sổ? | Hỏi stakeholder | Người học xác nhận chỉ số nguyên >0 |
| Tồn 0 có lịch sử được xóa? | Hỏi stakeholder | Có, giữ lịch sử; không tái dùng mã đã xóa |
| Phiếu đã lưu sai xử lý thế nào? | Hỏi stakeholder | Giữ phiếu gốc; điều chỉnh có duyệt, phần mở rộng chưa triển khai đầy đủ |
Hard-stop trước build: quyền danh mục/quy trình điều chỉnh chưa rõ, người học đã chốt để mở luồng demo. Hard-stop còn lại cho triển khai thật: chưa cấp quyền production/chưa có phê duyệt dữ liệu và evidence gates; không suy từ đồng ý demo là được release.
AI tự review: thông báo lỗi số lượng thiếu dòng gây hiểu nhầm; nhiều nút/feedback khó thấy được người học phát hiện, ghi UAT01–UAT09. Không biến đổi yêu cầu hoặc ví dụ nhập âm giả định thành hallucination thật.

## 6. Simulation barcode — phản hồi người học
> Em hiểu anh muốn giảm thao tác nhập hàng nhờ quét barcode, giúp tăng tốc độ xử lý và hạn chế sai sót. Tuy nhiên, việc thêm tính năng này lúc này đòi hỏi phải khảo sát phần cứng, thiết kế lại luồng và kiểm thử thêm, nên chúng ta chưa có cơ sở hứa trước mốc thời gian hoàn thành. Trước mắt, mình hãy tập trung hoàn thiện và chạy thử luồng lưu phiếu, xem tồn chuẩn xác theo MVP; sau khi hệ thống này vận hành ổn định, em sẽ lên lịch trình để chúng ta xem xét tích hợp barcode ngay ở đợt tiếp theo.
Ghi chú AI: khảo sát thiết bị/camera và điều chỉnh luồng nếu cần; không mặc định phải mua phần cứng hoặc thiết kế lại toàn bộ.

## 7. Truy vết và bằng chứng
RTM-DEMO-V10.md nối KH01–KH10 tới WBS/code/test. API-PB03.md là contract hiện hành; TEST-SCENARIOS-PB03.md là bộ scenario. Review/đổi rule do người học có trong DECISION-LOG (D01/D04/D05, UAT01–UAT09, EX03-D02). Tài liệu này chuẩn hóa lại các quyết định đã có, không tự thêm phê duyệt mới của người học.
