# DoR-PB03 — Điều kiện build và trạng thái demo

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Quyết định hiện hành
Người học đã chốt Tier2, luồng nhập→lưu→xem tồn/lịch sử, sau review mở rộng danh mục và duyệt giảm tồn; demo v10 được nghiệm thu. Kế hoạch build ban đầu đã thực hiện, không còn trạng thái chờ chốt build.
| Điều kiện demo | Trạng thái | Nguồn |
|---|---|---|
| Scope/role/AC rõ cho chức năng đã làm | Đủ để build demo | REQ KH01–KH10, quyết định người học |
| API/data contract | Có bản hiện hành | API-PB03.md, schema SQL chỉ tham khảo |
| Ranh giới | Đã chốt sandbox/dữ liệu giả | Không hệ thật, không auth production, không push/release |
| Gate logic/UI | Đã có kiểm thử | KET-QUA-KIEM-THU và scripts; đây là evidence lịch sử demo |
| UAT người học | Đã xác nhận demo v10 | Hội thoại/Decision Log |
| SoD/DB thật/concurrency/restore production | Chưa kiểm chứng, không trong DoR demo | DoD/Delegation Map cho kế hoạch triển khai thật |

## Thiết kế demo đã làm
HTML/JS tương tác, API mock trả status/body/next, lưu localStorage một snapshot trước đổi UI. Một mã một dòng, không nút gộp; thêm dòng chỉ chọn hàng chưa có. Nhập quantity nguyên >0, kiểm toàn phiếu, không âm/overflow. Quản lý tạo/sửa/xóa tồn0 có giữ lịch sử; Thủ kho gửi giảm tồn, Quản lý duyệt/từ chối. Feedback tạo/sửa/xóa/review tại đúng mục.
API mock/role selector minh họa, không REST server, DB transaction hoặc định danh user thật. Chưa có export Excel, xuất kho, cảnh báo tối thiểu, điều chỉnh tăng/liên kết phiếu đầy đủ.

## Build checklist đã thực hiện và điều kiện tiếp theo
Thiết kế/REQ → UI/model/mock → logic script → browser test → người học thử/review → sửa theo phản hồi → nghiệm thu demo. Decision Log ghi thay đổi thật, không tạo lỗi giả. 90 phút là tổng người học đã cung cấp, không tự cập nhật tăng theo số bản.
Nếu đổi chức năng tiếp, bổ sung AC/API/test/evidence trước chốt lại DoR cho phần mới; không coi đồng ý demo là approval production. DoD thật cần review/staging/auth/DB/UAT/restore và chủ hệ thống phê duyệt.
