# Definition of Done PB03 — kiểm soát người học yêu cầu

Nguồn: câu trả lời người học trong EX-04. DoD dưới đây áp cho MVP thực dự kiến; không coi là các kiểm soát đều đã chạy trên demo.
DoR = đủ điều kiện bắt đầu làm. DoD = đủ bằng chứng để nghiệm thu/bàn giao. Phần còn chưa kiểm chứng không tự gán PASS.

| Cổng | Điều kiện hoàn thành | Bằng chứng cần có | Người chịu trách nhiệm dự kiến | Trạng thái hiện tại |
|---|---|---|---|---|
| Requirement | AC hiện hành và scope rõ, trace được đến test | REQ/RTM/test IDs | PM + dev | Demo có yêu cầu qua nhiều lần review; cần bản chốt/RTM sạch |
| Code review | Dev đọc code tồn không âm, quyền, transaction và xử lý lỗi | Diff và biên bản review, finding đã xử lý | Dev reviewer | Chưa có dev thật review độc lập |
| Unit/integration | Test chạy thật theo AC, valid/invalid/boundary | Lệnh, exit code, báo cáo pass/fail/skip | Dev phụ trách | Model demo 27 test pass; chưa có integration DB thật |
| Concurrency | Hai giao dịch/duyệt lặp không làm âm hoặc trừ lặp | Kết quả test trên DB/backend thật | Dev backend + reviewer | Có test model duyệt lặp/kiểm tồn; chưa test đồng thời production |
| Authorization | Endpoint kiểm quyền thực, 401/403 đúng | Negative test backend thật | Dev backend + reviewer | Mock role đã test; chưa có auth thật |
| Review chéo | Hai dev review code và test case của nhau | Người review/finding/kết quả | Hai dev giả định | Chưa thực hiện với team thật |
| UAT người dùng | Thủ kho thực tế thử luồng, phản hồi được xử lý | Kịch bản, kết quả, danh sách lỗi và xác nhận | Thủ kho + PM | Người học nghiệm thu demo; UAT thủ kho thật chưa diễn ra |
| Evidence | Báo cáo/log đúng target/phiên bản, hoặc CI tương ứng nếu có | File log/report và commit/version, không chỉ lời AI | Người nghiệm thu | Có script/báo cáo demo; chưa có CI production |
| Telemetry/docs | Hướng dẫn đúng chức năng, log quyết định và số liệu có nguồn | Hồ sơ chốt, hướng dẫn, telemetry | PM/người học | Có 90 phút và review; còn chuẩn hóa hồ sơ |

## Quy tắc fail-closed
- Bất kỳ cổng bắt buộc FAIL/CHƯA CHẠY/CHƯA XÁC MINH: chưa được nghiệm thu phần tương ứng.
- Sửa nguyên nhân, chạy lại ca bị ảnh hưởng, lưu bằng chứng mới, người có thẩm quyền kiểm lại.
- AI có thể hỗ trợ code/test/tổng hợp; không tự ký thay dev reviewer, thủ kho hoặc chủ hệ thống.
- Lưu bạch skipped/expected-fail/unrun; không coi không chạy hoặc zero-test là pass.
- CI/CD là một loại bằng chứng khi có, không bắt buộc dựng pipeline chỉ để thay báo cáo test chạy thật.

Bổ sung từ review Top-5: bản thật cần RBAC tại API, idempotency duyệt, transaction/locking và backup/restore có RPO/RTO được nghiệp vụ chốt. Chưa có giá trị RPO/RTO và chưa diễn tập thật, không đánh dấu PASS.

## Kiểm soát EX-06 được người học bổ sung
Duyệt tồn: Quản lý xác minh chứng từ, requester không được tự duyệt, RBAC/SoD/audit. Bản thật cần định danh người dùng riêng; role selector của demo không chứng minh đã thực thi SoD.
Migration: DBA/người được ủy quyền review/phê duyệt, staging pass, backup và chứng minh restore; AI chỉ nháp script/test/rollback, không tự chạy production.
Release: Release Owner xem DoD, kiểm thử quan trọng, rủi ro và rollback plan, phê duyệt đúng version/môi trường; người được phép phát hành. Least privilege/HITL/evidence là điều kiện xuyên suốt, không tự cấp thêm quyền AI.
Chưa thực hiện các approval/staging/restore thật, không gán PASS.
