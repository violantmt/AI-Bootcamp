# EX-05 — Dữ liệu tuần giả lập, nguồn duy nhất của báo cáo
Nguồn: Workbook.md, EX-05, mục Input. Đây là bài tập giả lập tuần 3/8, không phải tiến độ thực của demo hoặc số đo người học.

- Tuần 3/8.
- Kế hoạch: hoàn thành module #1 và module #2.
- Thực tế: module #1 done; module #2 trễ 1 ngày do logic nghiệp vụ phức tạp hơn dự kiến. Chưa nói module #2 đã xong hoặc ngày hoàn thành mới.
- 3 bug mở: 2 UI, 1 logic.
- AI hỗ trợ sinh CRUD, tiết kiệm khoảng 1,5 MD (ước tính trong đề, chưa xác minh bằng time log).
- Token tuần khoảng 120k (ước tính trong đề).
- 1 rủi ro mới: tích hợp bên thứ ba thiếu tài liệu API tốt. Đây là input bài giả lập, chưa xác định nhà cung cấp/tích hợp cụ thể của PB03; không tự đưa vào scope MVP.

Không có: effort từng module, tổng task, task dùng AI, giờ review, artefact rework, đơn giá/model token, actual/estimate effort, baseline giờ truyền thống, doanh thu hoặc người dùng.
Không nhập 90 phút học hoặc capacity 64 dev-MD vào báo cáo tuần như actual của dự án.
