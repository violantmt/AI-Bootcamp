# EX-03 — Trade-off đang mở

## Quyết định đã có
Người học giữ không âm và duyệt điều chỉnh, hoãn Excel; dùng MoSCoW để bảo vệ nghiệp vụ/chất lượng thay vì cắt kiểm soát.

| Nội dung | Trước | Sau |
|---|---|---|
| REQ: xuất Excel | In-scope MVP theo brief | Phase sau; báo cáo trong ứng dụng vẫn giữ |
| WBS 2.6 | Báo cáo và Excel gộp | 2.6a báo cáo giữ; 2.6b Excel hoãn |
| M + buffer dev | 58.65 MD | 55.20 MD |
| Mốc/capacity | 6 tuần/48 dev-MD | Chưa đổi; còn vượt 7.20 MD |

Diff nội dung: REQ bổ sung mục EX-03 và thay scope Excel trong kế hoạch; WBS tách 2.6 thành 2.6a/2.6b và cập nhật dependency. Bản trước được giữ trong history/*-truoc-hoan-excel.md. Chưa chuẩn hóa REQ lịch sử thành một bản chốt sạch.

Giải trình stakeholder — bản AI đề xuất: Hoãn Excel để ưu tiên độ chính xác tồn và kiểm soát điều chỉnh. Báo cáo vẫn xem trong hệ thống. Ước lượng hiện tại cho thấy riêng việc hoãn Excel chưa đủ đáp ứng 6 tuần; cần thống nhất thêm phạm vi hoặc mốc trước cam kết, không giảm kiểm thử/phân quyền để ép tiến độ.

Quyết định tiếp theo: CHỜ người học chọn phương án khép gap. Chưa tuyên bố EX-03 hoàn thành hoặc thời hạn khả thi.

## Quyết định người học — phương án 8 tuần
Người học chọn đề xuất 8 tuần để giữ kiểm soát tồn không âm, phân quyền, duyệt điều chỉnh và kiểm thử; Excel vẫn hoãn sang phase sau.
Capacity dev theo giả định: 2 × 8 × 5 × 80% = 64 dev-MD; nhu cầu M + 15% dự phòng = 55,2 dev-MD; chênh 8,8 dev-MD (không cộng thêm một lần buffer 15%). PM: 8 × 5 × 80% = 32 PM-MD; effort PM khả dĩ 12,75, hoặc 14,6625 nếu áp 15% dự phòng tương tự.
Đây là phương án lập kế hoạch trong bài tập, chưa phải stakeholder đã duyệt đổi deadline. Người học yêu cầu xác nhận effort với team, dependency và critical path trước khi cam kết. Chưa có lịch nghỉ, task assignment và duration thực tế nên không khẳng định đường găng hoặc ngày bàn giao cụ thể.
Nếu overhead dev tăng 30% thì capacity 56 dev-MD, chỉ hơn nhu cầu 0,8. Nếu effort M tăng 20%, nhu cầu sau buffer thành 66,24 dev-MD, vượt capacity 64 là 2,24. Phải tái ước lượng/thương lượng nếu giả định không còn đúng.
