# Rà EX-01 — câu hỏi làm rõ và trạng thái

Phân loại dưới đây do AI tổng hợp từ hội thoại, cần người học review, không giả định người học đã tự gắn nhãn.

| Câu hỏi | Nhãn đề xuất | Kết quả thực tế |
|---|---|---|
| Ai tạo/sửa/xóa danh mục? | Hỏi stakeholder | Đã chốt Quản lý; Thủ kho chỉ chọn hàng nhập |
| Ai được giảm tồn và ai duyệt? | Hỏi stakeholder | Thủ kho đề nghị, Quản lý duyệt; chưa duyệt không đổi tồn |
| Cho phép số lượng lẻ không? | Hỏi stakeholder | Case bút/sổ chỉ số nguyên >0; người học xác nhận |
| Tồn 0 nhưng có lịch sử có được xóa mã hàng? | Hỏi stakeholder | Người học chốt được xóa khỏi danh mục, giữ lịch sử |
| Phiếu nhập đã lưu sai thì sửa/xóa trực tiếp hay dùng phiếu điều chỉnh có duyệt? | Hỏi stakeholder | Đã chốt: giữ phiếu gốc, đề nghị điều chỉnh có lý do, Quản lý duyệt; chưa triển khai đầy đủ liên kết phiếu/điều chỉnh tăng |

## Hard-stop có dấu vết
Trước build, quyền danh mục và ai duyệt giảm tồn chưa rõ: không tự chốt vào hệ thật. Người học đã quyết định và mở chốt cho demo. Hard-stop về xử lý phiếu sai đã được người học gỡ: dùng điều chỉnh có duyệt, không sửa/xóa trực tiếp. Chưa tự triển khai phần mở rộng này.

## Phản biện AI thực tế
Thông báo số lượng không chỉ dòng làm người học hiểu nhầm Sổ nhập 10 sai; thông báo xóa khó nhận biết và phần quản lý danh mục quá nhiều nút là các phản biện thật đã lưu ở Decision Log. Không gán một câu hỏi stakeholder thành [AI tự sai] chỉ để đủ nhãn.

## Scope simulation
Phản hồi barcode do người học viết đã lưu trong REQ và Decision Log: ghi nhận lợi ích, chưa cam kết thời gian khi chưa khảo sát, ưu tiên MVP rồi đánh giá barcode đợt sau.

## Quyết định chốt — xử lý phiếu nhập đã lưu sai
Người học đồng ý: giữ nguyên phiếu gốc, không sửa/xóa trực tiếp phiếu đã lưu. Thủ kho gửi đề nghị điều chỉnh có lý do, Quản lý duyệt trước khi tồn thay đổi; lưu tham chiếu phiếu gốc, người yêu cầu/duyệt và thời điểm.
Quy tắc này đã chốt ở mức yêu cầu. Demo hiện chỉ có giảm tồn theo đề nghị và chưa có liên kết điều chỉnh về phiếu gốc; điều chỉnh tăng tồn do nhập thiếu cũng chưa có. Không tuyên bố toàn bộ quy trình này đã được triển khai/kiểm thử. Chưa cần thêm vào demo đang nghiệm thu.
