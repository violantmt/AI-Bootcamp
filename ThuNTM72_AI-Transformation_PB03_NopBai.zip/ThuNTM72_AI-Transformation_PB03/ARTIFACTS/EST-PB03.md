# EST-PB03 — Ước lượng 3-point và capacity

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Giả định và phạm vi
Ước lượng phần còn lại để chuyển Tier2 thành MVP thật theo brief: React/Vue + Spring Boot/.NET + PostgreSQL/MySQL; demo/mock không thay backend thật. Hai dev quen stack, 1 PM, không QA riêng; một môi trường nội bộ, không LDAP/AD, import tự động chưa chốt. MD = ngày công một người; O/M/P thuận lợi/thông thường/khó khăn, là estimate AI chưa được team xác minh, không actual. 90 phút học không dùng làm effort production.

| ID | Trace WBS | Việc | O dev-MD | M dev-MD | P dev-MD | PM-MD (M) | Giả định |
|---|---|---|---:|---:|---:|---:|---|
| E01 | 2.1 | Backend/DB và mô hình dữ liệu | 3 | 5 | 8 | 1 | Stack theo brief; dựng DB thật, mock không tái dùng nguyên trạng |
| E02 | 2.1 | Xác thực, phân quyền và audit | 3 | 5 | 9 | 1 | Hai role, tài khoản nội bộ; chưa tích hợp LDAP/AD |
| E03 | 1.3→2.1 | Danh mục trên backend thật | 2 | 3 | 5 | 0.5 | Giữ lịch sử/xóa nghiệp vụ, kiểm quyền server |
| E04 | 1.4→2.1 | Nhập kho trên DB thật | 2 | 4 | 6 | 0.5 | Phiếu nhiều dòng nguyên tử; không sửa phiếu đã lưu |
| E05 | 2.3 | Xuất kho và chống tranh chấp | 3 | 5 | 8 | 0.5 | Transaction/khoá để không xuất âm |
| E06 | 2.4 | Điều chỉnh tăng/giảm và duyệt | 3 | 5 | 9 | 1 | Liên kết phiếu gốc, duyệt một lần, audit |
| E07 | 2.5 | Tồn, lịch sử và cảnh báo tối thiểu | 2 | 3 | 5 | 0.5 | Danh sách có lọc cơ bản, không dashboard nâng cao |
| E08 | 2.6a | Báo cáo nhập–xuất–tồn theo kỳ | 2 | 4 | 7 | 0.5 | Đối soát số dư/biến động, quyền xem |
| E09 | 2.6b | Xuất Excel | 1 | 3 | 5 | 0.25 | Dùng thư viện chuẩn, bộ lọc và kiểm quyền giống báo cáo |
| E10 | 2.7 | Kiểm thử tích hợp, bảo mật và 20 user | 3 | 5 | 9 | 1 | Không có QA riêng; dev tự chạy và review chéo |
| E11 | 2.8 | Triển khai, backup và thử phục hồi | 2 | 3 | 6 | 1 | Một môi trường nội bộ, cần quyền hạ tầng |
| E12 | 2.9 | Hướng dẫn người dùng | 0.5 | 1 | 2 | 2 | Dev cung cấp minh họa; PM soạn/điều phối |
| E13 | 2.10 | UAT thủ kho thực tế | 1 | 2 | 4 | 2 | Người dùng có lịch tham gia; effort dev không thay thời gian chờ |
| E14 | 2.11 | Sửa theo UAT và kiểm lại | 2 | 3 | 6 | 1 | Chỉ sửa lỗi thuộc scope; không thêm tính năng mới |

## Quyết định hiện hành và so sánh
Người học chọn hoãn Excel (E09) và đề xuất 8 tuần, có điều kiện xác nhận effort/team/dependency/critical path trước cam kết stakeholder. Chưa stakeholder baseline duyệt.
| Kịch bản | M dev-MD | Buffer rủi ro 15% | Tổng dev-MD | Capacity sau overhead 20% | Chênh capacity − nhu cầu |
|---|---:|---:|---:|---:|---:|
| Brief 6 tuần, có Excel | 51 | 7,65 | 58,65 | 48 | −10,65 |
| 6 tuần, hoãn Excel | 48 | 7,2 | 55,2 | 48 | −7,2 |
| Đề xuất 8 tuần, hoãn Excel | 48 | 7,2 | 55,2 | 64 | +8,8 |
Dev capacity 8 tuần =2×8×5×0,8=64. PM capacity =1×8×5×0,8=32 PM-MD; PM M đầy đủ 12,75, loại E09 còn 12,5, cộng 15% là 14,375 PM-MD. PM không cộng vào capacity code. Bản trước áp PM đầy đủ kể cả E09 đã lưu trong history; đây là hiệu chỉnh số học, không actual mới.
20% overhead cho họp/gián đoạn không bao gồm effort test đã có ở E10/E13/E14. Buffer 15% cho bất định ngoài giả định, cần tránh tính lại rủi ro đã bao trong E14. Không cộng tiếp 8,8 dư địa như buffer một lần nữa.

## Sensitivity và rủi ro
Overhead 30% → dev capacity56, chỉ dư0,8; M tăng20% → 48×1,2×1,15=66,24, vượt64 là2,24. Top bất định: quyền/auth, điều chỉnh tăng/giảm gắn phiếu gốc, test không QA riêng. Chưa chốt lịch nghỉ/thời gian chờ UAT/hạ tầng nên tổng MD đủ chưa chứng minh đường găng hoặc ngày bàn giao.
Trace: WBS/REQ/TRADEOFF hiện hành và review EX03-D01/D02. Team review lại trước cam kết; không giảm test/permission/không âm để ép mốc.
