# API-PB03 — Contract mock hiện hành

Bản hiện hành KH-Refresh-2 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Cách gọi và ranh giới
`api(state, role, method, path, payload={}, now=...)` trong ../CODEBASE/prototype/model.mjs trả `{status, body, next?}`. Không có REST server thật; status mô phỏng HTTP. Role chỉ keeper/manager, không hợp lệ trả401. API không đổi state gốc: next chỉ được UI áp dụng sau localStorage ghi thành công. GET trả bản sao. Endpoint lạ trả404.

| Method / path | Role được dùng | Input chính | Thành công | Lỗi chính |
|---|---|---|---|---|
| GET /api/products | keeper/manager | — | 200 danh sách {id,name,unit,stock,active?} | 401 |
| GET /api/receipts | keeper/manager | — | 200 phiếu {id,at,actor,lines} | 401 |
| POST /api/products | manager | {id,name,unit} | 201 product tồn0 + next | 400 invalid,403 sai role,409 mã trùng/đã xóa |
| POST /api/products/manage | manager | {action,originalId,id?,name?,unit?} | 200 {message}+next | 400 invalid,403 role,404 mã không tồn tại,409 ràng buộc |
| POST /api/receipts | keeper | {lines:[{productId,quantity}]} | 201 phiếu+next | 400 dữ liệu/overflow,403 role,409 dòng trùng |
| POST /api/adjustments | keeper | {productId,quantity,reason} | 201 request pending+next, tồn chưa đổi | 400 dữ liệu/lý do,403 role,409 vượt tồn |
| POST /api/adjustments/review | manager | {id,action:approve/reject,note?} | 200 request cập nhật+next | 400 action/lý do,403 role,404 request,409 đã xử lý/không đủ tồn |

## Danh mục
Mã trim/uppercase, 1–30 ký tự A-Z/0-9/_/-, tên trim1–100, unit trim1–30. Không tạo lại mã hiện có hoặc lưu trong deletedProducts.
manage edit: originalId tìm hàng; sửa tên; đổi mã/unit chỉ khi tồn0 và chưa có phiếu/đề nghị/liên quan theo model; chặn mã trùng/đã xóa.
manage delete: tồn khác0 trả409 với số tồn; tồn0 được xóa khỏi products, giữ snapshot trong deletedProducts cùng người/giờ, giữ phiếu/đề nghị/audit. Đề nghị pending của mã đó được đóng rejected với lý do. Không yêu cầu “chưa có lịch sử”.
Nhánh archive/restore còn trong model để tương thích lịch sử; UI v10 không có các nút đó. Hàng inactive không được nhập/gửi đề nghị mới; archive pending bị chặn. Không có mergeLines trong bản hiện hành.

## Phiếu nhập
Toàn phiếu cần ít nhất một dòng, hàng tồn tại/active, quantity là safe integer >0. Kiểm tất cả dòng và trùng trước tạo next; cộng tồn vượt giới hạn số nguyên an toàn bị chặn. Bất kỳ lỗi giữ state gốc, không lưu một phần. Phiếu ID PN-n, actor demo, timestamp và lines.
UI dùng select không cho chọn trùng và không có gộp. API vẫn chặn trùng để không chỉ tin UI.

## Đề nghị giảm và duyệt
Quantity nguyên >0, không vượt tồn hiện tại; reason trim1–500 ký tự. Request DC-n có productId/quantity/reason/status pending/requestedBy/requestedAt, chưa trừ tồn.
Review chỉ pending: approve kiểm hàng active/đủ tồn tại lúc duyệt, trừ một lần và ghi beforeStock/afterStock; reject cần note không trống, tối đa500, không đổi tồn. Cả hai ghi status/reviewedBy/reviewedAt/reviewNote. Đề nghị đã xử lý trả409, không xử lý lại.

## Phản hồi/lưu trữ và hạn chế
Tạo mã: createMessage dưới nút Tạo. Sửa/xóa: catalogMessage trong mục chỉnh sửa. Review: reviewMessage dưới lịch sử. Thành công sau khi ghi snapshot localStorage; lỗi ghi không báo thành công.
Không có endpoint sửa/xóa phiếu đã lưu, xuất kho, tăng điều chỉnh gắn phiếu gốc hoặc auth thật. Person demo chỉ chuỗi theo role; không bảo đảm requester khác approver. Không có DB transaction/locking/đồng thời thật; schema.sql chỉ bản tham khảo.

## Invariants và mức kiểm chứng sau review PM/BA
| Điều kiện cần bảo đảm | Demo hiện có và bằng chứng | Giới hạn/chưa được kiểm chứng |
|---|---|---|
| Gửi đề nghị không giảm tồn, chờ duyệt | model tạo pending, không đổi product.stock; test tuần tự có sẵn | Không đại diện luồng nhiều người/server |
| Một request không trừ tồn lần hai | model kiểm status=pending trước review; test tuần tự xử lý lại trả409 | Không có idempotency key/replay cache hoặc test double-click/retry UI riêng; không chứng minh idempotency production |
| Tồn không âm | validate số dương, review kiểm lại stock; model test hai đề nghị tuần tự | Không có DB locking/transaction, kiểm tra đồng thời hoặc multi-tab được chứng minh |
| Có lịch sử thao tác | Request có lý do/người demo/giờ gửi; review có người demo/giờ/status/note, approve lưu stock trước/sau; snapshot lưu cùng dữ liệu | Actor là chuỗi theo role, không danh tính tin cậy, không append-only/tamper-proof audit hoặc audit mọi lỗi API |
| Quyền đúng | model từ chối role không hợp lệ/sai role, UI ẩn nút | Đổi role UI không là xác thực; chưa có RBAC server hoặc kiểm requester khác approver theo identity thật |
| Lưu thành công mới xác nhận | UI ghi next vào localStorage trước đổi state, catch lỗi và không báo success | Fault injection/quota chưa được chạy; không có transaction phân tán/đa tab hoặc chống lost update |

## Contract mục tiêu cho bản thật — chưa triển khai
- Auth/identity đáng tin, RBAC tại API và SoD: requester không tự duyệt. Lưu danh tính/timestamp/version, không tin role do client gửi.
- Duyệt: kiểm pending và đủ tồn trong cùng DB transaction với locking/conditional update phù hợp; cập nhật tồn, trạng thái và audit cùng transaction. Hai yêu cầu cạnh tranh không được cùng vượt số tồn.
- Duplicate approval/double-click/retry: cùng business request/idempotency key không được sinh hai biến động tồn. Chốt semantics replay/error với team; không gọi hành vi trả409 tuần tự của mock là đã triển khai đầy đủ idempotency.
- Khi commit/lưu thất bại: không xác nhận thành công, không để tồn và trạng thái request lệch nhau; retry an toàn và có evidence. Reload đọc cùng trạng thái durable đã commit.
- Audit thao tác có request ID, chứng từ/lý do, actor thật, status trước/sau và stock trước/sau. Quy định retention/kiểm quyền sửa log với chủ hệ thống trước triển khai.
Các điều kiện trên là yêu cầu thiết kế và test backlog, không phải production đã có.

## Review hiện hành
PMBA-REVIEW-01: người học review bản tóm tắt dưới góc nhìn PM/BA, đồng ý workflow nhưng yêu cầu bảo vệ xử lý trùng/không âm/lịch sử và không nhầm role mock với RBAC/SoD thật. Trạng thái **Changes Requested**, chưa Approved.
KH-Refresh-2 đã làm rõ contract, evidence và limitation theo review; không sửa code demo hoặc tự ghi các test mới PASS. Review lại bản cập nhật và test thực thi liên quan còn chờ. Nguồn: knowledge-health/HUMAN-REVIEW-RECORD.json, REVIEW-PACKET-PB03.md.
