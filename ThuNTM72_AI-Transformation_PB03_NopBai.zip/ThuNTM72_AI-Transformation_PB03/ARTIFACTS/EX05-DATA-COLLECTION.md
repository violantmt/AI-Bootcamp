# EX-05 — Kế hoạch thu thập dữ liệu và kiểm chứng

## Bổ sung EX-05 do người học yêu cầu

### Token Cost — nguồn và cách thu thập
Kiểm tra usage log hoặc billing của công cụ AI cho đúng phiên/kỳ. Lưu nguồn, khoảng thời gian, tool/model, đơn vị tiền và cách tính; phân biệt chi phí API theo token với phí thuê bao/credit. Nếu có tổng chi phí thực được xác nhận cho đúng phiên thì có thể báo trực tiếp, không nhất thiết suy ngược từ token.
Nếu phải tính từ usage: cần token theo model và loại input/output/cache, đơn giá áp dụng tại thời điểm sử dụng; chi phí = tổng token từng loại/model × đơn giá tương ứng. Không lấy giá model bất kỳ hoặc chia phí thuê bao cho task khi chưa có quy tắc phân bổ được thống nhất.
Phiên hiện tại chưa có usage/billing thực được cung cấp hoặc truy xuất: ghi “Chưa có dữ liệu chi phí phiên”, không tự điền 0. Khoảng 120k trong INPUT-W3 là ước tính giả lập, không phải billing phiên thực hành.
Cho phiên tiếp theo: ghi session ID/kỳ và task ID ngay khi bắt đầu; lưu/export usage report hoặc ảnh/bản ghi billing không chứa secret; ghi model/token/giá hoặc tổng phí; đối soát cuối kỳ và ghi rõ phần chưa phân bổ. Bản ghi phải chỉ ra chi phí bao gồm/chưa bao gồm phí công cụ/thuê bao/thuế nếu có thông tin, không tự đoán.

### AI Adoption — lập inventory rồi đối chiếu bằng chứng
Tổng hợp task từ REQ, WBS, EST, RISK và WEEKLY; lập ID chuẩn và nối các nguồn để tránh một task xuất hiện ở nhiều tài liệu bị đếm nhiều lần. Yêu cầu/rủi ro không tự động là task; map chúng tới công việc cụ thể. Giữ cả task Non-AI/Unknown, không chọn riêng việc có AI.
Chốt kỳ và đơn vị task trước khi tính; tách task thực sự làm trong kỳ khỏi task kế hoạch chưa bắt đầu. Không trộn tuần W3 giả lập, kế hoạch MVP 8 tuần và phiên học 90 phút thành cùng một mẫu số.
Đối chiếu lịch sử tương tác, file thay đổi/artefact, diff/commit nếu có và bằng chứng skill/rule thực sự dùng. Không có commit không có nghĩa không dùng AI; có rule được cài cũng không chứng minh AI được dùng.
Phân loại:
- AI-assisted: có bằng chứng AI thực sự hỗ trợ task.
- Non-AI: có căn cứ task được thực hiện không dùng AI; không suy từ việc thiếu log.
- Unknown: chưa xác minh được; không tự chuyển thành Non-AI.
Ghi thêm trạng thái Planned/In progress/Done và lý do đưa vào kỳ. Với inventory đầy đủ và không còn Unknown trong tập task đủ điều kiện: Adoption = AI-assisted / (AI-assisted + Non-AI) ×100%. Mẫu số bằng 0 thì N/A.
Nếu còn Unknown: chưa báo một tỷ lệ Adoption chính xác; công khai A/N/U, việc kiểm chứng còn thiếu. Có thể báo tỷ lệ xác minh = (A+N)/(A+N+U), hoặc khoảng Adoption [A/T,(A+U)/T] khi inventory T đầy đủ, ghi rõ đây là khoảng chứ không phải số chốt. Inventory chưa đầy đủ thì không suy khoảng bao phủ toàn bộ kỳ.
