# TEST-SCENARIOS-PB03 — Bộ kiểm demo hiện hành

Bản hiện hành KH-Refresh-2 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Phạm vi và evidence
Script logic ../CODEBASE/prototype/test.mjs có 27 tests theo báo cáo đã lưu; browser ../CODEBASE/prototype/test_browser.py kiểm UI/role/lưu tải lại. Đây là script/nguồn tồn tại, không tự tuyên bố vừa chạy lại ở lần sửa tài liệu. Không thay UAT thủ kho thật hoặc test production. Kết quả lịch sử trong KET-QUA-KIEM-THU.md.

| Scenario | Given / When / Then | Nguồn kiểm hiện có |
|---|---|---|
| TS01 nhập đúng | Bút10, thủ kho nhập3/lưu →13 và có phiếu/lịch sử | test.mjs AC08; browser |
| TS02 nhập sai | Số -3/0/1.5/NaN/overflow → từ chối, không đổi tồn | test.mjs quantity/overflow; browser âm |
| TS03 lỗi chỉ dòng | Bút trống, Sổ10 → lỗi dòng Bút, giữ tồn; bỏ dòng Bút rồi lưu → Sổ20→30 | model test và browser |
| TS04 không trùng | Đã chọn Bút, thêm dòng chọn Sổ, khóa Bút ở dòng2; hết hàng chặn thêm; xóa dòng trả lựa chọn | browser option disabled/add |
| TS05 atomic phiếu | Một dòng đúng và một dòng sai → không lưu phiếu, mọi tồn không đổi | test.mjs Phiếu nhiều dòng lỗi |
| TS06 quyền nhập | Role rỗng401, manager403, keeper hợp lệ; UI ẩn lập phiếu cho manager | model + browser |
| TS07 quyền danh mục | Chỉ manager tạo; mã trùng/thiếu field bị chặn; tồn hàng mới0 | model + browser |
| TS08 sửa/xóa | Hàng có tồn không đổi mã/unit; tên sửa được; tồn>0 không xóa và báo số tồn; tồn0 xóa thành công dù có lịch sử, giữ phiếu/đề nghị sau reload | model + browser |
| TS09 xác nhận xóa | Tồn0 mở xác nhận trong trang; Hủy giữ mã, Xác nhận xóa thành công; đổi role/hàng đóng xác nhận | browser có hủy/confirm; đổi role được code xử lý, chưa có test riêng đầy đủ mọi biến thể |
| TS10 đề nghị | Keeper gửi quantity>0 và reason; thiếu lý do/số sai/vượt tồn/sai role bị chặn; gửi hợp lệ không đổi tồn | model + browser |
| TS11 review | Manager duyệt một lần; kiểm lại tồn, không âm; reject cần lý do và giữ tồn; keeper không duyệt | model + browser |
| TS12 vị trí feedback | Tạo dưới nút Tạo; sửa/xóa dưới mục chỉnh sửa; review dưới lịch sử; lỗi/thành công đúng kết quả | browser create/catalog/reviewMessage |
| TS13 local persistence | Lưu/tải lại giữ danh mục/tồn/phiếu/lịch sử; không lộ tham chiếu GET; test profile không chạm dữ liệu học viên | model JSON roundtrip + browser reload |
| TS14 giới hạn | Lỗi/quota localStorage, identity SoD thật, DB concurrency, backup/restore production → chưa kiểm đủ, không ghi PASS | Code có nhánh lỗi ghi; cần kiểm riêng/hệ thật |

## Cổng nghiệm thu
Đối chiếu AC trong REQ/RTM. Ghi PASS/FAIL/SKIP/CHƯA CHẠY và version/command/count thật, không hạ test để xanh. Sửa lỗi → retest liên quan. Scenario đủ nguồn không đồng nghĩa mọi trường hợp edge/production đã được kiểm.
Review người học cho bản tóm tắt scenario đã nhận: PMBA-REVIEW-01, Changes Requested. Không đồng nghĩa phê duyệt artefact hoặc các ca kiểm mới. Xem REVIEW-PACKET-PB03.md. Câu giả định để luyện và hallucination thật là loại bằng chứng khác, không đưa vào số test thực chạy.

## Scenario bổ sung theo PMBA-REVIEW-01
Các test dưới đây là **test specification/backlog**, chưa thêm script hoặc chạy mới trong lần cập nhật tài liệu này. “Existing partial evidence” chỉ trỏ kết quả lịch sử đã có, không dùng thay cho Not Tested của ca mở rộng.

| ID | Scenario / Given–When–Then | Cấp kiểm cần có | Existing partial evidence | Trạng thái ca mở rộng |
|---|---|---|---|---|
| TS15 | Concurrent stock deduction: tồn10, hai giao dịch độc lập cùng muốn trừ8, đồng bộ chạy cạnh tranh → chỉ một commit, giao dịch còn lại conflict/thiếu tồn, tồn cuối2 và chỉ một biến động đã duyệt | Integration DB thật có transaction/locking, nhiều client | Test model tuần tự hai đề nghị không gây âm không phải concurrency test | **Not Tested** — browser mock không có DB/server concurrency |
| TS16 | Duplicate approval / double-click: cùng pending request giảm3/tồn10, gửi hai lần review (kể cả double-click) → chỉ một biến động -3, tồn7, status/audit không lặp; phản hồi theo contract | Model tuần tự + UI rapid-click + API/DB concurrent | test.mjs “Đề nghị không đổi tồn; chỉ quản lý duyệt, trừ đúng một lần” có lần gọi tuần tự thứ hai409 | **Not Tested** cho double-click và đồng thời thật; tuần tự chỉ có evidence cũ |
| TS17 | Retry/replay: kết quả đã commit nhưng client mất phản hồi, retry cùng request/key → không trừ thêm, trả kết quả/duplicate theo contract; nếu lần đầu chưa lưu thì retry chỉ được lưu một lần | Fault injection client/API + idempotency persistence | Mock trên state đã cập nhật kiểm trạng thái; không có key/replay cache hoặc mất phản hồi mạng thật | **Not Tested** — cần chốt semantics và môi trường thực thi |
| TS18 | Hai đề nghị cùng mặt hàng: tồn10, R1=8/R2=8 → duyệt R1 xong R2 bị chặn, tồn2, R2 vẫn pending; nhánh hai R có tổng đủ tồn thì cả hai giảm đúng không lặp | Model + integration/concurrent DB | test.mjs “Duyệt kiểm lại tồn, hai yêu cầu không gây âm” có nhánh tuần tự không đủ; chưa có nhánh tổng đủ/concurrent riêng | **Not Tested** cho các nhánh mở rộng; không đánh dấu toàn scenario PASS |
| TS19 | Persistence/consistency: sau approve/reject, reload → stock, request status, history và before/after khớp snapshot cuối lưu thành công; không xuất hiện trạng thái approved mà stock cũ hoặc ngược lại | Browser + durable DB integration khi có backend | test_browser.py có reload/history/stock; model có JSON roundtrip, nhưng chưa assert đầy đủ bộ tuple tất cả approve/reject cases | **Not Tested** cho consistency matrix đầy đủ; reload cơ bản có evidence lịch sử |
| TS20 | Storage failure: inject setItem throw/quota sau thao tác nhập/duyệt/từ chối/xóa → báo lỗi tại mục, không báo success; stock/request/history trong UI và persisted snapshot vẫn theo lần lưu thành công cuối; retry khi khôi phục chỉ áp dụng một lần | Browser fault injection, profile test biệt lập | Code có try/catch nhưng chưa có report fault injection | **Not Tested** — không suy từ sự có mặt của catch thành PASS |
| TS21 | Dữ liệu lỗi khi đọc: localStorage hỏng/JSON invalid → báo không đọc được, chặn ghi, không âm thầm ghi đè dữ liệu cũ; đường phục hồi phải được xác nhận | Browser fault injection và recovery procedure | Code có nhánh blocked; chưa có test/report khôi phục đầy đủ | **Not Tested** |

## Evidence và điều kiện đóng finding
Mỗi lần chạy cần environment/version/script, fixture ban đầu, thao tác chính xác, expected/actual, ảnh/log/status PASS/FAIL/SKIP/Not Tested và người review. Test mock chỉ chứng minh phạm vi mock, không nâng lên RBAC/SoD/DB transaction production.
Với TS15/16/17/18 concurrency cần xác định điểm đồng bộ giao dịch và kiểm audit/tồn/request sau commit, không dùng hai lời gọi tuần tự để giả lập bằng chứng concurrent.
TS19/20 cần lưu/assert snapshot trước lỗi, trạng thái UI, persisted state và kết quả reload/retry; không ghi đè dữ liệu thật người học khi test.
Người học chưa approve hoàn toàn; các finding mới ở trạng thái đã ghi vào spec và **chưa được kiểm thử/đóng bằng evidence thực thi**.
