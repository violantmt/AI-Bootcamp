# Kiểm thử Knowledge Health dashboard
Chromium qua server tạm, profile test sạch:
- PASS: đúng 7 c1–c7; seed 2 KPI đỏ và 2 chưa có dữ liệu; c3=20%, c5=70%, c4=0%.
- PASS: lọc scope/trạng thái, mở hướng fix cho đỏ/vàng.
- PASS: c7 fixture 6/8=75% xanh; c4 3/15=20% vàng theo chiều thấp tốt; c2 0/0=N/A; tử vượt mẫu bị chặn.
- PASS: lưu/reload, checklist, xuất JSON 7 metric, reset về audit seed.
- PASS: mobile 390px không tràn ngang; không có lỗi JS.
Các điểm fixture nằm trong profile test, không ghi lại thành kết quả audit c7 hoặc số đo thật.
Audit dataset: 10 tên test/selector được kiểm có trong source test; 11 record markers tồn tại trong Decision Log; 10 file inventory tồn tại; 9 cặp package v1–v10 được đọc/hash để ghi proxy coupling.
Không chạy lại suite nghiệp vụ kho khi chỉ thêm dashboard; không tuyên bố đã human-review audit, test c7 đạt hoặc triển khai thật. Chưa kiểm quota storage, mọi tình huống file snapshot hỏng, đa tab cùng ghi, trình duyệt khác hoặc direct-file trên máy người học.

Snapshot v2: regression Chromium mới PASS với c2=9/9=100% theo đợt gói demo và c7=8/8=100% người học chấm. Ban đầu 2 đỏ (c3/c5), 0 chưa đo; fixture 0/0 vẫn N/A, sai tỷ lệ bị chặn. Export/reset/persistence/mobile và không lỗi JS đều đạt. C2 có 9 patch thật và SHA archive/file, không chứng minh original Git commit. Các trạng thái c2/c7 thiếu số phía trên là lịch sử snapshot trước.

Snapshot v3: Chromium regression mới PASS: c3=10/10=100%, c5=7/10=70%, đúng một KPI đỏ; c2/c7 giữ snapshot đã có evidence. Filter/update/validation/export/reset/local reload/mobile đều pass, không lỗi JS. Tài liệu được audit tĩnh theo source/tests có sẵn; không chạy lại model/browser nghiệp vụ kho vì không sửa code kho. Review packet chưa có người học phản hồi, c5 không tăng.

Snapshot v4 dashboard regression Chromium PASS: c5=10/10 trace, thẻ vẫn hiện Changes Requested, tổng quan vẫn nêu còn finding/test chưa làm. Export/reset/persistence/mobile/validation đạt. Đây chỉ kiểm dashboard, KHÔNG chạy TS15–TS21 hoặc concurrency/storage fault của ứng dụng kho. Trạng thái Not Tested trong scenario không thay đổi.
