# c2 — Change Coupling theo đợt phát hành demo

## Quy ước đo hiện hành
Đơn vị change set ở lần audit này = một bước chuyển giữa hai gói demo liền kề v1→v2 … v9→v10. Đây là nhóm thay đổi hồi cứu theo phiên bản được bàn giao trong hội thoại, không phải atomic Git commit hoặc log thời điểm sửa file.
Phạm vi: 9 bước chuyển có code hành vi/UI thay đổi và ảnh hưởng yêu cầu/hướng dẫn/scenario. Mỗi bước đếm một lần dù sửa nhiều file. Không đưa bước tạo v1 ban đầu vào mẫu số vì chưa có baseline trước đó trong tập version được audit.
Một bước đạt khi diff có thay đổi code và cập nhật nội dung tài liệu liên quan đúng chủ đề, không chỉ một file .md bất kỳ. Đã đối chiếu phần REQ thêm vào và code/test ứng với thay đổi; patch và SHA256 được tạo từ archive có thật. Tài liệu có cập nhật vẫn có thể còn đoạn cũ, vì vậy c3 Freshness đánh giá riêng, không tự cho c3 đạt.
Giới hạn: không chứng minh thời điểm cập nhật cùng phút, thứ tự thao tác, cùng original commit hoặc policy từng PR ở production. Nếu tổ chức bắt buộc đơn vị original Git change set, bộ dữ liệu đó vẫn chưa có và phải đo riêng.

## Kết quả
9/9 đợt demo có code thay đổi và tài liệu liên quan cập nhật trong cùng gói mới → **c2 theo đợt phiên bản =100%**. Đây là audit AI có bằng chứng để người học kiểm lại, không giả tạo Git history.

| ID | Phạm vi thay đổi | Tài liệu đối chiếu | Diff evidence |
|---|---|---|---|
| CS-v01-v02 | Ngăn trùng dòng, lỗi theo dòng, tạo mã quản lý | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v01-v02.patch](changeset-evidence/CS-v01-v02.patch) |
| CS-v02-v03 | Ẩn lập phiếu cho Quản lý | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v02-v03.patch](changeset-evidence/CS-v02-v03.patch) |
| CS-v03-v04 | Sửa/xóa danh mục và đề nghị giảm tồn | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v03-v04.patch](changeset-evidence/CS-v03-v04.patch) |
| CS-v04-v05 | Hai nút danh mục và phản hồi tại chỗ | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v04-v05.patch](changeset-evidence/CS-v04-v05.patch) |
| CS-v05-v06 | Làm rõ phản hồi xóa và focus/viewport | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v05-v06.patch](changeset-evidence/CS-v05-v06.patch) |
| CS-v06-v07 | Xóa tồn 0 dù có lịch sử | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v06-v07.patch](changeset-evidence/CS-v06-v07.patch) |
| CS-v07-v08 | Xác nhận xóa trong trang | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v07-v08.patch](changeset-evidence/CS-v07-v08.patch) |
| CS-v08-v09 | Phản hồi tạo mã tại chỗ | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v08-v09.patch](changeset-evidence/CS-v08-v09.patch) |
| CS-v09-v10 | Phản hồi duyệt/từ chối tại lịch sử | REQ-PB03.md + TEST-SCENARIOS-PB03.md | [CS-v09-v10.patch](changeset-evidence/CS-v09-v10.patch) |

Từ phiên sau: đặt change ID trước khi sửa; lưu code diff và doc diff với cùng ID/commit/PR. Ghi lý do nếu change set không ảnh hưởng docs. Giữ nguyên đơn vị đo khi so trend; không so 100% package-level với c2 commit-level như cùng một phép đo.
