# Mở Knowledge Health dashboard c1–c7
1. Giải nén PB03-knowledge-health-dashboard.zip.
2. Mở knowledge-health/MO-KNOWLEDGE-HEALTH.html trên máy bạn. HTML chứa sẵn dữ liệu, không cần cài thư viện hoặc tải dữ liệu mạng.
3. Đầu trang có Knowledge Health · c1–c7; ban đầu 7 KPI, c3=10/10 và c5=10/10 có evidence; các KPI đạt ngưỡng không đóng finding hoặc cấp phép release, c2 đạt 9/9 theo đợt demo, c7 đã chấm 8/8.
4. Các thẻ đỏ mở sẵn hướng khắc phục. Bấm công thức để xem cách tính/owner/nguồn; xem ARTEFACT-AUDIT.md để biết file nào cần sửa.
5. Khi đã có evidence mới, dùng Cập nhật số liệu và điền tử/mẫu, ngày, nguồn. c7 đã có 8/8 được người học chấm; chỉ đổi khi có bộ kiểm mới kèm evidence.
6. Checklist chỉ ghi hành động, không tự đổi KPI. Lưu cục bộ theo trình duyệt khi được phép; không nhiều người cập nhật chung.
7. Xuất JSON để lưu snapshot; Khôi phục cần xác nhận. Snapshot khởi đầu là kết quả audit AI được mô tả, chưa là phê duyệt độc lập.
8. Chưa hỗ trợ import JSON hoặc đọc Git/CI tự động. Các file source ở thư mục cha kèm trong ZIP đã được chuẩn hóa KH-Refresh-1; bản trước ở history/before-knowledge-refresh/. Review người trực tiếp 3 artefact còn chờ, c7 là kết quả chấm trước refresh.

Nếu trình duyệt không mở/lưu file local do chính sách, nhờ hỗ trợ chạy `python -m http.server 8000 --directory knowledge-health` từ thư mục PB03 rồi mở máy cục bộ. Đã kiểm qua HTTP Chromium; cloud hiện chặn file:// nên thao tác nhấp đúp trên máy cá nhân cần bạn xác nhận.
Không nhập secret/dữ liệu thật nhạy cảm. Demo kho không đổi. Dashboard Project Health cũ đã chuyển vào lịch sử, không nằm trong gói Knowledge Health hiện hành.

C2 hiện đo hồi cứu theo bước chuyển gói demo, xem CHANGESET-REGISTER.md và các patch. Không có Git commit thật được dựng giả.

Snapshot v4 dùng vùng lưu mới để không ghi đè dữ liệu bạn đã nhập ở dashboard cũ. Bản gốc c2/c7 N/A là snapshot trước khi audit/chấm xong; mở MO-KNOWLEDGE-HEALTH.html từ ZIP v4 để xem số mới. C7 8/8 là kết quả người học chấm, C2 9/9 là audit AI theo đợt demo có diff, hai loại evidence được phân biệt.

V3: mở REVIEW-PACKET-PB03.md ở thư mục PB03 để review API, test scenario, hướng dẫn. Có thể đồng ý hoặc chỉ ra điểm cần sửa cho từng mục; chỉ khi có phản hồi thực tế mới cập nhật c5. C3=100% là audit AI về độ nhất quán, không thay phê duyệt người đọc.

Snapshot v4 có PMBA-REVIEW-01: API/scenario Changes Requested, guide reviewed provisional (“tạm ổn”). Các TS15–TS21 vẫn Not Tested. Xem REVIEW-FINDINGS.md để phân biệt đã ghi vào tài liệu với đã kiểm thử/được approve. c5 chỉ đo có trace review, không tỷ lệ Approvals.

Bộ dashboard hiện chỉ giữ Knowledge Health c1–c7. Không cần dùng hoặc cập nhật Project Health tổng quát. Các giới hạn approval và Not Tested vẫn giữ như snapshot v4.
