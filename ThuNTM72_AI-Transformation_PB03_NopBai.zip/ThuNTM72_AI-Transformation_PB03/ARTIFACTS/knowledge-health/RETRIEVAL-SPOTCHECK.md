# c7 — 8 câu truy xuất cần người học chấm

AI đã nêu đường dẫn/cụm test dựa hồ sơ để chuẩn bị kiểm tra. Đây là gợi ý câu trả lời có nguồn, không tự chấm PASS cho chính AI. Cần người học đối chiếu và ghi 0/1 mỗi câu: đúng+đủ+không bịa =1, thiếu/sai/không có nguồn =0; phải đủ spec/code/test/decision khi nguồn có. Nếu nguồn thiếu, câu trả lời phải nêu thiếu, không tự tạo record.
Phạm vi 8 câu dưới đây; sau chấm c7 = số câu đạt/8 ×100%. Trạng thái hiện hành: người học đã chấm đủ 8 câu, mỗi câu 1 điểm; c7 = 8/8 = 100%. Các đoạn chưa chấm phía dưới là lịch sử trước xác nhận cuối cùng. Không dùng tỷ lệ chưa chấm thành 0%.

| Câu hỏi | Doc/spec | Code (trong prototype/) | Test (trong prototype/) | Decision Log | Điểm người học 0/1 |
|---|---|---|---|---|---|
| Ai nhập phiếu, ai tạo mã? | API-PB03.md;REQ-PB03.md | model.mjs api role; app controls | test.mjs: role/manager tạo | D04/UAT03 | 1 — người học xác nhận Đạt |
| Vì sao bỏ gộp dòng? | REQ-PB03.md | app controls/renderDraft | test_browser.py option disabled | UAT02 | 1 — người học xác nhận Đạt |
| Tồn 0 có lịch sử được xóa không? | REQ-PB03.md;API-PB03.md | model delete/deletedProducts | test.mjs giảm Bút về0/xóa/reload | UAT06/UAT07 | 1 — người học xác nhận Đạt |
| Duyệt giảm tồn lúc nào đổi số? | API-PB03.md | model adjustments/review | test.mjs duyệt đúng một lần | D01/D05 | 1 — người học xác nhận Đạt |
| Thông báo tạo hàng ở đâu? | REQ-PB03.md cập nhật v9 | app createFeedback | test_browser.py createMessage | UAT08 | 1 — người học xác nhận Đạt |
| Duyệt/từ chối báo kết quả ở đâu? | REQ-PB03.md cập nhật v10 | app commit notify reviewMessage | test_browser.py reviewMessage | UAT09 | 1 — người học xác nhận Đạt |
| Phiếu nhập nhiều dòng sai có lưu một phần không? | REQ-PB03.md AC02 | model validate trước next | test.mjs Phiếu nhiều dòng lỗi | Người học đồng ý quy tắc demo; thiếu ADR riêng không được bịa | 1 — người học xác nhận Đạt |
| Demo có SoD người dùng thật chưa? | DELEGATION-MAP-PB03-FULL.md;DOD-PB03.md | app role selector, không auth production | test.mjs chỉ mô phỏng role, không chứng minh identity | EX06-D01 | 1 — người học xác nhận Đạt |

## Tiến độ chấm từng câu
Câu 1: người học xác nhận “Đạt — 1 điểm” sau xem câu trả lời và nguồn. Đã chấm 1/8, đạt 1 câu; 7 câu chưa chấm. Chưa tính c7 cuối cùng, không suy 100% từ một câu và không tính câu chưa chấm là 0.

Cập nhật chấm: câu 1=1, câu 2=1; đã chấm 2/8 và đạt 2 câu, còn 6 chưa chấm. c7 cuối cùng chưa tính.

Cập nhật chấm: câu 1=1, câu 2=1, câu 3=1; đã chấm 3/8 và đạt 3 câu, còn 5 chưa chấm. c7 cuối cùng chưa tính.

Cập nhật chấm: câu 1–4 mỗi câu 1 điểm; đã chấm 4/8, đạt 4 câu, còn 4 chưa chấm. c7 cuối cùng chưa tính.

Cập nhật chấm: câu 1–5 mỗi câu 1 điểm; đã chấm 5/8, đạt 5 câu, còn 3 chưa chấm. c7 cuối cùng chưa tính.

Cập nhật chấm: câu 1–6 mỗi câu 1 điểm; đã chấm 6/8, đạt 6 câu, còn 2 chưa chấm. c7 cuối cùng chưa tính.

Cập nhật chấm: câu 1–7 mỗi câu 1 điểm; đã chấm 7/8, đạt 7 câu, còn câu 8 chưa chấm. c7 cuối cùng chưa tính.

## Kết quả cuối cùng được người học xác nhận
| Câu | Điểm | Bằng chứng |
|---|---|---|
| 1 | 1 | Người học: Đạt — 1 điểm |
| 2 | 1 | Người học: Đạt — 1 điểm |
| 3 | 1 | Người học: Đạt — 1 điểm |
| 4 | 1 | Người học: Đạt — 1 điểm |
| 5 | 1 | Người học: Đạt — 1 điểm |
| 6 | 1 | Người học: Đạt — 1 điểm |
| 7 | 1 | Người học: Đạt — 1 điểm |
| 8 | 1 | Người học: Đạt — 1 điểm |

c7 Retrieval Quality = 8 câu đúng–đủ–không bịa / 8 câu đã chấm × 100% = **100%**. Target ≥70%: đạt trong bộ 8 câu demo v10 này.
Phương pháp: AI trình câu trả lời và nguồn spec/code/test/decision trong hội thoại; người học chấm từng câu. Đây là đánh giá có hướng dẫn trên tập đã công bố, không phải bài kiểm mù hoặc bảo đảm truy xuất đúng mọi câu hỏi. Không đồng nghĩa demo đã có SoD/DB/auth production hoặc c3/c5 đã được sửa. Khi scope hoặc tài liệu đổi, kiểm lại và giữ version bộ câu.
