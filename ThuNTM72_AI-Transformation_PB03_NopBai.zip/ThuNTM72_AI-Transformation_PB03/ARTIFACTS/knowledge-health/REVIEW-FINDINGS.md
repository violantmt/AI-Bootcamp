# PMBA-REVIEW-01 — Findings và trạng thái

Người review: người học, góc nhìn PM/BA, đọc bản tóm tắt REVIEW-PACKET. Không claim đã review mọi dòng code hoặc approve toàn bộ 3artefact.

| Finding | Artefact | Xử lý tài liệu | Trạng thái thực thi / phê duyệt |
|---|---|---|---|
| Không trùng/không âm/audit phải có kiểm chứng | API | Thêm bảng invariants hiện có/giới hạn, contract production cần transaction/idempotency/audit | Tuần tự mock có partial evidence; thực thi production chưa có, chưa Approved |
| Không coi UI role là RBAC/SoD thật | API | Nêu auth/identity/server/SoD chưa triển khai, không dùng mock làm evidence | Đã làm rõ limitation, không tự đóng test thật |
| Concurrent stock deduction | Scenario | TS15 | Not Tested |
| Duplicate/double-click/retry | Scenario | TS16/TS17 | Model tuần tự cũ có evidence; test mở rộng Not Tested |
| Hai đề nghị cùng hàng | Scenario | TS18 | Có test tuần tự nhánh thiếu tồn; nhánh mở rộng Not Tested |
| Reload consistency | Scenario | TS19 | Reload cơ bản cũ có evidence; matrix đầy đủ Not Tested |
| Lỗi storage/không lưu được | Scenario | TS20/TS21 | Not Tested, cần fault injection |
| Hướng dẫn thao tác | BAT-DAU-DEMO | Người học nhận xét “tạm ổn” | Reviewed provisional, có trace, không blanket approval |

c5 đo **trace review**, không đo số Approved. Hai artefact có nhận xét Changes Requested đủ trace, cộng hướng dẫn được review “tạm ổn” nên từ7/10 lên10/10=100%. Không nói10/10 đã Approved hoặc finding được đóng. Code demo không thay đổi trong đợt cập nhật này.
