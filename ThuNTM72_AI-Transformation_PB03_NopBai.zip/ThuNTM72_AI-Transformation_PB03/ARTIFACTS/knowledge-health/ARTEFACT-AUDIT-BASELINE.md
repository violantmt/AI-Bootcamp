# Audit artefact Knowledge Health — demo v10

Inventory cố định 10 tài liệu lõi có liên quan demo/thiết kế/giải trình demo. Không đưa file history, log append chủ ý lưu lịch sử, tài liệu giả lập W3, chính dashboard/audit mới tạo vào mẫu số. Bản kế hoạch được xét trạng thái/phiên bản hiện hành, không đòi kế hoạch đã triển khai production.
Fresh = đọc được trạng thái hiện hành nhất quán, không còn chỉ dẫn trái nhau phải tự đoán đoạn nào dùng. Thêm ghi chú cuối file chưa đủ nếu phần thao tác cũ vẫn mâu thuẫn. Đây là audit nội dung AI thực hiện, chưa phải review độc lập.
Review evidence = có dấu vết người học góp ý/chốt phần nội dung thuộc artefact, không đòi đã duyệt mọi dòng. Không có trace trực tiếp thì tính “chưa có evidence”, không kết luận người chưa từng đọc.

| Artefact | Fresh? | Có trace review? | Finding freshness | Evidence review / thiếu |
|---|---|---|---|---|
| REQ-PB03.md | Chưa | Có | Đầu file DRAFT/chờ quyền, nhiều đoạn cũ chặn xóa có lịch sử và bản gộp dòng; append mới chưa thành spec hiện hành duy nhất. | Người học chốt quy tắc trong hội thoại; DECISION-LOG các UAT/Dxx |
| WBS-PB03.md | Chưa | Có | Vẫn có câu chưa estimate/chưa review, phạm vi 6 tuần trước phần bổ sung 8 tuần. | Người học tách hướng dẫn/UAT, chốt hoãn Excel và 8 tuần |
| EST-PB03.md | Chưa | Có | Còn phần “chưa được người học chốt” trước quyết định đã chốt 8 tuần. | Người học chọn phương án 8 tuần và điều kiện kiểm effort/critical path |
| RISK-PB03.md | Chưa | Có | Nhiều Top-5 khác nhau và nhãn bản AI chờ review trước phần đã chốt. | Người học chốt Top-5 và kiểm soát transaction/RBAC/idempotency/backup |
| DOR-PB03.md | Chưa | Có | Phần đầu còn CHỜ CHỐT/gộp dòng và chưa build, sau đó nhiều lần ghi đã thay đổi. | Người học duyệt phạm vi demo và clarification trước build |
| API-PB03.md | Chưa | Chưa thấy | Mục mergeLines/quy tắc xóa ban đầu còn lẫn với phần v7/v8; cần contract chỉ một bản hiện hành. | Chưa thấy dấu review trực tiếp API contract; review demo không tự tính review API |
| TEST-SCENARIOS-PB03.md | Chưa | Chưa thấy | Scenario v2 giữ mô tả Quản lý chỉ tạo; nhiều lớp v3–v10, không còn một suite đọc duy nhất. | Có thử demo thực tế, chưa có xác nhận review riêng artefact scenario này |
| BAT-DAU-DEMO.md | Chưa | Chưa thấy | Đoạn hướng dẫn v4 vẫn nói hàng có lịch sử bị chặn xóa; cuối file mới sửa v7. | Chưa có review trực tiếp hướng dẫn; không suy từ việc người học mở được demo |
| DELEGATION-MAP-PB03-FULL.md | Có | Có | Bản đã viết lại với responsibility/gate/evidence, ghi rõ production chưa thực hiện. | Người học xác nhận HITL và yêu cầu bốn trường, review F10/F11/F18 |
| DOD-PB03.md | Có | Có | Gate demo/production tách rõ, cổng chưa làm không gán PASS. | Người học yêu cầu đưa review/test/evidence vào DoD |

Kết quả: c3 = 2/10 = 20%; c5 = 7/10 = 70%. Phạm vi này không phải toàn bộ repository. Là finding cần sửa docs/review, không phải lỗi chạy demo.
