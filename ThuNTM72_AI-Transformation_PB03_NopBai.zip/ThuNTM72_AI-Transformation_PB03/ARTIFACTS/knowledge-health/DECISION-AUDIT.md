# c6 — Thay đổi lớn trong demo

Population: 11 thay đổi nghiệp vụ/quy trình/tương tác có ảnh hưởng người dùng trong v1–v10. Không đếm mỗi test fix/mobile/layout riêng.

| Thay đổi | Record trong DECISION-LOG-PB03.md |
|---|---|
| Gộp dòng do người học đề xuất | Cập nhật sau clarification |
| Thay gộp bằng ngăn trùng | UAT02 |
| Tạo danh mục chỉ quản lý | D04 |
| Ẩn nhập phiếu cho quản lý | UAT03 |
| Thêm sửa/xóa và luồng giảm tồn | D05 |
| Chỉ hai nút quản lý danh mục | UAT04 |
| Thông báo xóa tại chỗ và rõ hơn | UAT05 |
| Xóa tồn 0 dù có lịch sử | UAT06 |
| Xác nhận xóa trong trang | UAT07 |
| Thông báo tạo hàng tại chỗ | UAT08 |
| Thông báo duyệt/từ chối tại chỗ | UAT09 |

c6 = 11/11 = 100%, audit AI kiểm record tồn tại và khớp ý. Không chứng minh đã có approval production hoặc số record tương đương số lỗi AI.
