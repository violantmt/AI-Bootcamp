# EX-06 — Delegation Map đầy đủ PB03

Input: WBS-PB03.md, RISK-PB03.md và quyết định người học. 20 task, có đủ nhóm 5-loại, mức L, A/A+, AI Responsibility, Human Approver, Approval Gate, Evidence Required.

## Quy tắc chung đã được người học xác nhận
- Human-in-the-Loop, Least Privilege và Evidence-based Approval. Người quyết định và chịu trách nhiệm cuối cùng với thao tác quan trọng.
- F10/F11/F18: AI chỉ hỗ trợ; không tự thực hiện production. Trong mô hình bài tập này người có thẩm quyền thực hiện sau phê duyệt. Phê duyệt không tự nâng mức AI hoặc cấp quyền production ngoài bảng.
- A+ là kiểm soát tăng cường, không tự động cấp L4. Không cấp L5. L3 chỉ sandbox trong phạm vi bảng.
- Approval phải gắn với người/vai trò, hành động, môi trường, phạm vi dữ liệu, phiên bản artefact, thời điểm và điều kiện. Đổi script/version/scope thì phải review lại; log câu “đồng ý” chung không là giấy phép production.
- Gate thiếu bằng chứng/FAIL/CHƯA CHẠY → chặn; AI không tự đánh dấu Done hoặc gỡ chốt bằng lời tự xác nhận.
- Đây là kế hoạch/hồ sơ học tập: chưa có team/DB production được kết nối, chưa có DBA/release approval thật, staging hoặc backup/restore production.

| ID | Trace | Task | Nhóm | Mức AI | Leash | AI Responsibility | Human Approver | Approval Gate | Evidence Required |
|---|---|---|---|---|---|---|---|---|---|
| F01 | 1.1 | Nháp requirement/AC | AI-do | L1 | A | Nháp yêu cầu/AC, đánh dấu thiếu; không tự chốt intent | Người học/PM duyệt | So brief và quyết định hiện hành, đánh dấu thiếu | REQ có ID/nguồn, danh sách câu hỏi, review người học |
| F02 | 1.1 | Chốt scope và trade-off 8 tuần | Human-do | L2 hỗ trợ | A | Phân tích phương án và tác động effort, không tự cam kết timeline | PM/chủ nghiệp vụ | AI đề xuất, người chọn; chưa có quyền cam kết stakeholder | REQ/WBS/EST/TRADEOFF cùng scope, quyết định người phụ trách |
| F03 | 1.2/2.1 | Nháp schema và API | AI-do | L1 | A | Nháp schema/API và ràng buộc, không tự chạy DB thật | Dev review | Khóa/ràng buộc/trace; bản nháp chưa chạy hệ thật | Schema/API version, trace AC và review dev |
| F04 | 1.3/1.4 | Dựng UI/demo dữ liệu giả | AI-do | L3 | A | Dựng và sửa prototype trong sandbox dùng dữ liệu giả | Người học thử | Test + UAT demo; sandbox, sửa được, không dữ liệu thật | Bản demo/version, AC và kết quả UAT demo |
| F05 | 1.6 | Sinh/chạy test mock | AI-do | L3 | A | Sinh/chạy test sandbox, ghi trung thực PASS/FAIL/SKIP | Người học đọc kết quả | Exit/count đúng, invalid/role/stock; test đỏ chặn | Lệnh/exit code/test count/report đúng phiên bản |
| F06 | 2.1/R04 | Đề xuất chính sách phân quyền | Human-review | L1 | A+ | Nháp RBAC, SoD, least privilege và negative cases; không cấp quyền | PM/chủ hệ thống đích thân duyệt | Cố ý giữ L1 dù AI viết được; không để AI tự cấp quyền | Ma trận role-action, review chính sách và test plan |
| F07 | 2.1/R04 | Áp cấu hình quyền lên hệ thật | Human-do | L1 nháp lệnh | A+ | Chỉ nháp lệnh thay quyền, scope và cách thu hồi | Chủ hệ thống | Không tự chạy; cần quyền rõ và negative test; chưa được phép trong bài | Phê duyệt theo môi trường/phiên bản, negative tests, log thay đổi/rollback |
| F08 | 2.3/R03 | Sinh code transaction/xuất kho | AI-do | L3 sandbox | A+ | Sinh code transaction/locking trong sandbox, hỗ trợ review | Dev reviewer | Concurrency/atomic/không âm và review người trước dùng thật | Diff/version, concurrency/atomic/không âm tests và dev approval |
| F09 | 2.4/R05 | Sinh luồng duyệt idempotent | AI-do | L3 sandbox | A+ | Sinh code idempotency và kiểm trạng thái trong sandbox | Dev reviewer | Duyệt đúng một lần, trạng thái/role; không tự deploy | Test lặp/cạnh tranh/quyền, report và review dev |
| F10 | 2.4 | Duyệt đề nghị điều chỉnh tồn thật | Human-do | L2 hỗ trợ phân tích/đề xuất | A+ | Phân tích bất thường và đề xuất điều chỉnh từ dữ liệu được phép; không tự duyệt | Quản lý kho, khác người tạo yêu cầu | Xác minh chứng từ, RBAC tại API, SoD, không tự duyệt; tồn/idempotency đúng và audit có đủ trước áp dụng | ID đề nghị, chứng từ gốc, requester/approver khác người, kiểm quyền API, trạng thái và audit log |
| F11 | 2.1/R07 | Chạy migration DB thật | Human-do | L1 nháp kế hoạch | A+ | Nháp migration script, test plan và rollback plan; không chạy production | DBA hoặc người được ủy quyền | Review/phê duyệt migration, staging đạt, backup có bằng chứng restore và rollback plan; người được phép mới chạy production | Script/version/checksum, review DBA, approval, staging results, backup/restore evidence, rollback plan |
| F12 | 2.2/R06 | Nạp tồn đầu kỳ thật | Human-review | L1 nháp đối soát | A+ | Nháp đối soát từ dữ liệu được phép, không tự nhập tồn thật | Quản lý kho + chủ dữ liệu | Nguồn/đối soát/signed approval trước nạp; không tự dùng dữ liệu thật | Nguồn tồn đầu kỳ, kết quả đối soát, chủ dữ liệu ký nhận và import/test log |
| F13 | 2.6a | Sinh báo cáo/query nháp | AI-do | L3 sandbox | A | Sinh query/báo cáo sandbox, nêu nguồn/thiếu dữ liệu | Dev/PM kiểm số | Nguồn rõ, đối soát; thiếu dữ liệu N/A; không tự công bố | Query version, nguồn số liệu, đối soát và review người |
| F14 | 2.7/R11 | Review chéo code và test của AI | Human-review | L2 hỗ trợ | A+ | Hỗ trợ tìm lỗi và gợi ý test, không thay dev reviewer | Hai dev review | AI review thêm, không thay dev approval và test thực | Code diff, test case/report, người review/finding/kết quả xử lý |
| F15 | 2.8/R08 | Nháp backup/restore, đề xuất RPO/RTO | AI-do | L1 | A+ | Nháp backup/restore và phân tích RPO/RTO theo nghiệp vụ | Vận hành + chủ nghiệp vụ | Chốt RPO/RTO, diễn tập môi trường được phép; không tự backup dữ liệu thật | RPO/RTO được chốt, backup log, restore drill/đối soát, quyền thao tác |
| F16 | 2.9 | Nháp hướng dẫn sử dụng | AI-do | L3 | A | Nháp hướng dẫn theo chức năng đã có | PM/thủ kho review | Chỉ mô tả chức năng thật đã có; bấm thử theo hướng dẫn | Hướng dẫn khớp version, người dùng thử theo hướng dẫn/finding |
| F17 | 2.10 | UAT với thủ kho và nghiệm thu | Human-do | L1 hỗ trợ kịch bản | A | Soạn scenario, tổng hợp phản hồi; không giả người dùng/ký thay | Thủ kho + PM | Người dùng thử thật, không ký thay hoặc bịa kết quả | UAT người dùng thật, kết quả/finding/retest và người nghiệm thu |
| F18 | 2.11 | Push/merge/release hệ thống | Human-do | L1 nháp checklist | A+ | Chuẩn bị release checklist, tổng hợp test results/rủi ro; không tự release | Release Owner | DoD đạt, test quan trọng pass, risk được xử lý, rollback plan có thể thực hiện; approval hợp lệ gắn đúng version/môi trường; người release thực hiện | DoD đúng version, test reports, risk assessment, rollback plan, approval Release Owner và deploy/rollback log do người thực hiện |
| F19 | R12 | Gửi khóa/dữ liệu nhạy cảm cho AI ngoài phạm vi | AI-không-nên | L0, không cấp hành động | A+ | Không gửi secret/dữ liệu thật ngoài phạm vi; dùng giả/được phép | Chủ dữ liệu/bảo mật | Thiếu quyền/nguồn kiểm soát thì hard-stop; chỉ dữ liệu giả trong bài | Nguồn dữ liệu hợp lệ/quyền được xác minh; thiếu thì hard-stop |
| F20 | R11/EX05 | Tự review chéo trace và số liệu | AI-review | L2 | A | Đối chiếu trace/claims với nguồn; không tự xác nhận thay người | Người học/PM phân xử | Chỉ dẫn nguồn thực, không tự ký nghiệm thu hoặc điền số thiếu | Source-to-claim links, audit notes, correction log và review người |

## Vì sao cố ý giữ mức thấp
F06 giữ L1 dù AI có thể viết toàn bộ chính sách: sai quyền ảnh hưởng tài sản/dữ liệu, con người phải chốt. F10 là L2 phân tích/khuyến nghị nhưng quyền duyệt vẫn Human-do. F11/F18 giữ L1 tạo script/checklist; khả năng tạo file không đồng nghĩa quyền chạy production. Người học đã nêu rõ lý do rủi ro/nghiệp vụ/trách nhiệm trong hội thoại và VIVA.
F04/F05/F08/F09/F13/F16 dùng L3 cho tác vụ sandbox có ranh giới và kiểm được. Bước áp dụng hệ thật là quyết định riêng, không tự đi tiếp vì sandbox test pass.

## Trạng thái review và kiểm chứng
- Người học đã xác nhận HITL cho ba task F10/F11/F18 và bổ sung gate/evidence cụ thể; các nội dung đó đã phản ánh trong bảng.
- Bốn trường trách nhiệm/phê duyệt đã được AI điền cho cả 20 task để reviewer đọc thống nhất. Không suy diễn người học đã duyệt riêng mọi hàng mới hoặc đã thông qua production.
- SoD bản thật cần định danh từng người, không chỉ tên role. Demo chỉ cho chọn role, chưa chứng minh requester và approver là hai người khác nhau; phải test auth/identity ở bản production.
- Staging, review DBA, restore drill, Release Owner approval và UAT thủ kho thật chưa diễn ra; không đánh dấu các gate đó PASS.
