# Bắt đầu demo v10 — Không cần viết code

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Mở demo
1. Mở ../CODEBASE/prototype/MO-DEMO.html trong thư mục đã giải nén. Đầu trang hiện v10. Các gói ZIP cũ là snapshot lịch sử, đừng nhầm với bản đang thử.
2. Chọn Thủ kho hoặc Quản lý. Đây là đổi vai trò demo, không đăng nhập thật.
3. Dữ liệu chỉ lưu cục bộ trình duyệt. Đường dẫn file/trình duyệt khác có thể dùng vùng lưu khác; đừng xóa file/dữ liệu cũ nếu cần giữ bằng chứng.
4. Nếu bị chính sách chặn mở/lưu file, báo lỗi. Phương án cần người hỗ trợ: từ thư mục PB03 chạy `python -m http.server 8000 --directory prototype`, rồi mở `http://localhost:8000/MO-DEMO.html` trên chính máy đó. Đây là địa chỉ local để chạy trên máy cá nhân, không là preview cloud.
Đã kiểm demo qua HTTP Chromium; môi trường cloud chặn file://, cách nhấp đúp trên máy bạn cần tự xác nhận.

## Thử các thao tác chính
- Thủ kho: chọn Sổ ở dòng duy nhất, nhập10/lưu → tồn Sổ tăng10. Nhập -3/0/1.5 → lỗi, tồn không đổi. Nếu còn dòng khác trống, đọc lỗi chỉ dòng, nhập số hoặc bấm Bỏ dòng.
- Thêm dòng: chọn hàng chưa có; một mã chỉ một dòng. Không có nút gộp; hết danh mục thì nút thêm bị khóa.
- Quản lý: tạo mã THUOC, tên Thước kẻ, đơn vị cây → tồn0; kết quả/lỗi ngay dưới nút Tạo. Chọn Thủ kho để nhập mã mới.
- Chỉnh sửa danh mục: chỉ Lưu chỉnh sửa/Xóa hàng. Sửa tên; mã/unit chỉ đổi khi tồn0/chưa dùng. Kết quả ngay dưới mục.
- Xóa: còn tồn → báo rõ còn bao nhiêu, không xóa. Tồn0 → bấm Xóa rồi Xác nhận xóa trong trang; thành công nêu mã/tên. Hủy không xóa. Dù đã có lịch sử vẫn xóa khi tồn0; phiếu/lịch sử còn giữ, không tạo lại mã đã xóa.
- Giảm tồn: Thủ kho gửi số lượng/lý do, kiểm tồn chưa đổi. Quản lý duyệt → tồn giảm, có trước/sau/người/giờ; hoặc nhập lý do và từ chối → tồn không đổi. Kết quả/lỗi dưới Đề nghị và lịch sử giảm tồn.
- Tải lại rồi chọn role để xem dữ liệu giữ lại. Quản lý không thấy Lập phiếu nhập; Thủ kho không thấy quản lý danh mục hoặc nút duyệt.

## Giới hạn và trạng thái bài
Dữ liệu giả, không dùng kho thật/khóa bí mật. Chưa có auth/SoD hai người thật, DB/transaction production hoặc đồng bộ nhiều tab/người. Hàng inactive từ bản cũ có thể còn trong dữ liệu; UI hiện không có nút ngừng/dùng lại.
Demo v10 đã được người học nghiệm thu; điều này không tự hoàn tất mọi tiêu chí hồ sơ/nộp hoặc production. Hallucination EX05: người học xác nhận chưa phát hiện, không gài lỗi giả. Người học đã review và nhận xét “hướng dẫn mình thấy cũng tạm ổn”. Ghi là review có điều kiện, không suy thành phê duyệt toàn bộ; xem knowledge-health/HUMAN-REVIEW-RECORD.json.
