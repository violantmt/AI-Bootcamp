# Decision Log PB03

Đã có quyết định nghiệp vụ do người học xác nhận. Chưa có lỗi AI thật được người học phát hiện/sửa; quyết định chọn phương án không được tính thành lỗi AI hoặc Human-edit.
Ghi ngay khi xảy ra, giữ bản trước/sau làm bằng chứng.

| Thời điểm | File/mục và output AI gốc | Bạn phát hiện/sửa gì | Lý do | L/Leash | Cổng/hard-stop | Kết quả kiểm lại |
|---|---|---|---|---|---|---|

Mục tiêu theo Program: ≥3 lỗi AI thật → bạn sửa. Chưa đủ thì ghi chưa đủ; không dựng lỗi hoặc viết hồi tố như sự kiện thật.

## D01 — Người duyệt điều chỉnh tồn
- Người học: “thủ kho nên gửi đề nghị để quản lý duyệt”.
- Quyết định: thủ kho gửi đề nghị; quản lý duyệt trước khi hệ thống điều chỉnh tồn.
- Nguồn: câu trả lời trực tiếp trong cuộc hội thoại; không suy diễn thêm lý do của người học.
- Phạm vi: quy tắc nghiệp vụ; chưa triển khai, chưa kiểm thử, chưa xác nhận phạm vi MVP.
- Kiểm soát dự kiến: đề xuất chưa duyệt không làm đổi tồn; thủ kho không tự duyệt. Đây là tiêu chí do AI đề xuất, cần người học review.
- Bằng chứng lỗi AI: chưa có; không cộng vào chỉ tiêu ≥3 lỗi thật.

## R01 — Phản biện tình huống luyện tập nhập âm
- Bối cảnh: AI đưa ví dụ giả định nhập -3 mà được lưu; đây không phải lỗi phát sinh trong sản phẩm.
- Người học xác định kết quả sai vì vi phạm quy tắc số lượng nguyên lớn hơn 0.
- AI chuyển phản biện thành AC06: từ chối, không lưu phiếu thành công, giữ tồn 10; bổ sung ca 0, số lẻ và ca hợp lệ để review/test.
- Trạng thái: đã có bằng chứng hiểu quy tắc; kiểm thử chưa chạy.
- Không cộng vào chỉ tiêu ≥3 lỗi AI thật được người học sửa; không tự suy ra thời gian làm hoặc Human-edit.

## D02 — Bảo vệ scope trước đề nghị barcode
- Người học tự viết phản hồi stakeholder: công nhận lợi ích, nêu cần khảo sát/thiết kế/kiểm thử, không hứa mốc chưa có cơ sở; ưu tiên luồng MVP, xem xét barcode đợt sau.
- Nguồn: nguyên văn trong REQ-PB03.md.
- Trạng thái: hoàn thành phản hồi tình huống scope; không phải lỗi AI, không tính thành Human-edit hoặc lỗi sản phẩm.
- AI đề xuất làm rõ rằng camera điện thoại có thể đủ, không mặc định phải mua phần cứng hay thiết kế lại toàn bộ luồng; chờ người học review.

## D03 — Ranh giới giao việc demo và phân quyền
- Nguyên văn người học: AI có thể tự dựng màn hình demo vì đó là môi trường giả lập an toàn, mang tính kỹ thuật và có thể sửa đổi dễ dàng nếu có sai sót. Ngược lại, việc phân quyền sửa tồn kho ảnh hưởng trực tiếp đến tài sản thực tế và tính bảo mật của doanh nghiệp, đòi hỏi tư duy quản trị rủi ro và trách nhiệm giải trình mà chỉ con người mới có quyền quyết định.
- Kết quả: xác nhận hiểu lý do cho phép AI dựng UI demo trong giới hạn, giữ thiết kế phân quyền ở mức nháp L1/A+ để con người quyết định.
- Không suy ra cho phép thay quyền trên hệ thật hoặc duyệt toàn bộ Delegation Map.
- Chưa có lỗi AI thật được sửa trong lượt này; không cộng Human-edit.

## Cập nhật sau clarification dòng trùng của người học
Người học đồng ý phạm vi/quy tắc demo và yêu cầu có nút “Tự động gộp dòng” thay vì chỉ bắt sửa thủ công. Đây là bổ sung thực tế do người học review, không phải lỗi sản phẩm đã phát hiện.
Quy tắc triển khai: chặn Lưu khi trùng; nút gộp chỉ cộng các dòng hợp lệ cùng mã trong nháp, không tự lưu; dòng sai bị từ chối trước khi cộng. Các chi tiết kiểm tra trước gộp và bấm Lưu riêng do AI cụ thể hóa, người học cần thử/review.
Kế hoạch build đã được người học chấp thuận với bổ sung trên. Đã dựng Tier 2, chạy 17 test logic và kiểm UI Chromium. DoR đủ cho build demo; nghiệm thu người học/hoàn thành toàn bài vẫn chờ. Các trạng thái DRAFT/chưa build ở phần trên là lịch sử trước quyết định này.

## UAT01 — Thông báo lỗi không chỉ rõ dòng
- Người học báo Sổ tồn 20 nhập 10 bị lỗi 400 không hiểu nguyên nhân.
- Tái hiện: có dòng Bút trống và dòng Sổ 10 thì validation cả phiếu thất bại; riêng Sổ 10 hợp lệ và lên 30. Chưa khẳng định phiếu gốc người học có đúng cấu hình này.
- Lỗi AI đã xác nhận: thông báo chung không nêu dòng, gây hiểu nhầm; AI sửa để nêu dòng/mã và cách xử lý. Browser regression đã đạt.
## UAT02 — Cải tiến chọn hàng do người học đề xuất
- Thay cho cho phép trùng rồi gộp: disable hàng đã chọn, tự chọn mã còn lại, hết danh mục thì chặn thêm, bỏ dòng thì trả lại lựa chọn. Đây là cải tiến nghiệp vụ/UI, không dựng thành lỗi dữ liệu đã xảy ra.
## D04 — Mở rộng tạo hàng do người học chốt
- Người học chọn “Chỉ quản lý tạo; thủ kho chọn để nhập”. Đã triển khai tạo mã với tồn 0, kiểm mã trùng, lưu dấu người tạo/thời điểm; giữ quyền ghi phiếu cho thủ kho.
- Giới hạn hai hàng của bản cũ là phạm vi trước đây; không tính là lỗi trái spec.
- Không suy ra đã đủ ≥3 lỗi AI thật; giờ thật và token chưa có.

## UAT03 — Hiển thị phần không được cấp quyền
- Người học xác nhận demo v2 ổn, rồi yêu cầu Quản lý không thấy phần Lập phiếu nhập vì không có quyền.
- Đã sửa: ẩn toàn section theo role, hiện lại cho Thủ kho; giữ chặn 403 trong mock. Chuyển thông báo chung ra ngoài section để không mất thông báo tạo mã.
- Chromium xác minh ẩn/hiện khi đổi role, thông báo tạo mã vẫn thấy; regression đạt. Đây là phản biện/cải tiến thật của người học, không tự quy đổi thành đủ 3 lỗi AI thật.
- UAT v3: chờ người học xác nhận.

## D05 — Yêu cầu mở rộng của người học
Người học yêu cầu Quản lý sửa/xóa hàng và đề nghị AI thiết kế cách Thủ kho giảm tồn hợp lý. AI áp quy tắc đã chốt trước đó: thủ kho đề nghị, quản lý duyệt. Chi tiết bảo toàn mã đã dùng, xóa có điều kiện/ngừng sử dụng và kiểm lại tồn là thiết kế AI đề xuất, đã thực hiện trong demo, cần người học nghiệm thu.
AI kiểm thử phát hiện và sửa: sau đổi mã, dropdown quản lý nhảy về hàng đầu; đã giữ lựa chọn hàng vừa sửa. Phát hiện và sửa tràn ngang mobile do phần duyệt mới. Đây là lỗi AI tự phát hiện, không tính thành lỗi người học bắt hoặc Human-edit.

## UAT04 — Đơn giản hóa quản lý danh mục theo phản biện người học
- Người học chỉ ra quá nhiều nút gây khó hiểu và thông báo xa mục thao tác khó nhận biết.
- Đã đổi tên mục, chỉ giữ sửa/xóa, đặt phản hồi thành công/lỗi bên dưới và làm rõ lý do không xóa khi còn tồn.
- Đây là phản biện UI thật của người học; không bịa số giờ hoặc tự khẳng định đã đủ ba lỗi AI theo rubric.
- Chromium xác nhận đúng 2 nút, phản hồi sửa/xóa hiển thị tại mục, xóa hàng tồn bị chặn và thông báo lượng tồn, mã vẫn còn; đổi lựa chọn xóa thông báo cũ. UAT người học v5 đang chờ.

## UAT05 — Người học chưa nhận thấy thông báo xóa v5
- Người học báo chưa thấy thông báo ngay bên dưới sau xóa.
- Mã v5 có thông báo tại chỗ và test visible trước đó đạt, nhưng chưa xác định chính xác tình huống người học gặp; không khẳng định nguyên nhân do người dùng/bản cũ.
- V6 làm nổi khung, thêm mã/tên hàng, focus/scroll đến thông báo và giữ lại khi đổi hàng/chỉnh trường; báo rõ hủy thao tác.
- Chromium đã kiểm thành công xóa mã mới, nội dung TEMP2, focus và khung nằm trong viewport, giữ thông báo khi đổi hàng, hủy xóa và chặn xóa tồn. Đây là báo cáo UAT thật; không giả số giờ hoặc tính đủ ba lỗi thay người học.

## UAT06 — Cho xóa mã hàng khi tồn 0 dù đã có giao dịch
Người học phát hiện Bút đã giảm về 0 vẫn bị chặn và yêu cầu thay quy tắc. Nguyên nhân xác nhận: rule v6 chặn cả mã có lịch sử. Đã bỏ điều kiện này, giữ lịch sử tách khỏi danh mục hiển thị, báo thành công/lỗi rõ tại mục. Đây là thay đổi rule nghiệp vụ trực tiếp từ người học; không viết lại quyết định cũ như thể lỗi code trái spec cũ.
Đã chạy Chromium đúng luồng Bút: nhập → duyệt giảm hết về 0 → xóa thành công → reload, mã biến mất nhưng phiếu và lịch sử duyệt vẫn còn. UAT v7 người học chờ xác nhận.

## Nghiệm thu demo v7 bởi người học
Nguyên văn: “ok, mình thấy demo cũng ổn rồi. Bạn hướng dẫn tiếp next step trong bộ tài liệu nhé.”
Kết quả: người học chấp nhận demo hiện tại và chuyển sang hoàn thiện bài. Không suy diễn đã hoàn thành viva, telemetry hoặc toàn bộ rubric.

## UAT07 — Chưa đạt phản hồi xóa theo nghiệm thu mới của người học
Người học phản hồi demo vẫn chưa đạt “không xóa được thì nêu lý do, xóa được thì báo thành công”. Dừng viva; không coi lời xác nhận trước đây là nghiệm thu phần này hiện tại.
Mã trước có phản hồi và test browser từng đạt, nhưng chưa xác định tình huống cụ thể gây khác biệt trên máy người học. Không khẳng định do bản cũ hay trình duyệt của người học.
V8 kiểm tồn trước khi yêu cầu xác nhận, dùng khung xác nhận trong trang thay popup native; kiểm mới đạt cả còn tồn, hủy, xác nhận xóa tồn 0 có lịch sử, vị trí phản hồi và reload. Chờ người học nghiệm thu lại.

## UAT08 — Nghiệm thu v8 và đề nghị đưa phản hồi tạo mã về đúng mục
Người học nói “Look good”, rồi yêu cầu đưa thông báo tạo mã thành công/thất bại xuống dưới Danh mục — tạo hàng mới. Đã bổ sung createMessage riêng dưới nút Tạo mã hàng. Chromium kiểm tạo thành công, trùng mã và thiếu mã đều có phản hồi tại vị trí này. Giữ thay đổi này là cải tiến UI thực tế, không giả định đủ lỗi AI hay tự điền telemetry. UAT v9 chờ xác nhận.

## UAT09 — Di chuyển phản hồi duyệt/từ chối
Người học đề nghị đưa phản hồi duyệt và từ chối thành công/thất bại xuống phần Đề nghị và lịch sử giảm tồn. Đã tạo reviewMessage riêng, kiểm Chromium cả hai ca thành công và thiếu lý do từ chối. Đây là thay đổi UI do người học đề xuất; UAT v10 chờ xác nhận.

## Nghiệm thu demo v10 và tiếp tục chốt bài
Người học xác nhận demo ổn và yêu cầu tiếp các bước trong tài liệu. Đóng trạng thái chờ UAT demo hiện hành; không tự đóng viva/telemetry. Tái sử dụng giải trình phân quyền đã có cho câu 2 để không bắt người học trả lời lại.

## Quyết định chốt — xử lý phiếu nhập đã lưu sai
Người học đồng ý: giữ nguyên phiếu gốc, không sửa/xóa trực tiếp phiếu đã lưu. Thủ kho gửi đề nghị điều chỉnh có lý do, Quản lý duyệt trước khi tồn thay đổi; lưu tham chiếu phiếu gốc, người yêu cầu/duyệt và thời điểm.
Quy tắc này đã chốt ở mức yêu cầu. Demo hiện chỉ có giảm tồn theo đề nghị và chưa có liên kết điều chỉnh về phiếu gốc; điều chỉnh tăng tồn do nhập thiếu cũng chưa có. Không tuyên bố toàn bộ quy trình này đã được triển khai/kiểm thử. Chưa cần thêm vào demo đang nghiệm thu.

## EX02-R01 — Người học tách rõ đào tạo và UAT người dùng thật
Người học yêu cầu bổ sung hướng dẫn thao tác ngắn và cho thủ kho dùng thử, với lý do giảm sai sót và tăng khả năng chấp nhận hệ thống. Bản WBS trước gộp hai việc ở 2.8; đã tách thành 2.9 và 2.10 có đầu ra/phụ thuộc, bổ sung 2.11 xử lý phản hồi. Chưa có buổi UAT thủ kho thật, không ghi PASS thay cho người dùng. Đây là hai hiệu chỉnh WBS, không dựng thành hai lỗi runtime AI.

## EX03-D01 — MoSCoW và hoãn Excel
Người học chọn giữ không âm và duyệt điều chỉnh, hoãn Excel khi thiếu capacity. AI lập estimate giả định: M+15% từ 58.65 xuống 55.20 dev-MD, vẫn vượt capacity 48 dev-MD. Đã lưu scope/WBS trước thay đổi, cập nhật kế hoạch và TRADEOFF. Các con số chưa được người học hiệu chỉnh; không coi hoãn Excel tự động bảo đảm 6 tuần.

## EX03-D02 — Người học chọn đề xuất 8 tuần có điều kiện
Người học đồng ý phương án 8 tuần vì chất lượng, rủi ro và capacity 64 so với 55,2 dev-MD; đồng thời yêu cầu xác nhận effort/dependency/critical path trước cam kết. Giữ Excel phase sau. Không coi đủ tổng ngày công là lịch đã khả thi; chưa thông báo deadline ra ngoài. Đây là review/phán đoán thật, không phải số thực tế đã đo.

## EX04-R01 — Người học bác mitigation “AI tự kiểm tra kỹ”
Người học bổ sung code review, unit/integration thực gồm invalid/concurrency/quyền, hai dev review chéo, UAT thủ kho và evidence từ report/log/CI; đề nghị đưa vào DoD. Đã cập nhật R11 và soạn DOD-PB03.md, ghi rõ các cổng MVP thật chưa thực hiện thay vì coi test demo là đủ. Top-5 rủi ro chưa được người học chốt.

## EX04-D02 — Chốt Top-5 và kiểm soát vận hành
Người học đồng ý R03/R04/R05/R11/R08, bổ sung transaction/locking/concurrency, RBAC/negative test, idempotency, review/test/evidence, backup/restore/RPO/RTO; review risk hằng tuần, không loại tiến độ/nguồn lực khỏi theo dõi. Đã ghi owner dự kiến và trigger; các số L/I vẫn giả định, RPO/RTO chưa chốt.

## EX05-D01 — Quyết định từ dữ liệu giả lập
Tuần tới, mình sẽ ưu tiên phân tích nguyên nhân module #2 trễ tiến độ, làm rõ các vấn đề logic và đánh giá mức độ nghiêm trọng của 3 bug để ưu tiên xử lý theo mức độ ảnh hưởng đến nghiệp vụ.
Đồng thời, mình sẽ làm việc với bên liên quan để bổ sung tài liệu API còn thiếu, đánh giá tác động đến tiến độ và cập nhật Risk Register.
Về AI adoption, mình sẽ tiếp tục theo dõi effort tiết kiệm và token usage, nhưng chỉ báo cáo các KPI có dữ liệu kiểm chứng, không tự suy diễn số liệu còn thiếu.
Đã lưu vào weekly/dashboard; chưa thực hiện hành động với bên ngoài. Không tự gán deadline hoặc severity. Làm rõ Adoption cần task log, không suy từ effort/token.

## EX05-D02 — Tiếp tục EX-05 và thiết lập evidence logs
Người học yêu cầu tiếp tục EX-05, đề xuất task usage log có prompt/diff/commit/skill-rule, so năng suất trước/sau, đối chiếu severity/Adoption/token cost, giữ N/A/Unverified, lưu hallucination thật. Đã tạo mẫu, chỉ điền một dòng usage tái dựng có căn cứ và ghi chưa có mẫu số; không giả lập số đo/commit. Chưa phát hiện hallucination thật để ghi thành tích. EX-06 mở rộng vẫn chờ, không tự chuyển tiếp khi người học đang chọn EX-05.

## EX05-D03 — Người học bổ sung nguồn Token Cost và quy trình Adoption
Đã lưu hai yêu cầu: kiểm usage/billing hoặc xác định cách thu cho phiên sau; tổng hợp task từ REQ/WBS/EST/RISK/WEEKLY, đối chiếu tương tác/file/evidence và phân loại AI-assisted/Non-AI/Unknown trước tính. Đã cụ thể hóa gộp task trùng và tách planned/thực hiện/kỳ giả lập để mẫu số không sai. Đây là kế hoạch dữ liệu đã ghi, không phải đã truy xuất billing hoặc đã đối soát toàn inventory.

## EX05-D04 — Inventory Adoption theo yêu cầu người học
Đã đọc/đối chiếu REQ/WBS/EST/RISK/WEEKLY và hội thoại, lập 31 task chuẩn đã/đang thực hiện có evidence, gộp các revision của cùng feature và tách 20 mục tương lai/chưa thực hiện khỏi mẫu số. Tất cả task trong phạm vi quan sát có AI hỗ trợ; Adoption hồi cứu 100%, không áp cho W3 hay toàn doanh nghiệp. Các file evidence được kiểm tồn tại; không giả prompt exports/commit/time logs. Chờ người học rà task ngoài inventory để hiệu chỉnh nếu có.

## EX06-D01 — Người học chốt HITL và các cổng có bằng chứng
Người học đồng ý AI hỗ trợ với duyệt tồn/migration/release, bổ sung RBAC/SoD/audit, staging/backup/restore, DoD/test/rollback, Least Privilege và Evidence-based Approval. Đã mở rộng map 20 task với AI Responsibility/Human Approver/Approval Gate/Evidence Required. F10 cập nhật từ L0 đọc sang L2 phân tích/khuyến nghị theo yêu cầu mới, quyền duyệt vẫn con người. Chưa có quyền production hay gate thật đạt. Bản map trước được lưu history.

## EX05-D05 — Ghi nhận trung thực chưa phát hiện hallucination
Người học: “Minh nghĩ ghi trung thực là chưa phát hiện giúp mình vì thật sự mình cũng chưa thấy hallucination ở đây.” Đã ghi kết luận có phạm vi trong log/audit/dashboard/weekly/tiến độ; không coi là đảm bảo không có lỗi hoặc đáp ứng tiêu chí có ít nhất một phát hiện thật. Không sinh hoặc gài dữ liệu bịa.

## PH01 — Dashboard Project Health theo yêu cầu người học
Đã dựng dashboard HTML standalone 12 KPI, bộ lọc theo phạm vi/trạng thái, công thức/ngưỡng/nguồn/fix/owner, cập nhật local có ngày/evidence, checklist và export JSON. Actual project không có nguồn giữ N/A; dữ liệu kế hoạch/demo/W3 tách riêng. Ngưỡng là đề xuất, không tự approve production. Chromium regression mới pass; chưa có UAT người học dashboard. Demo kho v10 không đổi.

## KH01 — Chuyển trọng tâm dashboard sang Knowledge Health c1–c7
Người học yêu cầu bám bộ 7 Knowledge Health KPI. Đã giữ Project Health cũ riêng, tạo dashboard và storage key mới. Lập RTM demo 10 req/5 module, audit freshness/review 10 artefact, kiểm 11 decision records, chuẩn bị 8 retrieval questions và audit 9 cặp archive. Baseline c1=100%, c3=20%, c4=0%, c5=70%, c6=100%; c2/c7 chưa có evidence đủ cho KPI chính. Đây là audit AI có population rõ và cần người học review, không phải mọi cổng/hệ thống đã đạt. Không sửa nghiệp vụ demo hoặc tự chuẩn hóa 8 file stale trong task dashboard.

## KH-C7-01 — Chấm câu truy xuất 1
Người học chấm “Đạt — 1 điểm” cho câu ai lập phiếu/ai tạo mã sau bảng nguồn REQ/code/test/Decision Log. Ghi 1/8 câu đã chấm, c7 cuối cùng còn chờ 7 câu; không dùng điểm này để xác nhận auth production.

## KH-C7-02 — Chấm câu truy xuất 2
Người học xác nhận “Đạt — 1 điểm” cho câu vì sao bỏ gộp dòng sau xem nguồn REQ/code/test/UAT02. Tiến độ 2/8; không quy thành c7 cuối cùng.

## KH-C7-03 — Chấm câu truy xuất 3
Người học xác nhận “Đạt — 1 điểm” cho câu xóa tồn 0 có lịch sử, sau bảng nguồn REQ v7/code/test/UAT06. Tiến độ 3/8; c7 cuối cùng chưa tính.

## KH-C7-04 — Chấm câu truy xuất 4
Người học xác nhận “Đạt — 1 điểm” cho câu duyệt giảm tồn sau bảng nguồn API/code/test/D01. Tiến độ 4/8; c7 cuối cùng chưa tính.

## KH-C7-05 — Chấm câu truy xuất 5
Người học xác nhận “Đạt — 1 điểm” cho câu vị trí thông báo tạo mã sau bảng nguồn REQ v9/code/test/UAT08. Tiến độ 5/8; c7 cuối cùng chưa tính.

## KH-C7-06 — Chấm câu truy xuất 6
Người học xác nhận “Đạt — 1 điểm” cho vị trí thông báo duyệt/từ chối sau nguồn REQ v10/code/test/UAT09. Tiến độ 6/8; c7 cuối cùng chưa tính.

## KH-C7-07 — Chấm câu truy xuất 7
Người học xác nhận “Đạt — 1 điểm” cho phiếu nhiều dòng không lưu một phần, sau nguồn AC02/code/test và nêu rõ thiếu ADR riêng/không phải transaction DB thật. Tiến độ 7/8; c7 cuối cùng chưa tính.

## KH-C7-08 — Hoàn tất bộ truy xuất demo v10
Người học chấm câu 8 “Đạt — 1 điểm”. Tổng 8/8 câu, mỗi câu 1 điểm, c7=100% trong tập đã công bố; AI trình nguồn, người học chấm, không tự gán điểm. Cập nhật seed/dashboard/audit và gói tải. Không tự nâng c3/c5 hoặc công nhận SoD/auth production; đây không là blind benchmark.

## KH-C2-01 — Làm rõ và bổ sung evidence Change Coupling
Người học hỏi c2 còn tử/mẫu thiếu. Đã phân biệt đơn vị đợt demo với original Git commit: dựng diff 9 gói kế tiếp, lưu hash/patch/REQ added đúng chủ đề, cả 9 đợt có doc liên quan cập nhật. Theo đơn vị đợt phiên bản c2=100%; không chứng minh same-instant/original commit. Nhận định ban đầu chỉ kiểm có file đổi chưa đủ, nay thêm đối chiếu nội dung; giữ c3 thấp vì doc update không đồng nghĩa doc fresh.

## KH-REFRESH-01 — Sửa c3 và chuẩn bị c5
Người học yêu cầu cải thiện c3/c5. Đã archive10 baseline, viết lại8 stale docs thành bản KH-Refresh-1, so code/test và giữ rule demo v10. EST PM loại Excel được hiệu chỉnh12,75→12,5 MD trước buffer (14,375 sau15%); dev55,2/capacity64 không đổi. Audit AI mới10/10fresh. c5 giữ7/10 vì chưa review API/scenario/hướng dẫn; đã có review packet để người học đọc/chốt. Không sửa code hoặc tự tạo approval mới.

## KH-PMBA-REVIEW-01 — Review có điều kiện và scenario còn mở
Người học review tóm tắt ở góc PM/BA, chưa approve hoàn toàn3artefact. API cần không trùng/không âm/lịch sử, role mock không chứng minh RBAC/SoD. Scenario cần concurrent deduction, duplicate/double-click/retry, hai request một hàng, reload consistency và storage failure; không kiểm chứng thì Not Tested. Đã cập nhật API KH-Refresh-2, thêm TS15–TS21 và status/evidence riêng. Người học sau đó nói hướng dẫn tạm ổn, ghi reviewed_provisional. c5 từ7/10 lên10/10 là trace review, không approval. Không sửa code/không chạy test mới trong đợt phản hồi tài liệu; các finding thực thi vẫn mở.

## KH-SCOPE-02 — Bỏ Project Health tổng quát
Người học yêu cầu bỏ Project Health vì không cần. Đã chuyển project-health/, PROJECT-HEALTH-KPI.md và gói tải cũ vào history/retired-project-health. Chỉ Knowledge Health c1–c7 nằm trong bộ hiện hành; demo kho/code/điểm audit và trạng thái Changes Requested/Not Tested không đổi.
