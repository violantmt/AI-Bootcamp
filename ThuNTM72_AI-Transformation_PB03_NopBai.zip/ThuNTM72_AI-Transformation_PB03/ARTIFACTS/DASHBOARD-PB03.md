# Dashboard tuần 3 — bản AI để người học review
Nguồn duy nhất: INPUT-W3.md. Thiếu dữ liệu → N/A, không hiển thị 0 thay cho chưa biết. Target/cảnh báo nào dưới đây là quy tắc AI đề xuất, không phải số đo được cho.

| KPI | Công thức | Giá trị hiện tại | Nguồn cần có | Cách xử lý/cảnh báo đề xuất |
|---|---|---|---|---|
| AI Adoption | Task dùng AI / tổng task ×100% | N/A | Task log phân loại AI | Chưa có mẫu số, không suy từ một hoạt động CRUD |
| Review Time | Tổng giờ review / số artefact được review | N/A | Time log và artifact log | Chưa có giờ/số artefact |
| Rework Rate | Artefact phải làm lại / tổng artefact ×100% | N/A | Rework log và artifact log | Không đổi số bug thành số artefact rework |
| Estimation Accuracy | 1 − abs(Actual−Estimate)/Actual, Actual>0 | N/A | Estimate và effort actual cùng scope | Trễ 1 ngày không thay cho effort actual |
| Compression | Giờ truyền thống cùng scope / giờ người thật | N/A | Baseline/time log đối chiếu cùng phạm vi | Tiết kiệm 1,5 MD chưa đủ hai đại lượng |
| Token Efficiency | MD tương đương giao được / token (triệu) | N/A | MD đầu ra được nghiệm thu và usage | 1,5 MD tiết kiệm không đồng nghĩa MD đầu ra giao được |
| Token Cost | Σ(token từng loại /1.000.000 × giá từng loại) | N/A | Usage tách input/output/cache và bảng giá model | 120k chưa có loại/model/giá |
| Token sử dụng (ước tính) | Tổng token tuần theo nguồn | Khoảng 120k | Input bài tập; đối soát usage nếu có | Là số ước tính, không phải log thực |
| Độ trễ module #2 | Actual/forecast milestone − plan, theo cùng lịch | Trễ 1 ngày theo input | Input; lịch chi tiết để đối soát | Cần review logic/estimate, chưa kết luận trễ toàn dự án |
| Bug mở | Đếm bug chưa đóng | 3: 2 UI, 1 logic | Input; cần bug tracker/độ nghiêm trọng | Phân loại severity trước ưu tiên |

## Review cần người học thực hiện
- Rà số và nguồn; không biến dữ liệu giả lập thành số liệu thực tế.
- Chọn một quyết định quản lý có căn cứ (không tự suy bug logic nghiêm trọng hơn mọi bug UI khi chưa biết severity).
- Workbook yêu cầu ≥1 hallucination thật AI tạo trong báo cáo. Bản này không cố chèn số bịa để tạo thành tích; hiện chưa ghi nhận hallucination số thật trong EX-05. Nếu không có thì báo chưa có, không coi đã hoàn tất tiêu chí đó. Có thể luyện thêm bằng ví dụ cố ý sai nhưng phải ghi rõ simulation, không nộp như phát hiện thật.

## Quyết định người học sau review
Tuần tới, mình sẽ ưu tiên phân tích nguyên nhân module #2 trễ tiến độ, làm rõ các vấn đề logic và đánh giá mức độ nghiêm trọng của 3 bug để ưu tiên xử lý theo mức độ ảnh hưởng đến nghiệp vụ.
Đồng thời, mình sẽ làm việc với bên liên quan để bổ sung tài liệu API còn thiếu, đánh giá tác động đến tiến độ và cập nhật Risk Register.
Về AI adoption, mình sẽ tiếp tục theo dõi effort tiết kiệm và token usage, nhưng chỉ báo cáo các KPI có dữ liệu kiểm chứng, không tự suy diễn số liệu còn thiếu.

AI làm rõ: tiếp tục ghi N/A cho Adoption cho tới khi có task log/mẫu số; không dùng token hoặc MD tiết kiệm thay tỷ lệ adoption. Chưa có hallucination số thật trong báo cáo EX-05 được người học chỉ ra; không đánh dấu đạt tiêu chí phát hiện hallucination.

## Kế hoạch chứng minh số liệu do người học đề xuất
Thiết lập AI Usage Log theo task, giữ prompt/response, artefact/diff/commit nếu có, skill/rule dùng thực tế; tính Adoption từ số task xác nhận có AI/tổng task cùng kỳ. So năng suất trước/sau qua baseline/time log có cả review/rework, cùng scope và chuẩn chất lượng. Đối chiếu claims với nguồn, đặc biệt severity/Adoption/token cost; giữ N/A hoặc Unverified khi thiếu evidence. Hallucination thật phải có response gốc và nguồn đối chiếu, không dựng claim để đạt chỉ tiêu.
Mẫu đã tạo: AI-USAGE-LOG-PB03.md, PRODUCTIVITY-PB03.md, HALLUCINATION-LOG-PB03.md và CLAIM-AUDIT-W3.md. Chưa có đủ dữ liệu để thay N/A của tuần giả lập.

## Bổ sung EX-05 do người học yêu cầu

### Token Cost — nguồn và cách thu thập
Kiểm tra usage log hoặc billing của công cụ AI cho đúng phiên/kỳ. Lưu nguồn, khoảng thời gian, tool/model, đơn vị tiền và cách tính; phân biệt chi phí API theo token với phí thuê bao/credit. Nếu có tổng chi phí thực được xác nhận cho đúng phiên thì có thể báo trực tiếp, không nhất thiết suy ngược từ token.
Nếu phải tính từ usage: cần token theo model và loại input/output/cache, đơn giá áp dụng tại thời điểm sử dụng; chi phí = tổng token từng loại/model × đơn giá tương ứng. Không lấy giá model bất kỳ hoặc chia phí thuê bao cho task khi chưa có quy tắc phân bổ được thống nhất.
Phiên hiện tại chưa có usage/billing thực được cung cấp hoặc truy xuất: ghi “Chưa có dữ liệu chi phí phiên”, không tự điền 0. Khoảng 120k trong INPUT-W3 là ước tính giả lập, không phải billing phiên thực hành.
Cho phiên tiếp theo: ghi session ID/kỳ và task ID ngay khi bắt đầu; lưu/export usage report hoặc ảnh/bản ghi billing không chứa secret; ghi model/token/giá hoặc tổng phí; đối soát cuối kỳ và ghi rõ phần chưa phân bổ. Bản ghi phải chỉ ra chi phí bao gồm/chưa bao gồm phí công cụ/thuê bao/thuế nếu có thông tin, không tự đoán.

### AI Adoption — lập inventory rồi đối chiếu bằng chứng
Tổng hợp task từ REQ, WBS, EST, RISK và WEEKLY; lập ID chuẩn và nối các nguồn để tránh một task xuất hiện ở nhiều tài liệu bị đếm nhiều lần. Yêu cầu/rủi ro không tự động là task; map chúng tới công việc cụ thể. Giữ cả task Non-AI/Unknown, không chọn riêng việc có AI.
Chốt kỳ và đơn vị task trước khi tính; tách task thực sự làm trong kỳ khỏi task kế hoạch chưa bắt đầu. Không trộn tuần W3 giả lập, kế hoạch MVP 8 tuần và phiên học 90 phút thành cùng một mẫu số.
Đối chiếu lịch sử tương tác, file thay đổi/artefact, diff/commit nếu có và bằng chứng skill/rule thực sự dùng. Không có commit không có nghĩa không dùng AI; có rule được cài cũng không chứng minh AI được dùng.
Phân loại:
- AI-assisted: có bằng chứng AI thực sự hỗ trợ task.
- Non-AI: có căn cứ task được thực hiện không dùng AI; không suy từ việc thiếu log.
- Unknown: chưa xác minh được; không tự chuyển thành Non-AI.
Ghi thêm trạng thái Planned/In progress/Done và lý do đưa vào kỳ. Với inventory đầy đủ và không còn Unknown trong tập task đủ điều kiện: Adoption = AI-assisted / (AI-assisted + Non-AI) ×100%. Mẫu số bằng 0 thì N/A.
Nếu còn Unknown: chưa báo một tỷ lệ Adoption chính xác; công khai A/N/U, việc kiểm chứng còn thiếu. Có thể báo tỷ lệ xác minh = (A+N)/(A+N+U), hoặc khoảng Adoption [A/T,(A+U)/T] khi inventory T đầy đủ, ghi rõ đây là khoảng chứ không phải số chốt. Inventory chưa đầy đủ thì không suy khoảng bao phủ toàn bộ kỳ.

## Chỉ số riêng của phiên học thực tế — không thay KPI W3
Inventory hồi cứu trong TASK-INVENTORY-PB03.md: 31 task đã/đang thực hiện có đầu ra trong hội thoại, tất cả có bằng chứng AI hỗ trợ; A=31, N=0, U=0 → Adoption phiên quan sát = 100%, chờ người học review độ bao phủ. 20 mục dự án tương lai/chưa xác minh thực thi loại khỏi mẫu số. Adoption tuần W3 giả lập tiếp tục N/A. Chỉ số này không chứng minh chất lượng, mức tự chủ AI hay năng suất tăng.

## Kết luận rà soát EX-05 do người học xác nhận
Người học yêu cầu ghi trung thực: chưa phát hiện hallucination trong báo cáo EX-05 đã rà soát; thực tế người học cũng chưa thấy trường hợp nào ở đây.
Kết luận này giới hạn ở nội dung đã kiểm, không khẳng định mọi output AI đều đúng hoặc đã kiểm toàn bộ. Không tạo claim sai giả định và không dùng lỗi UI/đổi yêu cầu thay cho hallucination số liệu.
Trạng thái tiêu chí Workbook “≥1 phát hiện hallucination thật + cách sửa”: CHƯA CÓ BẰNG CHỨNG, không đánh dấu đạt; log hiện không có trường hợp phát hiện được xác nhận. Giữ nguyên báo cáo/KPI có nguồn và N/A cho dữ liệu thiếu.
