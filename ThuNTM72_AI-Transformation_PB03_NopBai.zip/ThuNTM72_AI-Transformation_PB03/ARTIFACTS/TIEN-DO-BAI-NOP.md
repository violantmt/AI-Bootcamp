# Tiến độ bài nộp PB03 — trạng thái hiện hành KH-Refresh-1

## Đã có
- Demo v10 Tier2 người học nghiệm thu; script model đã có27testpass và browser regression, không có auth/DB production.
- EX01: REQ hiện hành/AC, ≥5 câu hỏi phân loại từ hội thoại, hard-stop trước đây đã được làm rõ, scope simulation barcode do người học viết. Review sai intent và thay yêu cầu có log; không tự tính mọi scope change là lỗi AI.
- EX02: WBS người học tách hướng dẫn/UAT, giải thích lý do; các task MVP thật vẫn Planned.
- EX03: người học chọn hoãn Excel/đề xuất8tuần; 55,2dev-MD so capacity64, chưa team/stakeholder cam kết timeline. PM sau loạiExcel12,5MD trước buffer.
- EX04:14rủi ro, Top5/mitigation/owner vai trò/trigger được người học chốt; DoD/HITL/SoD/leastprivilege/evidence. RPO/RTO và triển khai kiểm soát thật chưa có.
- EX05: báo cáo/dashboard W3 giả lập có quyết định người học; Adoption phiên quan sát31/31=100% hồi cứu, khác Adoption W3 vẫnN/A. Usage/productivity/hallucination logs có mẫu và nguồn. Người học xác nhận chưa phát hiện hallucination, không gài lỗi giả.
- EX06:20task có trách nhiệm AI/approver/gate/evidence; người học review ba task rủi ro, không cấp quyền production.
- Viva3câu viết đã có nguồn tự viết/AIgợiý được ghi rõ; người học báo90phút cho tổng phiên trước, không tự kéo dài hoặc chia EX01–06.

## Knowledge Health
- c1 10/10 trace; c2 9/9 đợt demo, không originalGitcommit; c4 0/15orphan; c6 11/11decision.
- c7 người học chấm8/8 trước lần chuẩn hóa doc, không tự công nhận vừa retest bản mới.
- c3 sau viết lại8doc/audit10doc=100%, là auditAI có archive/SHA; cần người học báo nếu còn mâu thuẫn.
- c5 vẫn7/10: API, scenario, hướng dẫn chờ review qua REVIEW-PACKET-PB03.md. Bảy trace review trước áp cho nội dung nghiệp vụ được giữ, không phải người học đã duyệt lại toàn bộ bản viết mới.

## Còn thiếu/không tự coi đạt
- Workbook EX05 yêu cầu ≥1hallucinationthật: chưa có bằng chứng, ghi trung thực.
- Chưa chốt tổng ≥3lỗiAIthật do người học sửa theo rubric; nhiều thay đổi là cải tiến/scope, AI tự phát hiện không tính thay.
- Chưa có token billing/baseline trướcAI hoặc time log từng bài; để thiếu có lý do, không tự bịa số.
- Review3artefact c5; xem lại hồ sơ version trước đóng gói bài cuối.
- Chưa có nơi nhận/hạn nộp, chưa gửi ra ngoài. UAT thủ kho thật, staging, restore, auth/DB/production không trong việc đã làm.

Bản tiến độ lịch sử giữ ở history/before-knowledge-refresh/TIEN-DO-BAI-NOP.md, không dùng các trạng thái chờ cũ làm trạng thái hiện hành.

Cập nhật PMBA-REVIEW-01: cả10artefact có trace review, c5=100%; API/scenario Changes Requested và hướng dẫn tạm ổn, không toàn bộ Approved. API vKH-Refresh-2 phân biệt mock/prod; TS15–TS21 bổ sung Not Tested, các ca tuần tự cũ chỉ partial evidence. C3 vẫn10/10fresh theo audit nội dung, không chứng minh test mới đã chạy.

Phạm vi dashboard hiện hành: chỉ Knowledge Health c1–c7. Project Health tổng quát đã loại khỏi bộ đang dùng, archive riêng và không đóng gói. Không thay đổi trạng thái các finding hoặc test còn Not Tested.
