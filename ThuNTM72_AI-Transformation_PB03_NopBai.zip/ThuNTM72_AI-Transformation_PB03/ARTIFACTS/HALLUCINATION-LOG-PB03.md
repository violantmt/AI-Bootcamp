# Hallucination Log PB03 — EX-05

Trạng thái: chưa có phát hiện hallucination thật đủ evidence trong báo cáo EX-05. Đây là log sẵn dùng, không ghi số 0 như thể đã audit hết output.

| ID | Thời điểm/kỳ | Task và prompt nguyên văn/tham chiếu | AI response nguyên văn + file/mục/phiên bản | Claim/số cần kiểm | Nguồn đối chiếu + vị trí | Kết luận kiểm chứng | Người phát hiện | Cách sửa | Kiểm lại và trạng thái |
|---|---|---|---|---|---|---|---|---|---|

## Quy tắc ghi nhận
- Giữ prompt/response gốc và phiên bản trước sửa, trích đúng claim, không chỉ ghi “AI sai”. Chỉ dùng dữ liệu giả/được phép, không chép khóa hoặc dữ liệu nhạy cảm vào log.
- Phân loại: unsupported (không có căn cứ trong nguồn), contradicted (trái nguồn), hoặc chưa xác minh. Không đồng nhất không có bằng chứng với đã chứng minh sai.
- Số không có trong nguồn/tính hợp lệ → N/A hoặc “Unverified — cần nguồn”; không thay bằng số khác tự đặt.
- Derived metric phải kèm công thức và dữ liệu đầu vào. Estimate/đề xuất đúng nhãn không tự tính là hallucination.
- Lỗi UI, code bug và thay scope lưu Decision Log/defect log; không biến chúng thành hallucination số liệu.
- Ví dụ cố ý gài sai chỉ là simulation, không tính vào phát hiện hallucination thật của Workbook.

## Các điểm kiểm cụ thể
Bug severity: input chỉ có số lượng/loại, chưa có severity; không tự gán critical/high.
AI Adoption: input không có danh sách task và AI usage; hiện N/A.
Token Cost: chỉ có khoảng 120k tổng token, chưa có model/tách token/đơn giá; hiện N/A.
Không ghi log phát hiện nếu báo cáo hiện hành đã giữ đúng các giới hạn này.

## Kết luận rà soát EX-05 do người học xác nhận
Người học yêu cầu ghi trung thực: chưa phát hiện hallucination trong báo cáo EX-05 đã rà soát; thực tế người học cũng chưa thấy trường hợp nào ở đây.
Kết luận này giới hạn ở nội dung đã kiểm, không khẳng định mọi output AI đều đúng hoặc đã kiểm toàn bộ. Không tạo claim sai giả định và không dùng lỗi UI/đổi yêu cầu thay cho hallucination số liệu.
Trạng thái tiêu chí Workbook “≥1 phát hiện hallucination thật + cách sửa”: CHƯA CÓ BẰNG CHỨNG, không đánh dấu đạt; log hiện không có trường hợp phát hiện được xác nhận. Giữ nguyên báo cáo/KPI có nguồn và N/A cho dữ liệu thiếu.
