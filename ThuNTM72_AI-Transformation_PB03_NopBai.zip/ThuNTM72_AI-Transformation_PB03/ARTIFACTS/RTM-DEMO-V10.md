# RTM demo v10 — audit Knowledge Health

Phạm vi: 10 yêu cầu quan trọng được chọn công khai cho demo hiện hành; KH01–KH10 là ID audit mới, không tự tuyên bố là toàn bộ requirement MVP production. Code/test đã có, RTM được lập trong lần chuyển dashboard này.
Trước audit chưa có RTM chốt; sau lập bảng, 10/10 có trace explicit tới WBS, code và test hiện hữu. Đây là kiểm sự tồn tại/đối chiếu nội dung bởi AI, không phải user sign-off hoặc chạy lại test. Production/phase sau không nằm trong mẫu số.

| ID | Requirement | WBS | Code | Test | Tài liệu |
|---|---|---|---|---|---|
| KH01 | Phân quyền hai role, Quản lý không lập phiếu nhập | 1.3/1.4 | ../CODEBASE/prototype/model.mjs: api; ../CODEBASE/prototype/app.mjs: controls | Chưa xác thực mock và role quản lý không được ghi | API-PB03.md;REQ-PB03.md |
| KH02 | Chỉ Quản lý tạo/sửa danh mục | 1.3 | ../CODEBASE/prototype/model.mjs: /api/products, /api/products/manage | Chỉ quản lý tạo mã, tồn 0, có audit; mã trùng/thiếu field bị chặn | API-PB03.md |
| KH03 | Xóa khi tồn 0, còn tồn chặn; giữ lịch sử | 1.3 | ../CODEBASE/prototype/model.mjs: manage/delete; deletedProducts | Giảm Bút về 0 rồi xóa thành công dù có lịch sử; giữ lịch sử sau xóa và sau reload | REQ-PB03.md;API-PB03.md |
| KH04 | Số lượng nguyên >0, lỗi chỉ rõ dòng | 1.4 | ../CODEBASE/prototype/model.mjs: validate | Bút trống và Sổ 10: xác định đúng dòng Bút, không thay đổi tồn | REQ-PB03.md;TEST-SCENARIOS-PB03.md |
| KH05 | Không trùng hàng trên phiếu; mock chặn trùng | 1.4 | ../CODEBASE/prototype/app.mjs: controls/renderDraft; model api | Phiếu trùng bị chặn ở mock, giữ nguyên tồn | REQ-PB03.md |
| KH06 | Phiếu nhiều dòng nguyên tử, không cập nhật một phần | 1.4 | ../CODEBASE/prototype/model.mjs: validate trước structuredClone/update | Phiếu nhiều dòng lỗi: không cập nhật phần hợp lệ | REQ-PB03.md |
| KH07 | Thủ kho đề nghị giảm có lý do, chưa đổi tồn | 1.5 | ../CODEBASE/prototype/model.mjs: /api/adjustments | Đề nghị sai hoặc thiếu lý do/quyền bị chặn | API-PB03.md |
| KH08 | Quản lý duyệt/từ chối, kiểm tồn lại, duyệt một lần | 1.5 | ../CODEBASE/prototype/model.mjs: /api/adjustments/review | Đề nghị không đổi tồn; chỉ quản lý duyệt, trừ đúng một lần | API-PB03.md;DOD-PB03.md |
| KH09 | Lưu phiếu/tồn cục bộ, tải lại giữ dữ liệu | 1.4/1.5 | ../CODEBASE/prototype/app.mjs: localStorage load/setItem | Dữ liệu phiếu và tồn roundtrip qua JSON như lưu trình duyệt | BAT-DAU-DEMO.md |
| KH10 | Thông báo xóa/tạo/duyệt tại đúng mục và đúng kết quả | 1.3–1.7 | ../CODEBASE/prototype/app.mjs: createFeedback, catalogFeedback, commit notify | ../CODEBASE/prototype/test_browser.py: #catalogMessage/#createMessage/#reviewMessage assertions | REQ-PB03.md;TEST-SCENARIOS-PB03.md |

## Module documentation inventory cho c4
| Module trong demo | Code | Doc hiện có | Có thiếu doc? |
|---|---|---|---|
| Danh mục | model /products/manage | API-PB03.md + KH02/KH03 | Không |
| Phiếu nhập | model /receipts | API-PB03.md + KH04–KH06 | Không |
| Điều chỉnh | model /adjustments/review | API-PB03.md + KH07/KH08 | Không |
| Lưu cục bộ | app localStorage | BAT-DAU-DEMO.md + KH09 | Không |
| UI theo role/phản hồi | app controls/notify | REQ-PB03.md + KH01/KH10 | Không |

c4: 0 requirement thiếu code/test + 0 module thiếu doc / (10+5) = 0%. Có doc không có nghĩa doc còn fresh: c3 đo riêng sự nhất quán. Không dùng 0% orphan để che mâu thuẫn tài liệu.
