# Review packet — cải thiện c5, bản KH-Refresh-1

Mục tiêu: người học kiểm ba artefact còn thiếu trace review trực tiếp. Bản tóm tắt dưới đây giúp non-coder đọc; muốn xem đầy đủ bấm file tương ứng. Không coi yêu cầu “làm tốt c5” hoặc AI tự kiểm là approval của người học.
Ngày và version tài liệu: KH-Refresh-1, 31/10/2026. Scope: demo v10, không cấp quyền production.

## 1. API-PB03.md — Quyền và kết quả thao tác
- Thủ kho được nhập phiếu/gửi đề nghị giảm; Quản lý quản lý danh mục và duyệt, không lập phiếu nhập.
- Xóa hàng tồn0 được phép dù có lịch sử; phiếu/lịch sử giữ nguyên, còn tồn báo rõ và chặn.
- Đề nghị chờ chưa đổi tồn; Quản lý duyệt mới giảm, từ chối không đổi; không xử lý lại request đã duyệt/từ chối.
- Đây là API giả lập trong trình duyệt, không auth/DB thật; SoD hai danh tính chưa được chứng minh.
Người học cần xác nhận hoặc sửa: các quy tắc này có đúng với demo/nghiệp vụ bạn đã chọn không? Chưa cần hiểu syntax endpoint.
Nguồn đầy đủ: API-PB03.md. Review kết quả: PMBA-REVIEW-01 — Changes Requested, bản tóm tắt đã có review; bản KH-Refresh-2 cập nhật limitation, chưa Approved.

## 2. TEST-SCENARIOS-PB03.md — Có kiểm trường hợp sai và quyền
- Có scenario nhập đúng, -3/0/số lẻ, một dòng sai không lưu một phần; không trùng hàng.
- Có scenario xóa còn tồn bị chặn, tồn0 xóa được và giữ lịch sử, Hủy không xóa.
- Có scenario gửi giảm tồn chưa đổi, duyệt một lần/không âm, từ chối cần lý do và không đổi tồn.
- Có kiểm role/UI, thông báo đúng mục và tải lại giữ dữ liệu; lỗi quota/SoD/DB thật chưa kiểm đủ được ghi chưa kiểm, không giả PASS.
Người học cần xác nhận hoặc sửa: scenario đã bao phủ các lỗi bạn trực tiếp gặp và điểm nào còn thiếu?
Nguồn đầy đủ: TEST-SCENARIOS-PB03.md; scripts ../CODEBASE/prototype/test.mjs, ../CODEBASE/prototype/test_browser.py. Review kết quả: PMBA-REVIEW-01 — Changes Requested; đã bổ sung TS15–TS21, ca mở rộng Not Tested, chưa Approved.

## 3. BAT-DAU-DEMO.md — Hướng dẫn có làm theo được không
- Mở ../CODEBASE/prototype/MO-DEMO.html, chọn role; lưu ý dữ liệu cục bộ theo file/trình duyệt.
- Hướng dẫn tạo mã/nhập phiếu, bỏ dòng trống, sửa/xóa theo tồn, gửi đề nghị và đổi role duyệt/từ chối.
- Nêu đúng vị trí thông báo, không còn hướng dẫn dùng nút gộp/ngừng sử dụng; người dùng được cảnh báo không dùng dữ liệu thật và không xóa bằng chứng cũ.
- Có cách nhờ hỗ trợ chạy local server khi trình duyệt chặn mở file; không tuyên bố đã có bảo mật production.
Người học cần xác nhận hoặc sửa: với trải nghiệm vừa dùng demo, hướng dẫn có rõ và đúng các bước không?
Nguồn đầy đủ: BAT-DAU-DEMO.md. Review kết quả: người học nhận xét “tạm ổn” — reviewed provisional, không blanket approval.

## Cách gửi review
Có thể trả lời:
1. API: đồng ý / cần sửa ...
2. Test scenario: đồng ý / còn thiếu ...
3. Hướng dẫn: đồng ý / khó hiểu chỗ ...
Ý kiến phản biện cũng là review evidence, không bắt buộc phải đồng ý. Chỉ cập nhật c5 sau khi ghi người review, ý kiến, scope/version và nguồn hội thoại. Reviewer đọc bản tóm tắt phải được ghi là review bản tóm tắt nội dung, không bịa đã đọc mọi dòng kỹ thuật.

## Trạng thái hiện hành sau review PM/BA
API và scenario đã có phản biện cụ thể của người học, không phê duyệt hoàn toàn. Hướng dẫn vẫn Pending, người học chưa nêu ý kiến riêng. Chi tiết finding/evidence: knowledge-health/REVIEW-FINDINGS.md và HUMAN-REVIEW-RECORD.json. Không yêu cầu đồng ý để tăng c5; phản biện có căn cứ cũng là review evidence.

Cập nhật tiếp theo: hướng dẫn đã được người học review “tạm ổn”, thay trạng thái Pending trước đó. Cả ba có trace review; API/scenario vẫn Changes Requested. c5 đủ trace không đồng nghĩa được release hoặc các finding đã đóng.
