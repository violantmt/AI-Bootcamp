# RISK-PB03 — Risk Register hiện hành

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Phạm vi và cách đọc
Kế hoạch MVP thật đề xuất 8 tuần, Excel phase sau; demo v10 đã nghiệm thu nhưng chưa có auth/DB production. L/I thang1–5 là AI giả định để ưu tiên, score=L×I, không phải xác suất đo. Owner là vai trò dự kiến, chưa có người thật được giao. Các cổng production chưa được kiểm chứng.

| ID | Nhóm | Rủi ro | L | I | L×I | Giảm thiểu cụ thể | Owner dự kiến | Trigger | AI được tới đâu | Cổng chặn |
|---|---|---|---:|---:|---:|---|---|---|---|---|
| R01 | Tiến độ | Effort AI thấp hơn khả năng thực tế của team | 4 | 4 | 16 | Team review 3-point trước chốt lịch; cập nhật estimate khi task vượt biên M, không cắt gate | PM + dev | Trước cam kết; task vượt M | L2 | Estimate cần người chọn, không tự cam kết |
| R10 | Chất lượng | Không có QA riêng nên bỏ sót negative/boundary cases | 4 | 4 | 16 | Phân công dev review chéo, checklist AC-role, dành effort test riêng E10; không bỏ test lỗi để xanh | Dev lead | Trước nghiệm thu và mỗi thay rule | L3 draft test | Gate fail-closed: test thiếu/đỏ thì chưa đạt |
| R11 | AI | AI viết code/tài liệu hoặc báo cáo test sai, người dùng tin ngay | 4 | 4 | 16 | Map AC→test/code, chạy script thật, ghi log exit/count; người đọc kết quả và spot-check chức năng | Người điều phối + dev | Mỗi output AI quan trọng | L1/L2 tài liệu, L3 sandbox | Không evidence hoặc không pass thì chặn, không tự approve |
| R03 | Dữ liệu | Hai giao dịch đồng thời làm tồn âm hoặc lệch lịch sử | 3 | 5 | 15 | Transaction/khóa hoặc cập nhật có điều kiện; test hai yêu cầu cạnh tranh và kiểm đối soát | Dev backend | Mỗi đổi logic stock | L3 nháp; A+ khi áp vào hệ thật | Test atomic/concurrency bắt buộc pass và người review |
| R04 | Quyền | Thủ kho tự duyệt hoặc gọi API sửa tồn trái quyền | 3 | 5 | 15 | Kiểm role ở backend thật, negative test mọi endpoint; role selector demo không đủ | Dev backend | Mọi thay đổi quyền/API | L1 thiết kế; A+ áp dụng | Người duyệt quyền + test 401/403, fail thì chặn |
| R05 | Điều chỉnh | Duyệt lặp hoặc hai đề nghị cùng làm giảm quá tồn | 3 | 5 | 15 | Duyệt pending một lần trong transaction, kiểm lại tồn tại thời điểm duyệt; thử duyệt lặp/cạnh tranh | Dev backend | Mỗi thay đổi flow duyệt | L3 sandbox; A+ hệ thật | Test đúng một lần/không âm + human review |
| R08 | Vận hành | Mất dữ liệu do chưa có backup/phục hồi kiểm chứng | 3 | 5 | 15 | Thiết lập backup bản thật và diễn tập restore trên môi trường riêng, đối soát dữ liệu phục hồi | Dev vận hành | Trước phát hành; diễn tập không đạt | L1 nháp; A+ chạy thật | Chưa restore thử đạt thì chưa phát hành |
| R12 | AI/Dữ liệu | Dữ liệu nội bộ/khóa bị đưa vào prompt hoặc demo | 3 | 5 | 15 | Chỉ dùng dữ liệu giả; kiểm file trước gửi/đóng gói, dùng cấu hình bảo mật được cho phép cho hệ thật | Người điều phối | Trước mọi upload/integration | L0 đối với dữ liệu thật ngoài phạm vi | Thiếu quyền hoặc phát hiện secret thì dừng, không gửi |
| R02 | Phụ thuộc | Đủ MD nhưng task tuần tự/chờ hạ tầng làm lỡ 8 tuần | 3 | 4 | 12 | Gán owner/duration, lập dependency và critical path; xác nhận quyền/môi trường trước build thật | PM | Trước baseline; prerequisite chưa sẵn | L2 | Chưa xác minh đường găng thì không xác nhận lịch |
| R06 | Tồn đầu kỳ | Dữ liệu Excel sai hoặc chưa thống nhất cách mở sổ | 3 | 4 | 12 | Stakeholder chốt dữ liệu và phương án import/phiếu mở đầu; đối soát có ký nhận trước nạp | PM + Quản lý kho | Trước nạp dữ liệu thật | L1/L2; A+ dữ liệu thật | Không nạp khi thiếu nguồn/đối soát/duyệt |
| R07 | Lịch sử | Xóa mã hàng mất truy vết hoặc tái dùng mã gây nhầm | 3 | 4 | 12 | Xóa nghiệp vụ bằng tombstone, giữ mã/phiếu/audit; test stock0/xóa/reload và không dùng lại mã | Dev backend | Mỗi thay đổi xóa/danh mục | L3 sandbox; A+ hệ thật | Test lịch sử + quyền + review schema |
| R09 | Người dùng | UI báo kết quả xa mục thao tác làm thao tác nhầm/lặp | 4 | 3 | 12 | Phản hồi thành công/lỗi tại chỗ, nêu mã/diễn biến tồn; cho thủ kho UAT theo kịch bản | PM + dev UI | UAT phát hiện không biết thao tác đã xong | L3 demo | UAT người dùng đạt; không thay bằng test AI |
| R13 | Scope | Barcode/Excel hoặc yêu cầu mới quay vào MVP làm vượt effort | 4 | 3 | 12 | Change request ghi tác động REQ/WBS/estimate, chỉ đưa vào khi stakeholder chốt trade-off | PM | Mỗi yêu cầu mới | L2 | Không tự tăng scope hoặc cam kết mốc |
| R14 | AI/Quản trị | Có file đẹp nhưng review người học chỉ là hình thức | 3 | 4 | 12 | Giữ dấu vết phản biện, phân biệt AI gợi ý và người viết; viva và UAT thật, không dựng lỗi/telemetry | Người điều phối | Chốt bài/duyệt artefact | L1/L2 | Thiếu bằng chứng hiểu thì chưa đánh dấu đạt |

## Top-5 người học đã chọn (duy nhất hiện hành)
| Ưu tiên | ID | Kiểm soát bổ sung | Owner | Trigger |
|---|---|---|---|---|
| 1 | R03 | DB transaction/locking và concurrency testing | Dev backend | Đổi logic stock, tranh chấp lỗi |
| 2 | R04 | RBAC tại API, negative tests, SoD, requester không tự duyệt | Dev backend/reviewer | Đổi role/API, lọt truy cập trái quyền |
| 3 | R05 | Idempotency, pending xử lý một lần trong transaction, kiểm tồn lại | Dev backend | Request lặp/đồng thời, trừ lặp |
| 4 | R11 | Dev review, automated tests và evidence; hai dev review chéo | Dev reviewer/người điều phối | Output AI mới hoặc thiếu report |
| 5 | R08 | Backup định kỳ, restore drill và RPO/RTO được chủ nghiệp vụ chốt | Vận hành/Quản lý kho | Backup/restore fail hoặc trước triển khai |
Các rủi ro tiến độ/nguồn lực vẫn theo dõi hằng tuần, không thay Top5. Điểm cao hơn chưa đồng nghĩa được người học chọn cao hơn; ưu tiên theo hậu quả nghiệp vụ.
RPO là mức mất dữ liệu chấp nhận theo thời gian; RTO là thời gian phục hồi chấp nhận. Chưa chốt số, không tự điền. Review register hằng tuần và khi đổi scope, role, schema hoặc finding nghiêm trọng.

## Gate và trạng thái
AI tự kiểm chưa đủ: người học yêu cầu code review cho tồn/transaction/quyền, unit/integration thật (invalid/concurrency/unauthorized), review chéo hai dev, UAT thủ kho và report/log/CI nếu có. DoD ghi cổng chưa chạy/không evidence không được đạt.
Migration cần DBA review, staging và backup/restore/rollback; release cần Release Owner, DoD/test quan trọng đạt và rollback. Least privilege, HITL, evidence-based approval. Role selector demo không chứng minh SoD hai người thật. Không có production access được cấp qua bài học này.
Nguồn review: EX04-R01/D02, EX06-D01 trong Decision Log. Cần gán người cụ thể và evidence trước triển khai thật; việc ghi mitigation không chứng minh đã thực thi.
