# WBS-PB03 — Phân rã công việc

Bản hiện hành KH-Refresh-1 · 31/10/2026 · phạm vi demo v10 và kế hoạch được phân biệt bên dưới. Bản trước: history/before-knowledge-refresh/.

## Quy tắc kế hoạch
Đội giả định 1 PM +2 dev. Mốc gốc brief 6 tuần; người học chọn đề xuất 8 tuần, giữ quality/permission/không âm, hoãn Excel. Chưa có baseline stakeholder duyệt, lịch nghỉ/duration/critical path hoặc team xác nhận effort. Demo Tier 2 đã có; các task production dưới đây mới là backlog.

## Wave 1 — Công việc thực hành/demo đã thực hiện
| ID | Task / pha SDLC | Đầu ra / trạng thái | Phụ thuộc |
|---|---|---|---|
| 1.1 | Chốt scope/role/AC — Analysis | REQ hiện hành, quyết định qua review người học | — |
| 1.2 | Thiết kế API mock/schema — Design | API-PB03.md, schema SQL tham khảo; không DB thật | 1.1 |
| 1.3 | Danh mục/role/feedback — Code | Demo tạo/sửa/xóa, UI theo role, phản hồi tại chỗ | 1.2 |
| 1.4 | Nhập phiếu/tồn/lịch sử — Code | Không trùng/số lượng nguyên/không lưu một phần/localStorage | 1.2, 1.3 |
| 1.5 | Đề nghị giảm tồn và duyệt/từ chối — Code | Kiểm role/tồn/trạng thái, giữ lịch sử | 1.2, 1.3 |
| 1.6 | Test — Test | Script logic 27 test và browser regression demo; production chưa kiểm | 1.3–1.5 |
| 1.7 | UAT người học — UAT | Người học thử nhiều vòng và nghiệm thu demo v10; không phải UAT thủ kho thật | 1.6 |
| 1.8 | Hồ sơ và metrics — Documentation | Log/viva/90 phút đã ghi; RTM và audit knowledge bổ sung, còn review artefact đang chờ | 1.7 |

## Wave 2 — Kế hoạch MVP thật, chưa thực thi
| ID | Task/feature và SDLC | Đầu ra cần có | Phụ thuộc |
|---|---|---|---|
| 2.1 | Backend/DB/auth/role/audit — Design/Code | Theo stack brief, quyền thật, DB thật, migration có kiểm soát | 1.1, 1.2 |
| 2.2 | Xác minh tồn đầu kỳ — Analysis/Data | Chủ dữ liệu chốt phiếu mở đầu hoặc import; không tự thêm import Excel | 1.1 |
| 2.3 | Phiếu xuất — Design/Code/Test | Không xuất âm, transaction/concurrency có test | 2.1 |
| 2.4 | Điều chỉnh tăng/giảm gắn phiếu gốc — Design/Code/Test | Không sửa phiếu gốc, phê duyệt có định danh/audit | 2.1, 1.5 |
| 2.5 | Tra tồn/lịch sử/cảnh báo tối thiểu — Code/Test | Dữ liệu production, cảnh báo chưa có ở demo | 2.1 |
| 2.6a | Báo cáo nhập–xuất–tồn theo kỳ — Code/Test | Quyền xem và đối soát | 2.3, 2.4, 2.5 |
| 2.6b | Xuất Excel — Code/Test | Hoãn phase sau, không tính capacity MVP hiện tại | 2.6a |
| 2.7 | Độ tin cậy — Test/Operations | Integration/security/concurrency/load, backup/restore kiểm chứng | 2.1, 2.3, 2.4, 2.6a |
| 2.8 | Runbook/chuẩn bị triển khai — Operations | Quyền hạ tầng và vận hành được xác nhận | 2.7 |
| 2.9 | Hướng dẫn ngắn cho thủ kho — Documentation/Training | Nhập/xuất/tra tồn/điều chỉnh theo chức năng đã thực hiện | 2.3, 2.4, 2.5 |
| 2.10 | UAT thủ kho thật — UAT | Kịch bản, kết quả và phản hồi thực tế | 2.7, 2.9 |
| 2.11 | Xử lý feedback và release — Rework/Test/Release | Sửa/rerun, DoD đạt, Release Owner duyệt trước production | 2.8, 2.10 |
Wave3 ngoài MVP: barcode, nhiều kho, kế toán, dự báo; chỉ thêm khi có trade-off mới được chọn.

## Review và trace
Người học tách rõ 2.9/2.10 từ task gộp: hướng dẫn giúp làm quen/giảm sai; UAT kiểm quy trình thực và thu phản hồi. AI bổ sung 2.11 để đóng feedback, không giả thêm một quyết định người học. EST E01–E14 ước lượng phần MVP thật; không coi demo đã có là production xong. Lịch dependency ở bảng chỉ quan hệ trước/sau, chưa phải critical path đã tính.
