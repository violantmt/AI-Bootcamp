# AI Usage Log PB03 — EX-05

## Phạm vi và cách tính
Mỗi kỳ cần danh sách đầy đủ task thuộc cùng phạm vi, gồm cả task KHÔNG dùng AI và chưa xác minh. Chọn đơn vị task/tiêu chí tính trước kỳ; không tách nhỏ riêng task có AI để làm đẹp tỷ lệ.
Quy ước đề xuất: task được thực hiện trong kỳ; một task chỉ đếm một lần theo ID dù có nhiều prompt/model/commit. Dùng AI = AI thực sự tham gia viết/review/thiết kế/test cho task và có dấu vết. Chỉ có rules/skill được cài không chứng minh AI đã được dùng.
AI Adoption = số task xác nhận có AI / tổng task trong kỳ × 100%. Chưa có đầy đủ danh sách hoặc còn unknown có thể ảnh hưởng tử số thì báo N/A/Unverified, không suy 100% từ các task được chọn kể lại. Nếu tổng task=0 thì N/A, không chia 0.
Phân biệt kỳ thực hành PB03 và tuần 3 giả lập: không dùng log thực hành để tự điền Adoption cho INPUT-W3.md.

## Log task (mẫu sẵn dùng)
| Task ID | Kỳ/phạm vi | Task/đầu ra | Phân loại AI-assisted/Non-AI/Unknown | Vai trò AI và tool/model | Prompt/response tham chiếu | Diff/commit/artefact tham chiếu | Skill/rule thực sự dùng và evidence | Kết quả review người | Trạng thái dữ liệu |
|---|---|---|---|---|---|---|---|---|---|
| PB03-UI-REVIEW-MSG | Phiên thực hành PB03, không phải tuần W3 giả lập | Chuyển phản hồi duyệt/từ chối về dưới lịch sử giảm tồn | AI-assisted | Codex sửa UI và kiểm Chromium; model chưa xác minh | Hội thoại người học yêu cầu chuyển thông báo dưới Đề nghị và lịch sử giảm tồn; AI báo bản v10 | ../CODEBASE/prototype/app.mjs, ../CODEBASE/prototype/index.html, ../CODEBASE/prototype/test_browser.py; gói demo v10. Không có commit/diff độc lập được cung cấp | Chưa xác minh skill/rule riêng cho task; không tự gán onboarding skill cho code UI | Người học xác nhận demo ổn sau v10 | Tái dựng từ hội thoại/artefact sau phiên, không phải time log tại thời điểm làm |

Đây là một dòng có evidence, KHÔNG phải danh sách đủ task của kỳ. Chưa tính Adoption từ một dòng này. Những task không dùng AI cần ghi Không và căn cứ tương ứng; không bịa để tạo mẫu số.
90 phút là tổng thời gian phiên người học đã báo, không gán toàn bộ cho dòng trên hoặc tự chia cho các task.

## Quy tắc bổ sung
Inventory lấy từ REQ/WBS/EST/RISK/WEEKLY, gộp theo task ID, phân loại AI-assisted/Non-AI/Unknown, tách task kế hoạch khỏi task trong kỳ. Chi tiết tại EX05-DATA-COLLECTION.md.

## Inventory đối soát hiện hành
Bản một dòng phía trên là log mẫu cũ. Đã tổng hợp inventory chuẩn ở TASK-INVENTORY-PB03.md/.csv, gộp dòng mẫu vào A12.
Phạm vi quan sát phiên học: 31 task thực hiện/có đầu ra, 31 AI-assisted, 0 Non-AI có bằng chứng, 0 Unknown trong tập đủ điều kiện; Adoption hồi cứu = 100%. 20 mục kế hoạch/chưa thực hiện được xác minh được tách riêng, không tính mẫu số. Không chuyển kết quả sang tuần W3 giả lập; độ bao phủ phiên ngoài hội thoại chưa biết.
