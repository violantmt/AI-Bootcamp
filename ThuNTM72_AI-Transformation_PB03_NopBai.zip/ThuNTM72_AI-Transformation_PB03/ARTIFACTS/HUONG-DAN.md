# Lộ trình học PB03 — tài liệu tham khảo quá trình

Đây là lộ trình thực hành ban đầu, không phải trạng thái nghiệm thu mới nhất. Xem TIEN-DO-BAI-NOP.md, API/REQ hiện hành và README-NOP-BAI.md để biết kết quả/giới hạn hiện tại.

# Lộ trình học và chuẩn bị bài nộp PB-03

Trạng thái: bắt đầu học; chưa hoàn thành, chưa nộp.
Nguồn: AI Transformation v3.0, START-HERE, Program §6–7, Workbook, Build Playbook.
Đề khởi đầu đề xuất: PB-03 — quản lý kho. Có thể thay bằng dự án thật.

## Buổi chính 3 giờ
1. 0–30 phút: xác nhận công cụ hoạt động; viết “Tôi ở cấp AI Maturity ... vì ...”. Hiểu L1 = AI nháp/người duyệt, L2 = AI đề xuất/người chọn, L3 = làm trong giới hạn, L4 = vận hành luồng có cổng; chưa cấp L5. A = việc thông thường, A+ = việc rủi ro cần người duyệt.
2. 30–60 phút: đọc REQ-PB03.md, phản biện bằng lời của mình. AI tự review; bạn phân loại ≥5 câu hỏi thành [Hỏi stakeholder] hoặc [AI tự sai] khi thực sự có lỗi. Sửa ≥1 điểm sai intent nếu phát hiện; giữ ≥1 hard-stop hợp lý. Không tạo lỗi giả để đủ chỉ tiêu.
3. 60–75 phút: simulation: “Kho muốn thêm quét barcode từ điện thoại ngay trong MVP”. Bạn viết phản hồi ≤5 dòng: tác động, phương án thay thế, phần hoãn lại. Không mặc định barcode bắt buộc cần app riêng/hardware mới: cần khảo sát phương án camera web và chi phí trước.
4. 75–90 phút: AI lập DELEGATION-MAP-PB03.md ≥8 task, mỗi task có nhóm 5-loại, L0–L5, A/A+, ai duyệt, lý do. Bạn phản biện task phân quyền/điều chỉnh tồn; cố ý giữ ≥1 task ở L1/L2 và giải thích.
5. 90–100 phút: nghỉ.
6. 100–115 phút: chốt DOR-PB03.md và kế hoạch build. Luồng gợi ý: nhập phiếu → kiểm tra → lưu → xem tồn và lịch sử. Tier 1: React/Vue + Spring Boot/.NET + PostgreSQL/MySQL; Tier 2: prototype tương tác + API mock + schema SQL + test scenario và script. Chọn theo nền tảng của bạn.
7. 115–145 phút: build sau khi phạm vi và kế hoạch được bạn chốt. Ghi lỗi AI và phản biện thật vào Decision Log ngay khi xảy ra.
8. 145–160 phút: chạy gate theo AC, gồm ca hợp lệ, số lượng không hợp lệ, lỗi giữa chừng, quyền truy cập. Ghi PASS/FAIL/CHƯA CHẠY tách biệt. Test đỏ hoặc chưa xác minh thì chưa đạt.
9. 160–180 phút: demo trực tiếp; hoàn thiện telemetry; trả lời 3 câu viva: AI sai gì và bắt bằng cách nào? Vì sao L3/L4? Cổng nào gác và khi đỏ thì sao?

## Hồ sơ nộp buổi chính
- REQ-PB03.md: đã được bạn review; câu hỏi làm rõ, hard-stop, phản hồi scope và lý do.
- DELEGATION-MAP-PB03.md: ≥8 task cho bản rút gọn.
- DOR-PB03.md: phạm vi, API/data/AC, ranh giới, gate, kế hoạch đã chốt.
- Sản phẩm chạy + hướng dẫn chạy. Tier 2 thêm API mock, schema SQL, scenario/script test.
- Bằng chứng gate/test và demo; không chỉ ảnh chụp/slide.
- DECISION-LOG-PB03.md: ≥3 lỗi AI thật được bạn phát hiện/sửa.
- TELEMETRY-PB03.md: tool, token est, giờ thật, vòng lặp, rework, Human-edit.
- Câu trả lời viva bằng lời của bạn.

## Học tiếp đầy đủ
EX-02: WBS ≥2 cấp, dependency, pha SDLC; ≥2 việc bạn thêm/bớt và lý do.
EX-03: estimate 3-point, giả định, buffer; so capacity 3 người/6 tuần theo vai trò thực tế. Nếu vượt: cắt scope, sửa REQ/WBS và nộp TRADEOFF có diff v1→v2. Không dùng mốc 8 tuần của LMS cho PB03.
EX-04: ≥10 rủi ro L×I, mitigation, owner, top-5; rủi ro AI có mức ủy quyền và cổng.
EX-05: WEEKLY-W3 ≤1 trang, dashboard ≥5 KPI có công thức/nguồn, quyết định của bạn. Thiếu dữ liệu ghi N/A. Chỉ ghi hallucination thật nếu phát hiện; không cố bịa số để rồi bắt lỗi.
EX-06 bản đầy đủ: ≥15 task, lấy từ WBS và Risk.
Build Playbook đầy đủ bổ sung SCOPE, SPEC, MODULEMAP, ARCH, RTM và các cổng hiểu.
Mọi bài có telemetry riêng.

## Nộp ở đâu
Bộ tài liệu không chỉ rõ cổng nộp, người nhận hoặc hạn nộp. Sau khi hoàn thiện, đóng gói hồ sơ và xác nhận nơi nhận theo hướng dẫn người tổ chức. Chưa có bằng chứng gửi thành công thì không ghi “đã nộp”.
