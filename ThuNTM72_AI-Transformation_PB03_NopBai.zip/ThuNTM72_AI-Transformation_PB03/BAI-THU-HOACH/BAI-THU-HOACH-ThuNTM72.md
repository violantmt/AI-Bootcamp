# BÀI THU HOẠCH — AI TRANSFORMATION

Người thực hiện: ThuNTM72
Dự án: PB-03 — Quản lý kho văn phòng phẩm nội bộ
Mức thực hành: Tier 2 — prototype tương tác, API mock, schema tham khảo và kiểm thử

Ghi chú tác giả: Bản thảo do AI hỗ trợ tổng hợp từ hội thoại, các phản biện và quyết định của người học; cần ThuNTM72 đọc, chỉnh và xác nhận trước khi nộp. Những đoạn viết ở ngôi “tôi” là bản diễn đạt đề xuất cho trải nghiệm đã có dấu vết, không chứng minh đã bảo vệ miệng hoặc tự viết code.

## 1. Bài toán và mục tiêu dự án

Tôi chưa từng viết code nên chọn PB-03, một bài toán nghiệp vụ dễ hình dung: quản lý bút và sổ trong kho văn phòng phẩm. Khi ghi chép thủ công, người dùng có thể nhập sai, không biết tồn hiện tại hoặc không rõ ai đã điều chỉnh số lượng. Mục tiêu của tôi là điều phối AI tạo một luồng có thể dùng thử: nhập hàng, lưu phiếu, xem tồn và tra cứu lịch sử; sau đó bổ sung danh mục và đề nghị giảm tồn có người duyệt.

Tôi chọn Tier 2 thay vì cố trình bày một hệ thống production mà mình chưa kiểm chứng. Sản phẩm là HTML/JavaScript tương tác, API giả lập trong trình duyệt, dữ liệu localStorage, schema SQL tham khảo và script test. Kho ban đầu có 10 cây bút và 20 quyển sổ, hoàn toàn là dữ liệu giả. Backend thật, database transaction, xác thực người dùng và vận hành nhiều người không nằm trong kết quả đã triển khai.

Mục tiêu học của tôi không chỉ là có một màn hình chạy được. Tôi cần biết đặt giới hạn cho AI, kiểm kết quả theo quy tắc nghiệp vụ, phát hiện điểm chưa hợp lý và giữ bằng chứng quyết định. Tình huống quen thuộc giúp tôi tập trung vào các năng lực này thay vì bị cuốn vào công nghệ.

## 2. Tôi sử dụng AI như thế nào

Tôi dùng Codex để đọc tài liệu, đề xuất phạm vi, soạn yêu cầu, thiết kế mock API/schema, viết code và test, rồi tổng hợp hồ sơ. Tôi cung cấp ý kiến nghiệp vụ, thử demo, phản hồi và lựa chọn phương án. AI làm phần kỹ thuật, nhưng không được dùng lời “đã xong” của chính mình để thay việc nghiệm thu của tôi.

Quá trình bắt đầu từ REQ và Delegation Map, chốt điều kiện build, dựng prototype, chạy test, thử lại và ghi Decision Log. Tôi không yêu cầu toàn bộ MVP ngay từ đầu: luồng đầu là nhập phiếu rồi xem tồn; các chức năng khác được thêm khi tôi đã hiểu và thấy nhu cầu cụ thể. Khi chuyển sang các bài lập kế hoạch, AI hỗ trợ WBS, estimate 3-point, trade-off, Risk Register, weekly report và các KPI.

AI Adoption hồi cứu được tính trên 31 task có bằng chứng trong phiên quan sát: 31 task có AI hỗ trợ, tương ứng 100%. Đây không phải tỷ lệ công việc do AI tự làm, không đại diện doanh nghiệp hoặc tuần W3 giả lập. Tôi vẫn quyết định và kiểm kết quả; những task production mới nằm trong kế hoạch không được tính là đã thực hiện. Việc tạo video và đóng gói sau inventory chưa được tự cộng vào mẫu số 31.

## 3. Những quyết định quan trọng và cách tôi suy nghĩ

### 3.1. Người đề nghị không tự quyết thay đổi tồn

Tôi chọn Thủ kho gửi đề nghị giảm tồn và Quản lý duyệt. Gửi đề nghị không làm tồn đổi ngay. Tôi muốn có số lượng, lý do và lịch sử để kiểm tra, vì điều chỉnh tồn ảnh hưởng tài sản. Về thiết kế thật, tôi bổ sung RBAC, phân tách nhiệm vụ, audit log và yêu cầu người tạo không tự duyệt.

Tôi cũng nhận ra đổi role trên màn hình demo không chứng minh có hai người dùng thật. Một người có thể chọn cả hai role, vì vậy SoD thật còn cần đăng nhập và định danh độc lập. Việc nói rõ giới hạn này giúp tôi không đánh đồng một demo hợp lý với hệ thống bảo mật đã đạt yêu cầu.

### 3.2. Ngăn lỗi nhập từ đầu thay vì sửa sau

Ban đầu tôi đề nghị có nút tự động gộp khi một mã hàng xuất hiện hai dòng. Sau khi dùng, tôi chọn cách đơn giản hơn: chỉ cho chọn hàng chưa có trên phiếu. Tôi thấy ngăn trùng ngay từ đầu dễ hiểu hơn việc cho nhập trùng rồi bắt gộp. AI đã sửa UI và vẫn giữ kiểm tra trùng ở logic mock.

Đây là thay đổi lựa chọn UX của tôi, không phải bằng chứng chức năng gộp đã làm sai dữ liệu. Tôi học cách phân biệt cải tiến, mở rộng phạm vi và lỗi để Decision Log không biến mọi yêu cầu thành thành tích “bắt lỗi AI”.

### 3.3. Xóa hàng theo tồn nhưng giữ lịch sử

Tôi từng thử giảm Bút về tồn 0 nhưng Quản lý vẫn không xóa được do quy tắc cũ chặn mã đã có giao dịch. Sau trao đổi, tôi yêu cầu cho xóa khỏi danh mục khi tồn bằng 0, kể cả có lịch sử, nhưng phải giữ phiếu và dấu vết điều chỉnh. Khi còn tồn, hệ thống phải chặn và nêu rõ số lượng còn lại.

Tôi không chỉ kiểm việc dữ liệu biến mất. Tôi còn yêu cầu thông báo thành công hoặc lý do thất bại xuất hiện ngay dưới mục đang thao tác, có mã và tên hàng. Tôi cũng yêu cầu rút gọn mục quản lý còn hai nút sửa/xóa, vì nhiều nút làm người mới bối rối. Những quyết định này xuất phát từ khả năng người dùng nhận biết kết quả, không phải làm màn hình đẹp hơn đơn thuần.

### 3.4. Giữ kiểm soát cốt lõi khi thiếu thời gian

Trong dự án giả định, team có 1 PM và 2 dev. Tôi chọn hoãn Excel nhưng giữ kiểm tra không âm, quyền duyệt và kiểm thử. Estimate AI cho thấy bỏ Excel vẫn cần 55,2 dev-MD đã có dự phòng, vượt capacity 48 dev-MD của phương án 6 tuần. Tôi chọn đề xuất 8 tuần, capacity giả định 64 dev-MD.

Tôi không coi tổng ngày công vừa sức là đủ để cam kết ngày giao. Tôi yêu cầu xác minh effort với team, dependency và critical path trước khi đưa ra timeline chính thức. Phương pháp MoSCoW giúp tôi giải thích điều gì là bắt buộc và điều gì có thể hoãn, thay vì cắt chất lượng để giữ deadline.

### 3.5. Người dùng thật cần hướng dẫn và dùng thử

Khi review WBS, tôi tách rõ việc viết hướng dẫn thao tác và cho thủ kho dùng thử. Một hệ thống đúng chức năng vẫn có thể khó dùng. Hướng dẫn giảm sai sót ban đầu; UAT cho biết nó có khớp quy trình thực hay không. Buổi UAT với thủ kho thật mới nằm trong kế hoạch, không được ghi như đã xảy ra chỉ vì tôi thử demo thành công.

## 4. AI làm tốt và chưa làm tốt

AI giúp tôi đi từ một ý tưởng đơn giản đến các file thật và luồng tương tác mà tôi không cần tự viết code. AI có thể sửa UI, tạo test, đối chiếu nguồn và tổ chức tài liệu nhanh. Khi tôi mô tả tình huống cụ thể, ví dụ “xóa không thấy kết quả ở ngay bên dưới”, AI có đầu vào tốt hơn để sửa và kiểm lại.

Điểm chưa tốt là một số output ban đầu đúng về logic nhưng chưa dễ hiểu với người dùng. Khi Sổ nhập 10 bị báo lỗi chung, tôi không biết lỗi đến từ dòng Bút còn trống; AI sau đó phải chỉ rõ dòng lỗi. Mục danh mục có quá nhiều nút và các thông báo đặt xa chỗ thao tác cũng khiến tôi tiếp tục yêu cầu sửa.

Một vấn đề khác là tài liệu được bổ sung nhiều lần nhưng chưa được chuẩn hóa ngay. Những đoạn cũ và mới cùng tồn tại làm người đọc khó biết quy tắc hiện hành. Audit Knowledge Health ban đầu chỉ có 2/10 tài liệu fresh; sau đó AI viết lại 8 tài liệu và lưu bản cũ trong history. Bài học của tôi là cập nhật tài liệu không chỉ là thêm một ghi chú cuối file: cần giữ một bản hiện hành nhất quán.

Tôi không coi AI tự phát hiện lỗi mobile hoặc lỗi chọn mã trong lúc chạy test là lỗi tôi đã tự bắt. Tôi cũng chưa phát hiện hallucination thật trong báo cáo EX-05. Tôi chọn ghi trung thực kết quả đó, không yêu cầu AI cố bịa một số để có bằng chứng nộp bài.

## 5. Tôi phản biện và kiểm chứng output như thế nào

Tôi trực tiếp thử demo và đưa phản hồi theo hành vi quan sát được. Ví dụ, khi thông báo xóa chưa rõ, tôi không chỉ chấp nhận câu trả lời “đã sửa”; tôi tiếp tục yêu cầu kết quả đúng tại mục thao tác và thử lại. Tôi xác nhận nguyên tắc: có thông báo thành công không chứng minh thao tác nghiệp vụ đúng. Nếu hàng còn tồn mà vẫn xóa được thì chưa đạt; phải sửa, test lại cả nhánh còn tồn và tồn 0, rồi tôi thử lại.

Tôi bổ sung Definition of Done với code review, test thật, review chéo, UAT và bằng chứng report/log/CI khi có. AI chỉ tự kiểm code của mình chưa đủ. Trong review PM/BA cho API và scenario, tôi yêu cầu tách rõ concurrent deduction, double-click/retry, hai đề nghị cùng hàng, consistency sau reload và lỗi lưu trữ. Các scenario mở rộng này được ghi Not Tested thay vì tự PASS vì code có nhánh try/catch hoặc có test tuần tự.

Với EX-05, tôi yêu cầu KPI phải có nguồn. Adoption cần task inventory và bằng chứng sử dụng AI, không suy từ token hay effort tiết kiệm. Token cost cần usage/billing hoặc kế hoạch thu thập rõ cho phiên sau. Năng suất cần baseline trước AI và thời gian có AI gồm review/rework, cùng scope và chất lượng. Hiện các nguồn đó chưa đầy đủ nên không tự đưa ra tiền hoặc tỷ lệ tăng năng suất.

Tôi cũng review việc AI truy xuất nguồn bằng 8 câu có spec/code/test/decision và chấm từng câu đạt. C7 là 8/8 trên tập đã được hướng dẫn này, không phải benchmark mù hay bảo đảm AI luôn đúng. C2 đạt 9/9 theo đợt gói demo, không phải lịch sử Git commit gốc. C5 đạt 10/10 có trace review nhưng API/scenario vẫn Changes Requested; hướng dẫn tôi đánh giá tạm ổn. Tôi hiểu KPI xanh không đồng nghĩa mọi artefact được phê duyệt hoặc có thể release.

## 6. Kết quả, giới hạn và việc tiếp theo

Kết quả hiện có là demo Tier 2 đã được tôi nghiệm thu, bộ artefact EX-01–EX-06, test scripts, Decision Log, câu trả lời viva viết và dashboard Knowledge Health. Tôi đã báo 90 phút thực hành ở một thời điểm trong phiên; đó không phải thời gian toàn khóa hay từng task, và chưa tự cộng các lượt trao đổi sau đó khi không có ghi nhận thêm.

Những việc còn cần làm gồm thực thi các scenario mở rộng đang Not Tested, xử lý finding và review lại API/scenario, tổ chức UAT thủ kho thật nếu triển khai MVP, xác nhận estimate với team, và bổ sung nguồn usage/billing/baseline. Tôi không trình bày đây là hệ thống production hoặc nói đã hoàn tất tiêu chí phát hiện ít nhất một hallucination thật khi chưa có bằng chứng.

Qua bài tập, tôi học rằng giá trị của AI không nằm ở số file tạo ra hoặc mức Adoption cao. Giá trị nằm ở việc giao đúng phạm vi, hỏi rõ khi thiếu, kiểm bằng bằng chứng và dám nói chưa đạt. AI giúp tôi thực hiện nhanh hơn các bước kỹ thuật; trách nhiệm lựa chọn và chấp nhận kết quả vẫn thuộc về con người.

## 7. Bằng chứng kèm bài

- REQ, WBS, EST, TRADEOFF, RISK, Delegation Map, DoR/DoD và RTM trong ARTIFACTS.
- DECISION-LOG-PB03.md: các review UAT, quyết định EX-03/04/06 và PMBA-REVIEW-01.
- AI-USAGE-LOG, TASK-INVENTORY, PRODUCTIVITY, HALLUCINATION-LOG và báo cáo W3 có nhãn dữ liệu giả lập.
- Knowledge Health audit, HUMAN-REVIEW-RECORD và REVIEW-FINDINGS phân biệt review với approval.
- CODEBASE: source và test của demo/Knowledge Health; VALIDATION: log kiểm tra mới khi đóng gói.
- VIDEO-DEMO: quay thao tác thật bằng tự động hóa của AI trên dữ liệu giả, có phụ đề, không giả giọng hoặc bảo vệ miệng của người học.
